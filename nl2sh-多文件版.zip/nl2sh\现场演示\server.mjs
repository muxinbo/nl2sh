/* nl2sh · 现场演示用本地静态服务（Node 版）
 *
 * 为什么需要它：单文件产物双击打开是 `file://`，浏览器会限制跨域请求，
 * AI 那条链路在 file:// 下走不通（离线规则库仍然可用）。
 * 用本机 127.0.0.1 起一个 HTTP 服务，来源变成 http://，AI 就能正常调用——
 * 这一点我在开发时实测过：本地 HTTP 下状态栏显示「AI 已接入」，流式也正常。
 *
 * 用法：node server.mjs [端口]
 * 脚本会自动打开浏览器。
 */
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { exec } from 'node:child_process';

const here = path.dirname(fileURLToPath(import.meta.url));
const PORT = Number(process.argv[2]) || 8777;

const TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.png': 'image/png',
  '.svg': 'image/svg+xml',
  '.md': 'text/markdown; charset=utf-8'
};

const server = http.createServer((req, res) => {
  let rel = decodeURIComponent((req.url || '/').split('?')[0]);
  if (rel === '/' || rel.endsWith('/')) rel += 'index.html';
  const file = path.join(here, rel);
  /* 只允许读本目录内的文件 */
  if (!file.startsWith(here)) {
    res.writeHead(403).end('forbidden');
    return;
  }
  fs.readFile(file, (err, data) => {
    if (err) {
      res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' }).end('404 ' + rel);
      return;
    }
    res.writeHead(200, {
      'Content-Type': TYPES[path.extname(file).toLowerCase()] || 'application/octet-stream',
      'Cache-Control': 'no-store'
    }).end(data);
  });
});

server.listen(PORT, '127.0.0.1', () => {
  const url = 'http://127.0.0.1:' + PORT + '/';
  console.log('');
  console.log('  nl2sh 现场演示服务已启动');
  console.log('  地址：' + url);
  console.log('');
  console.log('  · 用这个地址打开，AI 才能工作（双击文件是 file://，AI 会被浏览器拦住）');
  console.log('  · 断网时页面仍然可用，只是走内置规则库（50 条已核对任务）');
  console.log('  · 关掉这个黑窗口就等于停止服务');
  console.log('');
  exec('start "" "' + url + '"');
});
