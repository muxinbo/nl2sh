/* nl2sh · 沙箱场景
 *
 * 一个虚构但自洽的服务器：一个学生的项目目录 + 一份系统日志目录。
 * 权限、属主、时间戳都是刻意安排的，为了让"危险命令"的后果可解释：
 *   /var/log/**  属主 root，学生只能读不能写 —— 不给 sudo 删就是 Permission denied
 *   .env         600，提醒"别把密钥所在的目录开放成 777"
 *   大文件分布  让 find -size +1G 能同时命中"能删的"和"删不掉的"
 *
 * 时间基准 now = 1790946000（2026-10-02 21:00 +08:00），
 * 所有 mtime 都是相对它算的，保证 find -mtime / -newermt 的结果稳定可复现。
 */
window.NL2SH_SBX_FIXTURES = (function () {
  'use strict';

  var NOW = 1790946000;
  var DAY = 86400;
  var TODAY = 1790870400;        // 今天 00:00，find -newermt today 的分界线
  var YESTERDAY = TODAY - DAY;

  var ROOT = 0;                  // uid 0 = root
  var ME = 1000;                 // uid 1000 = student

  function dir(nodes, path, opts) {
    opts = opts || {};
    nodes[path] = { t: 'd', mode: opts.mode === undefined ? 0o755 : opts.mode, uid: opts.uid || 0, mtime: opts.mtime || NOW };
  }
  function file(nodes, path, data, opts) {
    opts = opts || {};
    var text = data === undefined ? '' : data;
    nodes[path] = {
      t: 'f', mode: opts.mode === undefined ? 0o644 : opts.mode,
      uid: opts.uid || 0, mtime: opts.mtime || NOW,
      size: byteLen(text), data: text
    };
    return nodes[path];
  }
  function sparse(nodes, path, size, opts) {
    opts = opts || {};
    nodes[path] = {
      t: 'f', mode: opts.mode === undefined ? 0o644 : opts.mode,
      uid: opts.uid || 0, mtime: opts.mtime || NOW, size: size, data: null
    };
  }
  function byteLen(s) {
    var n = 0;
    for (var i = 0; i < s.length; i++) {
      var c = s.charCodeAt(i);
      if (c < 0x80) n += 1;
      else if (c < 0x800) n += 2;
      else if (c >= 0xd800 && c <= 0xdbff) { n += 4; i++; }
      else n += 3;
    }
    return n;
  }

  /* 确定性伪随机：每次打开页面看到的日志都一样，截图和测试才可复现 */
  function rng(seed) {
    var s = seed;
    return function () { s = (s * 1103515245 + 12345) & 0x7fffffff; return s / 0x7fffffff; };
  }

  /** 生成一份 nginx 风格的 access.log，IP 分布刻意做出"有几个特别多"的效果 */
  function accessLog(lines) {
    var rand = rng(20261002);
    var ips = ['203.0.113.45', '198.51.100.7', '192.0.2.88', '203.0.113.45', '203.0.113.45',
      '198.51.100.7', '172.16.8.21', '10.0.0.5', '203.0.113.99', '198.51.100.7',
      '192.0.2.88', '203.0.113.45'];
    var paths = ['/', '/index.html', '/api/health', '/assets/app.js', '/api/login',
      '/uploads/a.png', '/favicon.ico', '/api/list'];
    var out = [];
    for (var i = 0; i < lines; i++) {
      var ip = ips[Math.floor(rand() * ips.length)];
      var p = paths[Math.floor(rand() * paths.length)];
      var status = rand() < 0.06 ? 404 : (rand() < 0.03 ? 500 : 200);
      var size = 200 + Math.floor(rand() * 9000);
      var hh = 20, mm = Math.floor(rand() * 59), ss = Math.floor(rand() * 59);
      var pp = function (n) { return (n < 10 ? '0' : '') + n; };
      out.push(ip + ' - - [02/Oct/2026:' + pp(hh) + ':' + pp(mm) + ':' + pp(ss) + ' +0800] ' +
        '"GET ' + p + ' HTTP/1.1" ' + status + ' ' + size + ' "-" "Mozilla/5.0 (X11; Linux x86_64)"');
    }
    return out.join('\n') + '\n';
  }

  function appLog(lines) {
    var rand = rng(777);
    var levels = ['INFO', 'INFO', 'INFO', 'WARN', 'INFO', 'ERROR'];
    var msgs = ['connected to redis', 'cache miss for key session:8f2a', 'job queue size=3',
      'slow query 412ms', 'user 1002 logged in', 'failed to write /home/student/project/cache/session.tmp'];
    var out = [];
    for (var i = 0; i < lines; i++) {
      var lv = levels[Math.floor(rand() * levels.length)];
      var m = msgs[Math.floor(rand() * msgs.length)];
      out.push('2026-10-02T2' + (i % 2) + ':' + String(i % 60).padStart(2, '0') + ':00+0800 ' + lv + ' ' + m);
    }
    return out.join('\n') + '\n';
  }

  function nodeModules(nodes) {
    var base = '/home/student/project/node_modules';
    /* 目录节点必须显式建出来：children() 是按前缀找直接子项的，
       中间少一层，整棵子树就会在 du / find / ls 里凭空消失。 */
    dir(nodes, base, { mode: 0o755, uid: ME });
    var pkgs = {
      express: ['index.js', 'lib/router.js', 'lib/application.js', 'package.json'],
      lodash: ['lodash.js', 'fp.js', 'package.json'],
      axios: ['index.js', 'lib/adapters/http.js', 'package.json'],
      'left-pad': ['index.js', 'package.json'],
      typescript: ['lib/tsc.js', 'lib/typescript.js', 'package.json']
    };
    Object.keys(pkgs).forEach(function (name) {
      dir(nodes, base + '/' + name, { mode: 0o755, uid: ME });
      if (name === 'express' || name === 'axios') dir(nodes, base + '/' + name + '/lib', { uid: ME });
      if (name === 'express') dir(nodes, base + '/' + name + '/lib/adapters', { uid: ME });
      if (name === 'typescript') dir(nodes, base + '/' + name + '/lib', { uid: ME });
      pkgs[name].forEach(function (f) {
        var full = base + '/' + name + '/' + f;
        dir(nodes, full.slice(0, full.lastIndexOf('/')), { uid: ME });
        file(nodes, full, '/* ' + name + ' ' + f + ' —— 沙箱里的占位内容 */\n', { uid: ME, mode: 0o644 });
        if (/typescript|application|lodash\.js/.test(f)) {
          var n = nodes[full];
          /* ⚠️ 这里曾经是 400000 + Math.floor(Math.random() * 400000)，
             后果是每次建会话的文件大小都不一样：du 的总量来回跳、
             同一个命令的前缀输出互相矛盾、断言具体大小的测试随机失败。
             "确定性、可复现"是这个沙箱的地基，所以尺寸必须是常量。
             数值按包名区分，让 du 的输出仍然像真的 node_modules。 */
          n.size = /typescript/.test(f) ? 782336 : (/application/.test(f) ? 706560 : 498688);
          n.data = null;
        }
      });
    });
    /* 再补一批小文件，让 du 的数字看起来像真的 node_modules */
    dir(nodes, base + '/.cache', { uid: ME });
    for (var i = 0; i < 40; i++) {
      file(nodes, base + '/.cache/chunk-' + i + '.js', 'export default ' + i + '\n', { uid: ME, mode: 0o600 });
    }
  }

  return {
    now: NOW,

    default: function () {
      var nodes = {};
      dir(nodes, '/', { mode: 0o755, uid: ROOT });
      dir(nodes, '/etc', { uid: ROOT });
      dir(nodes, '/etc/nginx', { uid: ROOT });
      file(nodes, '/etc/nginx/nginx.conf', 'user www-data;\nworker_processes auto;\n\nhttp {\n  include /etc/nginx/mime.types;\n  server {\n    listen 80;\n    root /home/student/project;\n  }\n}\n', { uid: ROOT, mode: 0o644, mtime: NOW - DAY * 12 });
      dir(nodes, '/var', { uid: ROOT });
      dir(nodes, '/var/log', { uid: ROOT });
      dir(nodes, '/var/log/nginx', { uid: ROOT, mode: 0o755 });
      file(nodes, '/var/log/nginx/access.log', accessLog(400), { uid: ROOT, mode: 0o640, mtime: NOW - 120 });
      file(nodes, '/var/log/nginx/error.log',
        '2026/09/28 03:12:44 [error] 812#812: *2841 connect() failed (111: Connection refused) while connecting to upstream\n' +
        '2026/09/29 11:40:02 [warn] 812#812: *2913 an upstream response is buffered to a temporary file\n' +
        '2026/10/01 22:07:19 [error] 813#813: *3155 open() "/home/student/project/uploads/missing.png" failed (2: No such file or directory)\n' +
        '2026/10/02 20:58:31 [warn] 812#812: *3410 conflicting server name "localhost" on 0.0.0.0:80\n',
        { uid: ROOT, mode: 0o640, mtime: NOW - 900 });
      file(nodes, '/var/log/syslog', 'Oct  2 21:00:01 student systemd[1]: Started Daily apt download activities.\n', { uid: ROOT, mode: 0o640, mtime: NOW - 600 });
      /* 40 天前的轮转日志：find -mtime +30 / -name '*.gz' 的目标 */
      sparse(nodes, '/var/log/nginx/access.log.1.gz', 1_800_000, { uid: ROOT, mode: 0o640, mtime: NOW - DAY * 40 });
      sparse(nodes, '/var/log/nginx/access.log.2.gz', 1_700_000, { uid: ROOT, mode: 0o640, mtime: NOW - DAY * 47 });
      sparse(nodes, '/var/log/syslog.1.gz', 900_000, { uid: ROOT, mode: 0o640, mtime: NOW - DAY * 35 });
      dir(nodes, '/var/lib', { uid: ROOT });
      dir(nodes, '/var/lib/mysql', { uid: ROOT, mode: 0o750 });
      sparse(nodes, '/var/lib/mysql/ibdata1', 1_288_490_188, { uid: ROOT, mode: 0o660, mtime: NOW - DAY * 3 });
      dir(nodes, '/usr', { uid: ROOT });
      dir(nodes, '/usr/bin', { uid: ROOT });
      dir(nodes, '/tmp', { mode: 0o1777, uid: ROOT });
      dir(nodes, '/home', { uid: ROOT });
      dir(nodes, '/home/student', { mode: 0o755, uid: ME });
      file(nodes, '/home/student/.bashrc', 'export PS1="\\u@\\h:\\w\\$ "\nalias ll="ls -alh"\n', { uid: ME, mode: 0o644, mtime: NOW - DAY * 90 });

      /* 项目目录 */
      var P = '/home/student/project';
      dir(nodes, P, { mode: 0o755, uid: ME });
      dir(nodes, P + '/src', { uid: ME });
      file(nodes, P + '/src/index.js', "const app = require('express')();\napp.get('/api/health', (req, res) => res.json({ ok: true }));\napp.listen(3000);\n", { uid: ME, mode: 0o644, mtime: NOW - DAY });
      file(nodes, P + '/src/app.js', '/* 主逻辑占位 */\n'.repeat(200), { uid: ME, mode: 0o644, mtime: NOW - DAY * 2 });
      file(nodes, P + '/src/styles.css', 'body { margin: 0; font-family: system-ui; }\n', { uid: ME, mode: 0o644, mtime: NOW - DAY * 9 });
      file(nodes, P + '/package.json', '{\n  "name": "project",\n  "version": "0.3.1",\n  "scripts": { "start": "node src/index.js" }\n}\n', { uid: ME, mode: 0o644, mtime: NOW - DAY * 5 });
      file(nodes, P + '/.env', 'DB_PASSWORD=correct-horse-battery-staple\nAPI_KEY=sk-live-9f2a77c1\n', { uid: ME, mode: 0o600, mtime: NOW - DAY * 5 });
      file(nodes, P + '/README.md', '# project\n\n演示用的占位项目。\n', { uid: ME, mode: 0o644, mtime: NOW - DAY * 20 });
      file(nodes, P + '/notes.txt', 'todo: 把 uploads 目录的权限收回去\n', { uid: ME, mode: 0o644, mtime: NOW - 7200 });
      dir(nodes, P + '/uploads', { uid: ME });
      file(nodes, P + '/uploads/avatar.png', 'PNG\u0000\u0000\u0000\u0000' + 'x'.repeat(184000), { uid: ME, mode: 0o644, mtime: NOW - DAY * 6 });
      file(nodes, P + '/uploads/banner.png', 'PNG\u0000\u0000\u0000\u0000' + 'x'.repeat(73000), { uid: ME, mode: 0o644, mtime: NOW - DAY * 11 });
      file(nodes, P + '/uploads/.gitkeep', '', { uid: ME, mode: 0o644, mtime: NOW - DAY * 60 });
      dir(nodes, P + '/cache', { uid: ME });
      file(nodes, P + '/cache/session.tmp', 'sess 8f2a\nsess 91bd\n'.repeat(40), { uid: ME, mode: 0o644, mtime: NOW - 3600 });
      file(nodes, P + '/cache/index.tmp', 'stale cache\n', { uid: ME, mode: 0o644, mtime: NOW - 3600 * 5 });
      dir(nodes, P + '/build', { uid: ME });
      file(nodes, P + '/build/old.tmp', 'tmp build artifact\n'.repeat(20), { uid: ME, mode: 0o644, mtime: NOW - DAY * 4 });
      file(nodes, P + '/build/bundle.js', '/* built bundle */\n'.repeat(500), { uid: ME, mode: 0o644, mtime: NOW - DAY * 4 });
      dir(nodes, P + '/scripts', { uid: ME });
      file(nodes, P + '/scripts/deploy.sh', '#!/bin/sh\nrsync -a ./build/ /var/www/html/\n', { uid: ME, mode: 0o644, mtime: NOW - DAY * 30 });
      nodeModules(nodes);

      /* 学生自己的日志和下载 */
      dir(nodes, '/home/student/logs', { uid: ME });
      file(nodes, '/home/student/logs/access.log', accessLog(1200), { uid: ME, mode: 0o644, mtime: NOW - 300 });
      file(nodes, '/home/student/logs/app.log', appLog(300), { uid: ME, mode: 0o644, mtime: NOW - 1800 });
      dir(nodes, '/home/student/Downloads', { uid: ME });
      sparse(nodes, '/home/student/Downloads/ubuntu-24.04.3-desktop-amd64.iso', 6_141_325_312, { uid: ME, mode: 0o644, mtime: NOW - DAY * 18 });
      sparse(nodes, '/home/student/Downloads/dataset.csv', 268_435_456, { uid: ME, mode: 0o644, mtime: NOW - DAY * 2 });
      file(nodes, '/home/student/backup-2026-09-28.tar.gz', '', { uid: ME, mode: 0o644, mtime: NOW - DAY * 4 });
      nodes['/home/student/backup-2026-09-28.tar.gz'].size = 48_234_496;
      nodes['/home/student/backup-2026-09-28.tar.gz'].data = null;

      return {
        nodes: nodes,
        cwd: '/home/student/project',
        now: NOW,
        services: {
          nginx: {
            pid: 812, active: true, startedAt: NOW - DAY * 6, tasks: 5, mem: '18.4M',
            desc: 'A high performance web server and a reverse proxy server',
            reloads: 0,
            log: [
              'using the "epoll" event method', 'nginx/1.24.0', 'start worker process 813',
              'start worker process 814', 'signal process started', 'reconfiguring'
            ]
          },
          mysql: {
            pid: 1044, active: true, startedAt: NOW - DAY * 12, tasks: 28, mem: '412.7M',
            desc: 'MySQL Community Server', reloads: 0,
            log: ['ready for connections', 'InnoDB initialization has started']
          },
          cron: { pid: 640, active: true, startedAt: NOW - DAY * 20, tasks: 1, mem: '2.1M', desc: 'Regular background program processing daemon', reloads: 0, log: ['(CRON) INFO (pidfile fd = 3)'] }
        },
        processes: [
          { user: 'root', pid: 1, cpu: '0.0', mem: '0.1', vsz: 168432, rss: 12884, comm: 'systemd', cmd: '/sbin/init' },
          { user: 'root', pid: 640, cpu: '0.0', mem: '0.0', vsz: 29008, rss: 3120, comm: 'cron', cmd: '/usr/sbin/cron -f' },
          { user: 'root', pid: 812, cpu: '0.0', mem: '0.2', vsz: 232140, rss: 18844, comm: 'nginx', cmd: 'nginx: master process /usr/sbin/nginx' },
          { user: 'www-data', pid: 813, cpu: '0.1', mem: '0.3', vsz: 235216, rss: 24680, comm: 'nginx', cmd: 'nginx: worker process' },
          { user: 'www-data', pid: 814, cpu: '0.2', mem: '0.4', vsz: 238328, rss: 31204, comm: 'nginx', cmd: 'nginx: worker process' },
          { user: 'mysql', pid: 1044, cpu: '1.3', mem: '5.1', vsz: 1892344, rss: 422688, comm: 'mysqld', cmd: '/usr/sbin/mysqld' },
          { user: 'root', pid: 1120, cpu: '0.0', mem: '0.1', vsz: 15420, rss: 6820, comm: 'sshd', cmd: 'sshd: /usr/sbin/sshd -D' },
          { user: 'student', pid: 3312, cpu: '2.4', mem: '1.2', vsz: 1044212, rss: 98432, comm: 'node', cmd: 'node src/index.js' },
          { user: 'student', pid: 4188, cpu: '0.0', mem: '0.0', vsz: 9876, rss: 3412, comm: 'bash', cmd: '-bash' }
        ],
        sockets: [
          { port: 22, addr: '0.0.0.0:22', proc: 'sshd', pid: 1120, fd: 3 },
          { port: 80, addr: '0.0.0.0:80', proc: 'nginx', pid: 812, fd: 6 },
          { port: 3000, addr: '127.0.0.1:3000', proc: 'node', pid: 3312, fd: 21 },
          { port: 3306, addr: '127.0.0.1:3306', proc: 'mysqld', pid: 1044, fd: 22 }
        ]
      };
    }
  };
})();
