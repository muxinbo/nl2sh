/* nl2sh · 模型代理（EdgeOne Pages Cloud Function 版）
 *
 * ── 为什么要有这一份 ────────────────────────────────────
 * 原来的代理是 Cloudflare Worker，域名 `nl2sh-api.zibochen82.workers.dev`。
 * 实测（外部评审，2026-10-03）：**`*.workers.dev` 在大陆被 DNS 污染**——
 * curl 21 秒超时零响应，DNS 解析返回 Facebook / Dropbox 的 IP。
 * 同一台机器的浏览器能通，只是因为走了系统代理。
 *
 * 也就是说：**评委的校园网大概率没有代理，赛道三最核心的"AI 功能技术实现与集成度"
 * 他一点都看不到**——界面上写着"AI 已接入"也只是静态展示。
 *
 * 这份代码把同一个代理搬到 EdgeOne Pages 的 Cloud Function 上：
 * 它跑在**国内节点**，而且和静态页**同域**，所以：
 *   · 前端不需要再走 FALLBACK_ORIGIN（同源 /api/chat 直接通）
 *   · 没有跨源、没有预检，也就没有额外的失败点
 *   · 静态页本身也建议一起放 EdgeOne，两边一起国内可达
 *
 * ── 与 worker/worker.js 的关系 ──────────────────────────
 * 服务端加固那几段（SERVER_SAFETY / STRICT_ADDON / DANGER_HINTS / LIMITS / harden）
 * 与 worker/worker.js **逐字相同**，两边必须同步。
 * 这不是靠"记得改"来保证的——scripts/audit.mjs 里有一条检查会**逐字比对两份常量**，
 * 一旦漂移就红。（这个项目里凡是"需要我手工同步两次以上"的东西，最后都漂过。）
 *
 * ── 路由 ────────────────────────────────────────────────
 * EdgeOne Pages 的 Cloud Function 按目录映射路径：
 *   cloud-functions/api/[[default]].js  →  /api/*
 * 所以这个文件里的 `/health` 对外是 `/api/health`，`/chat` 对外是 `/api/chat`。
 * ⚠️ 挂载前缀以控制台/`edgeone pages dev` 的实际输出为准；如果它显示的是别的路径，
 *    把下面的 app.post('/chat') 改成对应的相对路径即可，其余不用动。
 */
import express from 'express';
import { Readable } from 'node:stream';

const ZHIPU_URL = 'https://open.bigmodel.cn/api/paas/v4/chat/completions';

/* 只允许这两个：一个主力、一个深度思考。想换模型必须改这里并重新实测。 */
const MODELS = { fast: 'glm-4-flash', think: 'glm-4.7' };

const LIMITS = {
  maxInputChars: 16000,
  maxTotalChars: 64000,
  contextBudgetChars: 16000,
  maxTokensCap: 2048,
  windowSeconds: 60,
  windowRequests: 20
};

/* ── 以下四段与 worker/worker.js 逐字相同（audit 会比对）── */
const SERVER_SAFETY = [
  '',
  '[服务端安全约束 · 由边缘代理注入，前端无法绕过]',
  '1. 不要生成针对 / 、/etc 、/dev 、/proc 、/sys 的递归强制删除，也不要生成格式化磁盘的命令。',
  '2. 修改或删除类命令，先给出可先行确认的只读命令（ls / find / grep），再给改动命令。',
  '3. 可能造成不可逆数据损失时，risk_note 必须写明后果，risk_level 至少是 medium。',
  '4. 不要生成「下载远程脚本并直接执行」（curl … | sh）这类命令。'
].join('\n');

const STRICT_ADDON = '\n5. 【本次请求命中服务端高危意图检测：请格外保守，先讲清后果，并优先给出只读的确认步骤。】';

const DANGER_HINTS = [
  /rm\s+(-[a-z]*\s+)*-?[a-z]*[rf][a-z]*\s+\/(\s|$)/i,
  /rm\s+-rf\s+~\//,
  /mkfs(\.\w+)?\s+\/dev\//i,
  /dd\s+if=.*of=\/dev\//i,
  /:\(\)\s*\{.*\};\s*:/,
  />\s*\/dev\/sd[a-z]/i,
  /chmod\s+-R\s+777\s+\//,
  /curl[^|]*\|\s*(ba)?sh/i
];

function harden(messages) {
  const meta = { trimmed: 0, injected: false, flagged: false };
  const msgs = messages.map((m) => ({
    role: m && m.role ? String(m.role) : 'user',
    content: String((m && m.content) || '')
  }));

  const userText = msgs.filter((m) => m.role === 'user').map((m) => m.content).join('\n');
  meta.flagged = DANGER_HINTS.some((re) => re.test(userText));

  const block = SERVER_SAFETY + (meta.flagged ? STRICT_ADDON : '');
  const sys = msgs.find((m) => m.role === 'system');
  if (sys) sys.content = sys.content + '\n' + block;
  else msgs.unshift({ role: 'system', content: block.replace(/^\n/, '') });
  meta.injected = true;

  const size = () => msgs.reduce((n, m) => n + m.content.length, 0);
  while (size() > LIMITS.contextBudgetChars) {
    const firstChat = msgs.findIndex((m) => m.role !== 'system');
    if (firstChat < 0) break;
    const secondChat = msgs.findIndex((m, i) => i > firstChat && m.role !== 'system');
    const dropTo = secondChat < 0 ? firstChat : secondChat;
    meta.trimmed += dropTo - firstChat + 1;
    msgs.splice(firstChat, dropTo - firstChat + 1);
    if (msgs.filter((m) => m.role !== 'system').length <= 1) break;
  }
  return { messages: msgs, meta };
}
/* ── 逐字相同段落结束 ─────────────────────────────────── */

function cors() {
  return {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'POST, GET, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
    /* 自定义响应头必须显式 expose，否则跨源读不到（拿到的是 null） */
    'Access-Control-Expose-Headers': 'X-NL2SH-Server, X-NL2SH-Trimmed, X-NL2SH-Safety, X-NL2SH-Model'
  };
}

function clamp(n, lo, hi, fallback) {
  const v = Number(n);
  if (!Number.isFinite(v)) return fallback;
  return Math.min(Math.max(v, lo), hi);
}

/* 限流：Cloud Function 实例可能被回收，所以这只是"尽力而为"的一层。
   真正的防线是 EdgeOne 控制台里的速率限制规则（见操作手册第 6 步）。 */
const buckets = new Map();
function rateLimit(ip) {
  const now = Date.now();
  const rec = buckets.get(ip);
  if (!rec || now - rec.start > LIMITS.windowSeconds * 1000) {
    buckets.set(ip, { start: now, n: 1 });
    return { ok: true };
  }
  rec.n += 1;
  if (rec.n > LIMITS.windowRequests) {
    return { ok: false, retryAfter: Math.ceil((LIMITS.windowSeconds * 1000 - (now - rec.start)) / 1000) };
  }
  return { ok: true };
}

const app = express();
app.use(express.json({ limit: '256kb' }));

/* 健康检查：部署完先打这个，确认密钥注入成功 */
app.get('/health', (req, res) => {
  res.set(cors()).json({ ok: true, hasKey: !!process.env.ZHIPU_API_KEY, models: MODELS, via: 'edgeone-pages-function' });
});

app.options('/chat', (req, res) => res.set(cors()).status(204).end());

app.post('/chat', async (req, res) => {
  res.set(cors());
  if (!process.env.ZHIPU_API_KEY) {
    return res.status(500).json({ error: '服务端未配置 ZHIPU_API_KEY' });
  }

  const ip = (req.headers['x-forwarded-for'] || '').split(',')[0].trim() ||
    req.socket.remoteAddress || 'unknown';
  const gate = rateLimit(ip);
  if (!gate.ok) {
    return res.status(429).set('Retry-After', String(gate.retryAfter))
      .json({ error: '请求太频繁，请稍后再试' });
  }

  const body = req.body || {};
  const messages = Array.isArray(body.messages) ? body.messages : null;
  if (!messages || !messages.length) return res.status(400).json({ error: 'messages 不能为空' });

  const total = messages.reduce((n, m) => n + String((m && m.content) || '').length, 0);
  if (total > LIMITS.maxTotalChars) {
    return res.status(413).json({ error: '上下文过长，请清空对话后重试' });
  }
  const lastUser = [...messages].reverse().find((m) => m && m.role === 'user');
  if (lastUser && String(lastUser.content).length > LIMITS.maxInputChars) {
    return res.status(413).json({ error: '单条消息上限 ' + LIMITS.maxInputChars + ' 字' });
  }

  /* 模型由服务端决定，不接受客户端指定，免得有人拿它调贵的模型 */
  const model = body.thinking === true ? MODELS.think : MODELS.fast;
  const wantJson = body.json !== false;

  const hardened = harden(messages);
  const payload = {
    model,
    messages: hardened.messages,
    stream: body.stream !== false,
    temperature: clamp(body.temperature, 0, 2, 0.2),
    max_tokens: Math.min(Number(body.max_tokens) || 1200, LIMITS.maxTokensCap)
  };
  if (wantJson) payload.response_format = { type: 'json_object' };

  let upstream;
  try {
    upstream = await fetch(ZHIPU_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${process.env.ZHIPU_API_KEY}` },
      body: JSON.stringify(payload)
    });
  } catch (e) {
    return res.status(502).json({ error: '连不上模型服务：' + String(e && e.message) });
  }

  if (!upstream.ok) {
    const text = await upstream.text();
    console.error('upstream', upstream.status, text.slice(0, 400));
    return res.status(upstream.status)
      .set('Content-Type', 'application/json; charset=utf-8').send(text);
  }

  /* ── 关键：把上游 body 直接流出去才是真流式 ──
     写成 await upstream.text() 再返回等于把整个响应缓冲下来，前端的打字机效果会消失。 */
  res.status(200);
  res.set({
    'Content-Type': 'text/event-stream; charset=utf-8',
    'Cache-Control': 'no-cache, no-transform',
    'X-Accel-Buffering': 'no',
    'X-NL2SH-Server': 'edgeone',
    'X-NL2SH-Trimmed': String(hardened.meta.trimmed),
    'X-NL2SH-Safety': hardened.meta.flagged ? 'strict' : 'on',
    'X-NL2SH-Model': model
  });
  if (upstream.body) {
    Readable.fromWeb(upstream.body).pipe(res);
  } else {
    res.end();
  }
});

export default app;
