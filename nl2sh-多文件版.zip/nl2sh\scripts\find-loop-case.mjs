/* 找一条"第一次就会失败、而且修正能收敛"的真实需求
 *
 * 为什么要做这件事：自验证自纠错闭环是本作品最独特的点，但它默认只显示
 * 「第 1 次就真跑通（未触发修正）」——因为 glm-4-flash 大多一次就对。
 * 用户和评审都指出过："评委大概率全程看不到自纠错能力"。
 *
 * 解法不是**造**一个假失败（那是假的），而是**实测找出一个自然就会失败的需求**：
 * 把它当"看一次闭环"的默认任务，第一轮红、第二轮绿，全程真实。
 *
 * 判据（三条都要满足）：
 *   ① 第 1 轮在沙箱里真的失败（exit≠0 或有 stderr）
 *   ② 把真实报错喂回模型后，第 2 轮的答案能跑通
 *   ③ 失败原因不是"沙箱没实现这条命令"这种修不好的死结
 */
import fs from 'node:fs';
import path from 'node:path';

const assets = 'D:/dsh/downloads/nl2sh/assets';
globalThis.window = globalThis;
new Function('window', fs.readFileSync(path.join(assets, 'ai.js'), 'utf8'))(globalThis);
for (const f of ['sandbox-fixtures.js', 'sandbox-cmds.js', 'sandbox.js']) {
  new Function('window', fs.readFileSync(path.join(assets, f), 'utf8'))(globalThis);
}
const AI = globalThis.NL2SH_AI;
const sb = globalThis.NL2SH_SANDBOX.createSession();
const st = await AI.health();
if (!st.ok) { console.log('代理不通，无法实测'); process.exit(1); }

function ask(q, repair) {
  return new Promise((resolve) => {
    AI.generate(q, {
      onProgress() {},
      onDone: resolve,
      onError(e) { console.log('    生成失败：' + (e && e.message)); resolve(null); }
    }, { repair: repair || null, history: [] });
  });
}

const CANDIDATES = [
  '把 cache 目录删掉',
  '统计 /var/log/nginx/access.log 里 500 错误一共出现了多少次',
  '把 uploads 目录里的 png 文件按顺序重命名成 1.png、2.png',
  '算一下 /var/log/nginx/access.log 里所有 500 请求返回的字节数总和',
  '找出 src 目录下所有 js 文件里被注释掉的 TODO',
  '看看 /var/log/nginx/error.log 最后 20 行有什么'
];

console.log('  共 ' + CANDIDATES.length + ' 个候选，逐个实测...\n');
const results = [];

for (const q of CANDIDATES) {
  console.log('─'.repeat(70));
  console.log('需求：' + q);
  const a1 = await ask(q);
  if (!a1) { console.log('  跳过（生成失败）\n'); continue; }
  const r1 = sb.run(a1.cmd);
  const failed1 = r1.code !== 0 || !!String(r1.err || '').trim();
  console.log('  第 1 轮：' + a1.cmd);
  console.log('    沙箱：exit ' + r1.code + (String(r1.err || '').trim() ? ' · ' + String(r1.err).trim().split('\n')[0] : ''));

  if (!failed1) {
    console.log('    → 一次就过（不触发修正）\n');
    results.push({ q, firstFail: false });
    continue;
  }

  const repairCtx = {
    cmd: a1.cmd, code: r1.code,
    err: [r1.err, r1.out].filter(Boolean).join('\n').slice(0, 800), attempt: 1
  };
  const a2 = await ask(q, repairCtx);
  if (!a2) { console.log('    → 修正轮生成失败\n'); results.push({ q, firstFail: true, converge: false }); continue; }
  const r2 = sb.run(a2.cmd);
  const failed2 = r2.code !== 0 || !!String(r2.err || '').trim();
  console.log('  第 2 轮：' + a2.cmd);
  console.log('    沙箱：exit ' + r2.code + (String(r2.err || '').trim() ? ' · ' + String(r2.err).trim().split('\n')[0] : ''));
  console.log('    → ' + (failed2 ? '仍未通过' : '★ 修正后跑通（红→绿，可用于闭环演示）'));
  results.push({ q, firstFail: true, converge: !failed2, cmd1: a1.cmd, cmd2: a2.cmd });
  console.log('');
}

console.log('\n' + '═'.repeat(70));
console.log('汇总：');
results.forEach((r) => {
  const tag = !r.firstFail ? '一次就过 ✗' : (r.converge ? '★ 失败→修正→通过 ✓✓' : '失败但没修好 ✗');
  console.log('  ' + tag.padEnd(22) + r.q.slice(0, 34));
});
const best = results.filter((r) => r.firstFail && r.converge);
if (best.length) {
  console.log('\n推荐用作"看一次闭环"的默认任务：');
  console.log('  「' + best[0].q + '」');
  console.log('  第 1 轮：' + best[0].cmd1);
  console.log('  第 2 轮：' + best[0].cmd2);
} else {
  console.log('\n这批候选里没有"失败且能修好"的，需要再找。');
}
