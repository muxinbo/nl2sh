/* nl2sh · 模型接入层（经同源边缘代理）
 *
 * 架构：浏览器 ──POST /api/chat──▶ Cloudflare Worker ──▶ 智谱
 *                                        ↑ 密钥只在这里
 * 前端永远拿不到密钥，也永远不直连模型厂商。
 *
 * 2026-10-03 真实请求实测（决定的默认模型，别凭记忆改）：
 *   glm-4.7-flash  500 / 75.9s  ✗ 这个 ID 不存在
 *   glm-4-flash    200 /  0.5s  ✓ 默认模型
 *   glm-5.3-flash  429 /  0.2s  ✗ 余额不足
 *   glm-4.7        200 /  4.0s  ✓ 有 reasoning_content，用于"深度思考"开关
 *   JSON mode 实测：glm-4-flash 流式从"带 ```json 围栏、首字节 2.31s"
 *   变成"可直接 JSON.parse、首字节 0.43s"——所以 response_format 是强制的。
 *
 * 职责边界：
 *   本文件负责  需求 → 命令 + 逐段解释 + 风险等级（模型该干的事）
 *   不负责      影响推演（sim）。那是沙箱在影子会话里真跑一遍算出来的，
 *               比让模型猜准确得多，也顺带让"执行前推演"从猜测变成事实。
 */
window.NL2SH_AI = (function () {
  'use strict';

  var ENDPOINT = '/api/chat';
  var HEALTH = '/api/health';

  /* ── 托管方式与代理地址 ──────────────────────────────
     两种情况：
       ① 静态站和 Worker 部署在同一处（Cloudflare Pages + Pages Function）
          → 同源 /api/chat 直接可用，下面留空即可。
       ② 静态站托管在 GitHub Pages 这类没有 /api 路由的纯静态主机
          → 同源必然 404，必须填上 Worker 的地址，否则评委永远只看到离线模式。
     所以策略是"同源优先，失败再走兜底"，并把最终生效的基址记在 state.base 上。
     ⚠️ 只有这里留空且同源也不通时才会降级到离线模式。 */
  /* 兜底域：pages.dev 上部署了 _worker.js（见 deploy/CloudflarePages函数代理-操作步骤.md），
   实测 /api/health 返回 hasKey:true、/api/chat 能真实流式（首字节 ~0.8s），
   而且它对跨源请求正确回告 X-NL2SH-* 诊断头。
   旧的 workers.dev 已确认在部分国内网络下 DNS 被污染（解析到 Facebook/Dropbox 的 IP），
   所以换成这个；而**真正解决"国内可达"的仍然是 EdgeOne 那条**（腾讯云国内节点）。 */
var FALLBACK_ORIGIN = 'https://nl2sh.pages.dev';
  /* 上面这个地址是已部署的 Cloudflare Worker（2026-10-03 部署并实测）：
       · /api/health → {"ok":true,"hasKey":true,...}
       · OPTIONS 预检 → 204 + Access-Control-Allow-Origin: *
       · 真实 POST /api/chat → 200 + text/event-stream（glm-4-flash 流式）
     因为作品托管在 GitHub Pages（没有 /api 路由），同源一定 404，
     所以这一行是"AI 能不能用"的开关，删掉它就会永远停在离线模式。 */

  /* 服务端会按 thinking 标志选模型，这两个值只用于界面上显示"当前用哪个" */
  var MODELS = { fast: 'glm-4-flash', think: 'glm-4.7' };

  /* 沙箱实际支持的命令与参数写法（由 app.js 在启动时注入 help 的输出）。
     为什么要注入：实测发现模型会**发明**沙箱里没有的命令——问"把图片转成 webp"时
     它写出了 `cconvert`（沙箱里叫 cwebp），问"重命名一批文件"时写出了 shell 的 while 循环。
     这跟"占位符"是同一个根因：**提示词不知道沙箱的现实**。
     注入后模型只能从这份清单里挑，第一次就能跑通的比例明显上升。 */
  var SANDBOX_HELP = '';
  function setSandboxHelp(text) { SANDBOX_HELP = String(text || '').slice(0, 1800); }

  var SYSTEM_PROMPT = [
    '你是 Linux 命令专家，服务对象是刚学 Linux 的新手。',
    '用户用中文描述想做的事，你只返回一个 JSON 对象，不要解释文字，不要 markdown 代码块。',
    '',
    'JSON 结构：',
    '{"command":"可直接执行的一条命令（单行）",',
    '"segments":[{"part":"命令里的连续片段，必须和 command 逐字一致","label":"6 字以内的短标签","explanation":"这一段干什么、参数什么语义，40 字以内"}],',
    '"risk_level":"low|medium|high",',
    '"risk_note":"这个等级的依据，30 字以内",',
    '"flow":"只有命令分多个阶段时才填，用 → 连接各阶段，不要重复命令本身",',
    '"see":["最多 2 条，必须是完整可执行的命令"]}',
    '',
    '硬性要求：',
    '1. segments 给 2-5 段，覆盖关键参数；每段的 part 必须能在 command 里逐字找到（连引号、空格都要一致），否则那一段会被丢弃。',
    '2. 解释必须准确。不确定某个参数的语义时，宁可不给这一段，也不要猜。',
    /* ⚠️ 这条原来写的是「需要用户自己填的地方用 <占位符>」——**方向完全错了**。
       实测（scripts/find-loop-case.mjs）发现模型会输出 `rm -rf <cache_directory>`，
       追下去才发现：不是它不听话，是它在**执行我的指令**。
       而这个作品的立身之本恰恰是"拿到一条能直接粘贴执行的命令"——
       一个带尖括号的模板等于交了半成品，用户还得自己猜路径。
       改法：不许占位符，缺路径就用当前目录或能推断出的路径，并在 risk_note 里说明假设。 */
    '3. command 必须单行、**可直接粘贴执行**，不许出现 `<路径>` `<文件>` `xxx` `your_file` 这类占位符。',
    '   用户没给具体路径时，用当前目录 `.` 或从上下文能确定的路径，并在 risk_note 里写明"假设在当前目录执行"。',
    '4. risk_level 判定：只读查询是 low；会写文件、改权限、重启服务是 medium；删除、递归改权限、写块设备、把网络内容管道给 shell 执行是 high。',
    '5. 用户没说清环境时，选更安全、影响面更小的做法。',
    /* 这一条是实测加的：模型会把 shell 正则里的 \( \) 直接写进 JSON 字符串，
       而 JSON 不认这种转义，整条回答就解析不出来。
       前端已经有一层修复兜底（repairJsonEscapes），但源头少犯一次更好。
       另外 JSON 里 / 不需要转义、\/ 会被解析成一个正斜杠，
       所以要表达"反斜杠 + 斜杠"必须写 \\/ —— 这条也说清楚，能少一轮自动修正。 */
    '6. JSON 字符串里要表达反斜杠必须写两个：要表达 \\( 就写 \\\\(，要表达 \\d 就写 \\\\d。',
    '7. JSON 里正斜杠 / 不需要转义；写 \\/ 会被解析成一个 /。要表达"反斜杠加斜杠"必须写 \\\\/。',
    /* 多轮对话：用户会追问，模型必须知道"它"指的是什么。 */
    '8. 用户可能在**追问上一条命令**（例如刚问完「找出最大的 10 个文件」，接着说「那只要今天的呢」）。',
    '   对话历史会一并给你，请结合上下文理解需求；仍然只返回同样结构的 JSON 对象。',
    /* 真机实测踩到的三个坑，全部写进规则——它们共同的特征是"看起来成功、结果却是错的"：
       ① grep `ls -l` 里的日期字符串 → ls 的日期格式随 locale 变（中文是「10月 02」），一定匹配不到；
       ② 把 find 的输出管道接给 ls → ls 不读标准输入，会静默列出当前目录，退出码还是 0；
       ③ find 的 -printf → 本沙箱未实现；管道会把它的报错和退出码一起吃掉，
          外面只看到"成功、零输出"。所以排序要走 ls -lS / du -ah | sort -rh。 */
    /* 教学属性：这个作品的定位是"新手零门槛入门"，而解释如果"用术语解释术语"
       （例如用"谓词""标准输入"去解释 xargs），目标读者根本看不懂——
       等于把"教方法"做成了"给答案"。规则写死在提示词里：
       不许引入比原命令更难的词，必须说清"不写它会怎样"，尽量给生活化类比。 */
    '9. 逐段解释是给**完全没学过 Linux 的人**看的，必须遵守：',
    '   · 不许用比原命令更难的术语。宁可啰嗦，不要用「谓词」「标准输入」「管道符」这类词，',
    '     除非你同时在括号里用一句大白话解释它。',
    '   · 每个参数都要说清「不写它会怎样」，而不只是「它是干什么的」。',
    '   · 能给生活化类比就给（例如「-r 像把一摞纸倒过来数」比「逆序」好懂）。',
    '   · label 用 6 字以内的中文短词，不要写英文命令名。',
    '10. 排序与筛选请用这些写法：按大小 `ls -lS` 或 `du -ah | sort -rh`；按时间用 find 的 -mtime / -size 条件。',
    '   **避开三个会"假装成功"的写法**：',
    '   · 不要用 find 的 -printf（本沙箱未实现，管道会吃掉报错，命令零输出却返回成功）；',
    '   · 不要 grep `ls -l` 输出里的日期字符串（日期格式随系统语言变，中文环境是「10月 02」）；',
    '   · 不要把 find 的输出管道接给 ls（ls 不读标准输入，会静默列出当前目录）。'
  ].join('\n');

  /* 极客终端模式用：只要命令，输出越少越快（免费额度下"少输出"就是"快"） */
  /* 数据分析专用提示词。
     赛道三的评审侧重点第一条就是"模型选择、API 调用、**数据处理能力**"——
     只做"中文 → 命令"是覆盖不到数据处理这一项的。
     所以这里让模型读服务器日志的**本地预处理结果**（统计量是用真实命令算出来的，
     不是估计值）+ 原文取样，产出结论与可执行的确认命令。
     ⚠️ 两条关键设计：
       1. 统计量由沙箱里的 awk/sort/uniq 真跑出来，模型负责**解释**而不是**计算**——
          它算数不可靠，这是扬长避短。
       2. 环境事实（nginx 而非 apache、日志路径、可用命令清单）必须写死在提示词里。
          第一次真机实测时模型编出了 `tail /var/log/apache2/error.log` 和
          `ipset add suspicious_ip …`——前者路径根本不存在，后者这台机器没装。
          界面上的"一键在沙箱里验证"是第二道防线：编出来的命令跑不通，一眼可见。 */
  var ANALYST_ENV = [
    '【这台机器的环境（已核实，不要臆测）】',
    '- Web 服务是 nginx，**不是 apache**；没有任何 apache 的目录或日志。',
    '- 访问日志 /var/log/nginx/access.log，错误日志 /var/log/nginx/error.log。',
    '- 日志格式：客户端IP - - [日期:时间 +0800] "方法 路径 协议" 状态码 响应字节 "-" "UA"',
    '- 当前用户是普通用户 student，**没有 sudo 权限**；不要给需要 root 的命令。',
    '- 可用命令仅限这些基础工具：awk basename cat cd chmod chown cp cut date df dirname du echo file',
    '  find grep head id kill ls mkdir mv ps pwd rm sed seq sort stat tail tar tee touch tr uniq unzip wc',
    '  which whoami xargs zip。',
    '- **不要使用 ipset / iptables / ufw / fail2ban / systemctl / journalctl / ss / netstat / tcpdump**',
    '  这类这台机器上没有的工具；统计与排查一律用上面那批基础命令组合出来。'
  ].join('\n');

  var SYSTEM_PROMPT_ANALYST = [
    '你是 Linux 运维分析助手。用户会给你一份服务器日志的**本地预处理结果**（统计量由真实命令算出，可信）和原文取样。',
    ANALYST_ENV,
    '',
    '你的任务：找出值得注意的事，并给出可以直接执行的确认命令。只返回一个 JSON 对象，不要解释文字，不要 markdown 代码块。',
    '',
    'JSON 结构：',
    '{"summary":"一句话结论，40 字以内",',
    '"findings":[{"title":"6 字以内的短标题","detail":"40 字以内，必须点明依据是哪个数字","level":"low|medium|high","cmd":"用来确认这条结论的可执行命令；没有就给空串"}],',
    '"next":["最多 3 条你最建议马上执行的命令"]}',
    '',
    '硬性要求：',
    '1. findings 最多 4 条，按重要性从高到低排。',
    '2. detail 里必须引用预处理结果里的具体数字或原文片段，不许泛泛而谈。',
    '3. level 判定：只是观察、无风险是 low；需要跟进确认是 medium；疑似攻击、数据风险是 high。',
    '4. cmd 必须是单行、可在**上面那份命令清单里**直接执行的命令，路径必须来自输入或环境说明；',
    '   不确定就给空串。**编一个不存在的工具或路径，比留空更有害。**',
    '5. 数据量小或没有异常时，如实说"未发现明显异常"，不要硬凑结论。',
    '6. JSON 字符串里要表达反斜杠必须写两个；正斜杠 / 不需要转义。'
  ].join('\n');

  var SYSTEM_PROMPT_SHORT = [
    '你是 Linux 命令专家。只返回一个 JSON 对象，不要解释文字，不要 markdown 代码块。',
    '',
    '结构：',
    '{"command":"可直接执行的一条命令（单行）","segments":[{"part":"片段","label":"短标签","explanation":"一句话说明"}],' +
      '"risk_level":"low|medium|high","risk_note":"风险依据，20 字以内"}',
    '',
    '要求：command 必须单行、**可直接粘贴执行**，不许出现 `<路径>` `xxx` 这类占位符；' +
      '缺路径就用当前目录 `.` 并在 risk_note 里说明；' +
      '删除、递归改权限、写块设备一律 risk_level=high；不确定环境时选影响面更小的做法。'
  ].join('\n');

  /* 危险命令兜底：不采信模型自述，命中就强制升级等级。
     能用一条短正则说清的就用 re；说不清的（比如"rm 带了递归开关、目标是根"）
     用 test 函数，拆开判断比写一条又长又难维护的正则更可靠。 */
  function stripQuotes(s) { return String(s || '').replace(/^['"]|['"]$/g, ''); }

  function isRecursiveRootDelete(cmd) {
    var m = /\brm\s+([^;&|]*)/.exec(cmd);
    if (!m) return false;
    var args = m[1].split(/\s+/).filter(Boolean);
    var recursive = false, targets = [];
    args.forEach(function (a) {
      if (a[0] === '-' && a.length > 1) {
        if (/[rR]/.test(a) || a === '--recursive') recursive = true;
      } else {
        targets.push(stripQuotes(a));
      }
    });
    if (!recursive) return false;
    return targets.some(function (t) {
      return /^\/\*?$/.test(t) || /^\/\*/.test(t) || /^~\/?\*?$/.test(t) ||
        t === '$HOME' || t === '$HOME/' || t === '${HOME}';
    });
  }

  var DANGER_PATTERNS = [
    { test: isRecursiveRootDelete, why: '递归删除根目录或整个家目录' },
    { re: /:\s*\(\s*\)\s*\{[^}]*\}\s*;?\s*:/, why: 'fork 炸弹' },
    { re: /\bmkfs(\.\w+)?\s/, why: '格式化文件系统' },
    { re: /\bdd\b[^|]*\bof=\/dev\/(sd|nvme|hd|vd|mmcblk)/, why: '直接写块设备' },
    { re: />\s*\/dev\/(sd|nvme|hd|vd|mmcblk)/, why: '覆盖块设备' },
    { re: /chmod\s+-R\s+[0-7]*7[0-7]*7\s+\/(\s|$)/, why: '把根目录权限放到最大' },
    { re: /chown\s+-R\s+\S+\s+\/(\s|$)/, why: '递归修改根目录属主' },
    { re: /\b(curl|wget)\b[^|]*\|\s*(sudo\s+)?(ba|z|d|k)?sh\b/, why: '把网络内容直接管道给 shell 执行' }
  ];

  /* ── 连接状态 ─────────────────────────────────────────
     没有"用户自己的 Key"这个概念了：密钥在 Worker 里。
     前端只需要知道"代理通不通、用的是哪个模型"。 */
  var state = {
    checked: false,
    ok: false,          // 代理可用且有密钥
    hasKey: false,
    base: '',           // 生效的代理基址：'' 表示同源，否则是 Worker 的 origin
    models: { fast: MODELS.fast, think: MODELS.think },
    error: ''
  };

  function stateOf() { return state; }

  function urlFor(path, base) {
    return (base === undefined ? state.base : base) + path;
  }

  /* 探一个基址的健康检查；成功返回解析后的 json，失败抛错 */
  function probe(base) {
    return fetch(urlFor(HEALTH, base), { method: 'GET' })
      .then(function (res) {
        if (!res.ok) throw fail('proxy', '代理返回 ' + res.status);
        return res.json();
      })
      .then(function (j) {
        if (!j || !j.ok) throw fail('proxy', '代理健康检查未通过');
        return j;
      });
  }

  /* 同源优先；同源不通且配了兜底地址时再试兜底。
     这一步同时决定了后续 generate() 往哪里发请求。 */
  function health() {
    var tried = state.base;
    return probe(tried).catch(function (firstErr) {
      if (tried !== '' || !FALLBACK_ORIGIN) throw firstErr;
      return probe(FALLBACK_ORIGIN).then(function (j) {
        state.base = FALLBACK_ORIGIN;
        return j;
      });
    }).then(function (j) {
      state.checked = true;
      state.ok = !!j.hasKey;
      state.hasKey = !!j.hasKey;
      if (j.models) state.models = j.models;
      state.error = state.hasKey ? '' : '代理已部署，但还没写入 ZHIPU_API_KEY';
      return state;
    }).catch(function (err) {
      state.checked = true;
      state.ok = false;
      state.error = FALLBACK_ORIGIN
        ? '同源和兜底代理都连不上，已切到离线模式'
        : '连不上同源代理 /api/health（纯静态主机不会提供 /api 路由，需要在 ai.js 里填 FALLBACK_ORIGIN）';
      throw err;
    });
  }

  /* ── 从模型输出里抠出 JSON ──────────────────────────
     JSON mode 下通常是干净 JSON，但 glm-4.7（深度思考）实测仍会带 ```json 围栏，
     所以这一步不能省。 */
  /* 模型经常把 shell 正则里的反斜杠直接写进 JSON 字符串，例如
        "command":"sed -i 's/console.log\(.*\)/\/\/&/g' src/*.js"
     而 JSON 只认 \" \\ \/ \b \f \n \r \t \uXXXX —— `\(` 不是合法转义，
     JSON.parse 会直接抛 "Bad escaped character"。
     这不是能靠提示词保证的事（实测 glm-4-flash 照样犯），所以这里做一层修复：
     把字符串里所有"非法转义"的单个反斜杠补成双反斜杠，让它成为字面反斜杠。
     ⚠️ 只在严格解析失败后才调用 —— 合法 JSON 一个字节都不动。 */
  function repairJsonEscapes(raw) {
    var out = '', inStr = false;
    for (var i = 0; i < raw.length; i++) {
      var c = raw.charAt(i);
      if (!inStr) {
        if (c === '"') inStr = true;
        out += c;
        continue;
      }
      if (c === '"') { inStr = false; out += c; continue; }
      if (c !== '\\') { out += c; continue; }

      var n = raw.charAt(i + 1);
      if (n === '') { out += '\\\\'; continue; }                 // 末尾孤零零一个反斜杠
      if (n === 'u' && /^[0-9a-fA-F]{4}$/.test(raw.substr(i + 2, 4))) {
        out += raw.substr(i, 6); i += 5; continue;               // \uXXXX 保留
      }
      if ('"\\/bfnrt'.indexOf(n) >= 0) { out += c + n; i++; continue; }  // 合法转义保留
      out += '\\\\' + n; i++;                                     // 非法 → 补成字面反斜杠
    }
    return out;
  }

  function extractJson(text) {
    if (typeof text !== 'string') return null;
    var s = text.trim();
    var fence = s.match(/```(?:json)?\s*([\s\S]*?)```/i);
    if (fence) s = fence[1].trim();
    var start = s.indexOf('{');
    if (start < 0) return null;
    var depth = 0, inStr = false, esc = false;
    for (var i = start; i < s.length; i++) {
      var c = s[i];
      if (inStr) {
        if (esc) esc = false;
        else if (c === '\\') esc = true;
        else if (c === '"') inStr = false;
        continue;
      }
      if (c === '"') { inStr = true; continue; }
      if (c === '{') depth++;
      else if (c === '}') {
        depth--;
        if (depth === 0) {
          var slice = s.slice(start, i + 1);
          try { return JSON.parse(slice); }
          catch (e) {
            try { return JSON.parse(repairJsonEscapes(slice)); }
            catch (e2) { return null; }
          }
        }
      }
    }
    return null;
  }

  function fail(kind, message) {
    var e = new Error(message);
    e.kind = kind;
    return e;
  }

  /* 新结构的 risk_level 与旧结构（以及我们内部的）风险词汇之间的映射 */
  var RISK_LEVEL_MAP = { low: 'safe', medium: 'caution', high: 'danger' };
  var RISK_WORDS = ['safe', 'caution', 'danger'];

  function normalizeRisk(v) {
    if (typeof v !== 'string') return '';
    var s = v.trim().toLowerCase();
    if (RISK_LEVEL_MAP[s]) return RISK_LEVEL_MAP[s];
    if (RISK_WORDS.indexOf(s) >= 0) return s;
    return '';
  }

  /* ── 校验并规整成前端渲染需要的形状 ────────────────
     同时接受规格里的新结构 {command, segments[], risk_level, risk_note}
     和历史结构 {cmd, anno[], risk, why}——模型偶尔会串，两种都收。 */
  function normalize(raw, query, opts) {
    opts = opts || {};
    var needAnno = opts.requireAnno !== false;
    var obj = typeof raw === 'string' ? extractJson(raw) : raw;
    if (!obj || typeof obj !== 'object') throw fail('format', '模型没有返回合法 JSON');

    var cmd = typeof obj.command === 'string' ? obj.command
      : (typeof obj.cmd === 'string' ? obj.cmd : '');
    cmd = cmd.trim().replace(/\s*\n\s*/g, ' ').replace(/^```[a-z]*\s*|\s*```$/g, '');
    if (!cmd) throw fail('format', '返回结果里没有 command 字段');

    var risk = normalizeRisk(obj.risk_level) || normalizeRisk(obj.risk) || 'caution';
    var riskNote = typeof obj.risk_note === 'string' ? obj.risk_note.trim()
      : (typeof obj.why === 'string' ? obj.why.trim() : '');

    /* segments（新）与 anno（旧）统一成 anno。
       只保留能在命令里逐字定位、且互不重叠的段，避免高亮错位。
       重叠过滤放在数据层而不是只放在渲染层：否则会留下"有解释条目、
       却一行都渲染不出来"的空壳，界面就会开天窗。 */
    var rawSegs = Array.isArray(obj.segments) ? obj.segments
      : (Array.isArray(obj.anno) ? obj.anno : []);
    var anno = [];
    var used = [];
    rawSegs.forEach(function (a) {
      if (!a || typeof a !== 'object') return;
      var part = typeof a.part === 'string' ? a.part
        : (typeof a.t === 'string' ? a.t : '');
      if (!part) return;
      var start = cmd.indexOf(part);
      if (start < 0) return;                       // 定位不到就丢掉，不要污染高亮
      var end = start + part.length;
      for (var k = 0; k < used.length; k++) {
        if (start < used[k][1] && end > used[k][0]) return;   // 与已接受的区间重叠
      }
      used.push([start, end]);
      var label = typeof a.label === 'string' ? a.label.trim()
        : (typeof a.short === 'string' ? a.short.trim() : '');
      if (!label) {
        /* 模型没给短标签就从解释里截一个，保证节点卡片有标题可显示 */
        var ex = typeof a.explanation === 'string' ? a.explanation
          : (typeof a.n === 'string' ? a.n : '');
        label = ex.replace(/[，。；：、,.;:]/g, ' ').trim().split(/\s+/)[0] || part;
        if (label.length > 8) label = label.slice(0, 8);
      }
      anno.push({
        t: part,
        short: label,
        n: (typeof a.explanation === 'string' ? a.explanation
          : (typeof a.n === 'string' ? a.n : '')).trim()
      });
    });
    anno.sort(function (x, y) { return cmd.indexOf(x.t) - cmd.indexOf(y.t); });
    if (needAnno && !anno.length) throw fail('format', '逐段解释为空，或全部无法在命令里定位');

    var see = Array.isArray(obj.see) ? obj.see.filter(function (c) {
      return typeof c === 'string' && c.trim();
    }).slice(0, 3) : [];

    var result = {
      q: query,
      cmd: cmd,
      flow: typeof obj.flow === 'string' ? obj.flow.trim() : '',
      risk: risk,
      why: riskNote || '模型未给出风险说明。',
      anno: anno,
      see: see,
      source: 'ai'
    };

    return enforceSafety(result);
  }

  /* 命令本身的危险特征不采信模型自述，直接升级等级 */
  function enforceSafety(result) {
    for (var i = 0; i < DANGER_PATTERNS.length; i++) {
      var p = DANGER_PATTERNS[i];
      var hit = p.test ? p.test(result.cmd) : p.re.test(result.cmd);
      if (!hit) continue;
      result.risk = 'danger';
      result.safety = p.why;
      if (result.why.indexOf(p.why) < 0) result.why = p.why + '。' + result.why;
      break;
    }
    return result;
  }

  function httpError(status, bodyText) {
    var detail = '';
    try {
      var j = JSON.parse(bodyText);
      detail = (j.error && (j.error.message || j.error.code)) || j.message || '';
    } catch (e) { detail = String(bodyText || '').slice(0, 160); }
    if (status === 401 || status === 403) return fail('auth', '代理或上游拒绝了这个请求（密钥无效？）');
    if (status === 429) return fail('rate', '请求太频繁，稍后再试');
    if (status >= 500) return fail('server', '模型服务返回 ' + status + '，稍后再试');
    return fail('format', '请求失败 ' + status + (detail ? '：' + detail : ''));
  }

  /* ── 生成 ─────────────────────────────────────────────
   * opts.brief     极客终端模式：短提示词、少输出、更快
   * opts.thinking  深度思考：切到 glm-4.7，推理内容走 onReasoning
   * opts.repair    {cmd, code, err, attempt} 自纠错循环的第 N 次修正
   * handlers: onProgress({elapsed, chars, cmd}), onReasoning(text), onDone(item), onError(err)
   * 返回 { cancel }
   */
  function generate(query, handlers, opts) {
    opts = opts || {};
    handlers = handlers || {};
    var brief = opts.brief === true;
    var session = opts.session || function () {};   // 当前会话累积的上下文，可选

    var ctrl = window.AbortController ? new AbortController() : null;
    /* ⚠️ 自动超时。原来 AbortController 只用于"用户点取消"——
       Worker 一旦挂起（网络抖动、上游卡住），界面就会一直转圈，用户只能刷新。
       免费额度下 429 也不罕见，所以再配一层退避重试（见下）。 */
    var timedOut = false;
    var timeoutMs = opts.timeoutMs || (opts.thinking ? 60000 : 30000);
    var timer = ctrl ? setTimeout(function () {
      timedOut = true;
      try { ctrl.abort(); } catch (e) { }
    }, timeoutMs) : null;
    /* 定时器要在 generate 的作用域里清 —— 定义在外面会引用不到 timer（实测报 ReferenceError） */
    function clearTimer() { if (timer) { clearTimeout(timer); timer = null; } }
    var started = Date.now();
    var acc = '';
    var sentCmd = null;
    var reasoning = '';
    var settled = false;
    /* 调用凭证用的计数：首字节时刻与流式分片数。
       这不是给开发者看的日志，是要显示在结果卡上给评委看的——
       它回答的是"这到底是真·大模型生成，还是本地关键词匹配"。 */
    var firstByteMs = 0;
    var chunks = 0;
    /* 服务端回告的"我做了什么"（注入安全约束 / 裁剪上下文 / 用的哪个模型） */
    var serverMeta = null;

    var tick = setInterval(function () {
      if (settled) return;
      if (handlers.onProgress) {
        handlers.onProgress({
          elapsed: Date.now() - started,
          chars: acc.length,
          cmd: sentCmd,
          chunks: chunks,
          firstByteMs: firstByteMs,
          /* 原始输出的尾部：界面上实时滚动它，"正在流式接收"就成了看得见的事实 */
          tail: acc.slice(-200)
        });
      }
    }, 200);

    function finish(fn, arg) {
    clearTimer();   /* 无论成功还是失败，定时器都要清掉 */
      if (settled) return;
      settled = true;
      clearInterval(tick);
      if (fn) fn(arg);
    }

    function sniffCmd() {
      if (sentCmd !== null) return;
      var m = acc.match(/"command"\s*:\s*"((?:[^"\\]|\\.)*)"/) || acc.match(/"cmd"\s*:\s*"((?:[^"\\]|\\.)*)"/);
      if (!m) return;
      var value;
      try { value = JSON.parse('"' + m[1] + '"'); } catch (e) { return; }
      if (!value) return;
      sentCmd = value;
      if (handlers.onProgress) {
        handlers.onProgress({ elapsed: Date.now() - started, chars: acc.length, cmd: sentCmd });
      }
    }

    /* 自纠错循环：把上一条命令、真实报错、**以及沙箱实际支持的能力清单**一起喂回去。
       实测（scripts/find-loop-case.mjs）发现原来那版几乎修不好，两个原因：
         ① 模型不知道沙箱支持什么——报错只说"不支持这个语法"，
            没有告诉它"那支持什么"，于是它原样重复或只改皮毛；
         ② 提示词里没有禁止占位符，模型会写出 `rm -rf <cache_directory>` 这种
            带尖括号的模板——而"能直接粘贴执行"是这个作品的立身之本。
       所以这里做了三件事：附上能力清单、明确"不要重复"、并给一条**诚实的退路**
       （真做不到就返回最接近的替代命令并如实说明，不许为了通过而编造）。 */
    var userContent = query;
    if (opts.repair) {
      var r = opts.repair;
      userContent = '用户想做的事：' + query + '\n\n' +
        '你上一次给出的命令是：\n' + r.cmd + '\n\n' +
        '它在沙箱里执行失败了（退出码 ' + r.code + '），错误输出：\n' +
        String(r.err || '').slice(0, 600) + '\n\n' +
        (r.caps
          ? '【沙箱实际支持的全部命令与写法——你只能用这里列出的】\n' +
            String(r.caps).slice(0, 2000) + '\n\n'
          : '') +
        '请修正它，并严格遵守：\n' +
        '1. **不要重复上一条命令**——它已经被真实执行证明跑不通了。\n' +
        '2. 如果原命令用了上面清单里没有的命令、参数或语法' +
          '（例如 shell 的 while / for 循环、awk 的 if 与求和、grep 的 --include、' +
          'sed 的 a / i / y 脚本），就换成清单里有的基础命令组合' +
          '（管道 | 、重定向 > 、find 的 -exec / -delete 等）。\n' +
        '3. 命令里**不许出现占位符**（`<路径>`、`{文件}`、`xxx`、`your_file` 之类），' +
          '必须是能直接粘贴执行的完整命令。用户没给具体路径时，就用当前目录 . 或能推断出的路径。\n' +
        '4. 如果这件事**用沙箱支持的命令根本做不到**，就返回一条最接近、且能跑通的替代命令，' +
          '并在 risk_note 里如实写清"沙箱做不到什么"。**不要为了通过而编造。**\n' +
        '按要求返回同样的 JSON 结构。';
    }

    /* 组装消息：system + 对话历史 + 本次提问。
       多轮对话是"智能交互"最直观的一块——没有历史，用户问完
       「找出最大的 10 个文件」就没法接「那只要今天的呢」，
       产品立刻从"能对话的助手"退化成"一问答一题的表单"。
       只带最近的若干轮（服务端还会再裁一次），token 与延迟都受控。 */
    var sysBase = opts.analysis ? SYSTEM_PROMPT_ANALYST : (brief ? SYSTEM_PROMPT_SHORT : SYSTEM_PROMPT);
    /* 附上沙箱真实支持的命令清单（分析模式不带——它读的是日志，与命令清单无关） */
    var sysText = (!opts.analysis && SANDBOX_HELP)
      ? sysBase + '\n\n【沙箱实际支持的命令与写法——**只能用这里列出的**，不许发明其它命令或 shell 语法】\n' + SANDBOX_HELP
      : sysBase;
    var msgs = [{ role: 'system', content: sysText }];
    if (opts.history && opts.history.length) {
      for (var hi = 0; hi < opts.history.length; hi++) {
        var h = opts.history[hi];
        if (h && (h.role === 'user' || h.role === 'assistant') && typeof h.content === 'string' && h.content) {
          msgs.push({ role: h.role, content: h.content });
        }
      }
    }
    msgs.push({ role: 'user', content: userContent });

    var payload = {
      stream: true,
      temperature: opts.analysis ? 0.1 : 0.2,
      json: true,
      max_tokens: opts.thinking ? 1600 : (opts.analysis ? 1600 : (brief ? 500 : 1200)),
      messages: msgs
    };
    payload.turns = msgs.length;
    if (opts.thinking) payload.thinking = true;

    /* 429 退避重试：免费额度下限流不罕见，评委演示高峰撞上就直接失败。
       把"取响应"这一步单独包一层，后面的流式解析与归一化一字不动。
       1s → 2s → 4s，三次仍失败才如实报错。 */
    function fetchWithRetry(retriesLeft) {
      return fetch(urlFor(ENDPOINT), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
        signal: ctrl ? ctrl.signal : undefined
      }).then(function (res) {
        if (res.status === 429 && retriesLeft > 0) {
          var waitMs = 1000 * Math.pow(2, 3 - retriesLeft);
          if (handlers.onProgress) handlers.onProgress({ retryIn: waitMs, elapsed: Date.now() - started, chars: acc.length, chunks: chunks });
          return new Promise(function (r) { setTimeout(r, waitMs); }).then(function () {
            return fetchWithRetry(retriesLeft - 1);
          });
        }
        return res;
      });
    }
    fetchWithRetry(3).then(function (res) {
      if (!res.ok) {
        return res.text().then(function (t) { throw httpError(res.status, t); });
      }
      /* 读服务端回告的"我做了什么"——后端智能不该是隐形的。
         Worker 会告诉我们：注入了几条安全约束、裁掉了几条上下文、用的哪个模型。
         跨源读自定义头要求服务端显式 expose（Worker 里已设），否则这里是 null。 */
      try {
        serverMeta = {
          server: res.headers.get('X-NL2SH-Server') || '',
          trimmed: Number(res.headers.get('X-NL2SH-Trimmed') || 0) || 0,
          safety: res.headers.get('X-NL2SH-Safety') || '',
          model: res.headers.get('X-NL2SH-Model') || ''
        };
      } catch (e) { serverMeta = null; }
      if (!res.body || typeof res.body.getReader !== 'function') {
        return res.json().then(function (j) {
          var msg = j.choices && j.choices[0] && j.choices[0].message;
          if (msg && msg.content) consume(msg.content);
        });
      }
      var reader = res.body.getReader();
      var decoder = new TextDecoder('utf-8');
      var buf = '';

      function line(raw) {
        var s = raw.trim();
        if (!s || s.indexOf('data:') !== 0) return;
        var data = s.slice(5).trim();
        if (!data || data === '[DONE]') return;
        try {
          var j = JSON.parse(data);
          var delta = j.choices && j.choices[0] && (j.choices[0].delta || j.choices[0].message);
          if (!delta) return;
          /* 深度思考模式：glm-4.7 会先吐 reasoning_content，单独送给可折叠面板 */
          if (typeof delta.reasoning_content === 'string' && delta.reasoning_content) {
            reasoning += delta.reasoning_content;
            if (handlers.onReasoning) handlers.onReasoning(reasoning);
          }
          if (typeof delta.content === 'string' && delta.content) consume(delta.content);
        } catch (e) { /* 半包或心跳，跳过 */ }
      }

      function pump() {
        return reader.read().then(function (r) {
          if (r.done) {
            if (buf.trim()) line(buf);
            return;
          }
          buf += decoder.decode(r.value, { stream: true });
          var parts = buf.split('\n');
          buf = parts.pop();
          parts.forEach(line);
          return pump();
        });
      }
      return pump();
    }).then(function () {
      /* 分析模式：不复用 normalize（那套是给"命令卡片"用的）。
         这里只做结构兜底——模型偶尔会少字段、或把 findings 写成字符串数组，
         都宽容地收拾成渲染层能直接吃的形状。 */
      var item;
      if (opts.analysis) {
        var obj = extractJson(acc);
        if (!obj || typeof obj !== 'object') throw fail('format', '分析结果不是合法 JSON');
        var findings = Array.isArray(obj.findings) ? obj.findings : [];
        item = {
          kind: 'analysis',
          summary: typeof obj.summary === 'string' ? obj.summary.trim() : '',
          findings: findings.map(function (f) {
            if (typeof f === 'string') return { title: '', detail: f, level: 'low', cmd: '' };
            return {
              title: typeof f.title === 'string' ? f.title.trim() : '',
              detail: typeof f.detail === 'string' ? f.detail.trim() : '',
              level: normalizeRisk(f.level) || 'caution',
              cmd: typeof f.cmd === 'string' ? f.cmd.trim() : ''
            };
          }).filter(function (f) { return f.detail || f.title; }).slice(0, 6),
          next: (Array.isArray(obj.next) ? obj.next : [])
            .filter(function (x) { return typeof x === 'string' && x.trim(); })
            .slice(0, 3),
          source: 'ai'
        };
        if (!item.summary && !item.findings.length) {
          throw fail('format', '分析结果里既没有结论也没有发现');
        }
      } else {
        item = normalize(acc, query, { requireAnno: !brief });
      }
      item.reasoning = reasoning;
      item.attempt = opts.repair ? (opts.repair.attempt || 1) : 0;
      /* 调用凭证：把"这确实是一次真实的大模型调用"变成界面上看得见的事实。
         模型名取自服务端 health 的回报（不是前端写死的字面量），
         端点也记下来 —— 这样"离线规则库"和"AI 实时生成"在界面上无法混淆。 */
      item.trace = {
        model: (state.models && (opts.thinking ? state.models.think : state.models.fast)) || MODELS.fast,
        endpoint: (state.base || '') + ENDPOINT,
        sameOrigin: !state.base,
        firstByteMs: firstByteMs,
        totalMs: Date.now() - started,
        chunks: chunks,
        chars: acc.length,
        thinking: !!opts.thinking,
        /* 服务端那一层做了什么。这是"后端智能"在界面上的落点——
           没有它，"后端智能突出"就只是一句架构描述。 */
        server: serverMeta
      };
      finish(handlers.onDone, item);
    }).catch(function (err) {
      if (err && err.name === 'AbortError') {
        /* 超时和"用户点了取消"是两回事，提示必须分开——
           否则用户会以为是自己点了什么，而实际是网络/上游卡住了。 */
        return finish(handlers.onError, timedOut
          ? fail('timeout', '模型响应超时（' + Math.round(timeoutMs / 1000) + 's），已切回离线规则库。')
          : fail('abort', '已取消'));
      }
      if (err && err.kind) return finish(handlers.onError, err);
      finish(handlers.onError, fail('network', '连不上同源代理 /api/chat，已切换到离线模式。'));
    });

    function consume(piece) {
      if (!firstByteMs) firstByteMs = Date.now() - started;
      chunks++;
      acc += piece;
      sniffCmd();
    }

    return {
      cancel: function () { if (ctrl) ctrl.abort(); }
    };
  }

  return {
    ENDPOINT: ENDPOINT,
    MODELS: MODELS,
    SYSTEM_PROMPT: SYSTEM_PROMPT,
    SYSTEM_PROMPT_SHORT: SYSTEM_PROMPT_SHORT,
    SYSTEM_PROMPT_ANALYST: SYSTEM_PROMPT_ANALYST,
    DANGER_PATTERNS: DANGER_PATTERNS,
    extractJson: extractJson,
    normalize: normalize,
    enforceSafety: enforceSafety,
    normalizeRisk: normalizeRisk,
    state: stateOf,
    health: health,
    generate: generate,
    /* 沙箱能力清单的注入点：由 app.js 在启动时把沙箱 help 的输出交进来 */
    setSandboxHelp: setSandboxHelp,
    fail: fail
  };
})();
