/* nl2sh · 单文件构建
 *
 * 把 index.html、样式和全部脚本内联成一个 HTML 文件。
 * 用途：
 *   · 有些免费主机 / 虚拟主机只给一个入口文件，不给目录
 *   · 需要把作品直接发给别人时，一个文件最省事
 *   · 评委用「另存为」就能离线留存一份可运行的副本
 *
 *     node scripts/build-single.mjs
 *   →  dist/nl2sh.html
 */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.join(path.dirname(fileURLToPath(import.meta.url)), '..');
const read = (p) => fs.readFileSync(path.join(root, p), 'utf8');

let html = read('index.html');
const order = [];
let inlinedBytes = 0;

/* 内联样式表（容忍属性顺序与其它属性） */
html = html.replace(/<link\b[^>]*\brel="stylesheet"[^>]*\bhref="([^"]+)"[^>]*>/g, (m, href) => {
  order.push(href);
  const css = read(href);
  inlinedBytes += Buffer.byteLength(css, 'utf8');
  return '<style>\n/* ' + href + ' */\n' + css + '\n</style>';
});

/* 内联脚本，保持原来的先后顺序。
   ⚠️ 这里踩过一次坑，别再改回去：原来的正则只认 `<script src="…">`，
   给标签加上 defer 之后一个都匹配不到，构建"成功"但产物只剩 50KB（脚本全丢），
   而当时的守卫用的是同一个正则，所以也没拦住。
   现在改成"有 src 就内联"（不管还有没有 defer/async/type 属性），
   守卫也不再依赖具体写法，而是去找"还有没有本地资源引用"。 */
html = html.replace(/<script\b[^>]*?\ssrc="([^"]+)"[^>]*?>\s*<\/script>/g, (m, src) => {
  order.push(src);
  const js = read(src).replace(/<\/script/gi, '<\\/script');
  inlinedBytes += Buffer.byteLength(js, 'utf8');
  return '<script>\n/* ' + src + ' */\n' + js + '\n</script>';
});

/* 守卫：任何指向本地文件的 src/href 都必须已经消失。
   外链（http/https/协议相对）、data:、页内锚点不算本地资源。
   这一条比"检查某个具体标签写法"可靠：换了写法也照样能兜住。 */
const leftover = (html.match(/(?:src|href)="(?!https?:|\/\/|data:|#|mailto:)([^"]*)"/g) || []);
if (leftover.length) {
  console.error('还有没被内联的本地资源，构建中止——否则单文件在离线时会缺东西：');
  leftover.slice(0, 10).forEach((x) => console.error('  · ' + x));
  process.exit(1);
}

/* 再兜一层：产物必须比内联进来的资源总和还大。
   光靠正则容易"看起来成功"，尺寸是最后一道便宜的保险。 */
if (order.length === 0 || Buffer.byteLength(html, 'utf8') < inlinedBytes) {
  console.error('构建结果可疑：内联了 ' + order.length + ' 个资源，共 ' +
    (inlinedBytes / 1024).toFixed(1) + 'KB，但产物只有 ' +
    (Buffer.byteLength(html, 'utf8') / 1024).toFixed(1) + 'KB。');
  process.exit(1);
}

const outDir = path.join(root, 'dist');
fs.mkdirSync(outDir, { recursive: true });

/* 输出名就叫 index.html：对象存储/虚拟主机上传后就是默认首页，不用再改名，
   也避免了"多文件版漏传 assets/ 导致白屏"这一类最容易发生的部署事故。 */
const outFile = path.join(outDir, 'index.html');
fs.writeFileSync(outFile, html, 'utf8');

const kb = (Buffer.byteLength(html, 'utf8') / 1024).toFixed(1);
console.log('已内联 ' + order.length + ' 个资源：');
order.forEach((f) => console.log('  · ' + f));
console.log('\n产物 dist/index.html   共 ' + kb + ' KB');
console.log('把它单独上传到任意对象存储 / 虚拟主机，访问根路径就能打开。');
console.log('（多文件版见仓库根目录的 index.html + assets/，适合看源码的场合）');
