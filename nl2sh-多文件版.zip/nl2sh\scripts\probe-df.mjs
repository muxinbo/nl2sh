/* df 数学不变量的探针：审计用它做回归守门 */
import fs from 'node:fs';
const assets = 'D:/dsh/downloads/nl2sh/assets';
globalThis.window = globalThis;
for (const f of ['sandbox-fixtures.js', 'sandbox-cmds.js', 'sandbox.js']) {
  new Function('window', fs.readFileSync(assets + '/' + f, 'utf8'))(globalThis);
}
const sb = globalThis.NL2SH_SANDBOX.createSession();
const bad = [];
for (const c of ['df -h', 'df']) {
  for (const line of String(sb.run(c).out || '').split('\n').filter(Boolean).slice(1)) {
    const p = line.trim().split(/\s+/);
    if (p.length < 6) continue;
    if (parseInt(p[4], 10) > 100) bad.push('[超100%] ' + line.trim());
    if (/^-/.test(p[3])) bad.push('[可用为负] ' + line.trim());
    if (/^-/.test(p[2])) bad.push('[已用为负] ' + line.trim());
  }
}
if (bad.length) { bad.forEach((b) => console.log(b)); process.exit(1); }
console.log('df -h 读数：' + String(sb.run('df -h').out).split('\n')[1].trim());
console.log('df -h tmpfs：' + String(sb.run('df -h').out).split('\n')[2].trim());