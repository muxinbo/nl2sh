#!/usr/bin/env node
/**
 * 把 作品说明.md 编译成可打印的 作品说明书.html（再用无头 Chrome 打成 PDF）。
 *
 * 为什么自己写这个而不是找 Markdown 库：
 *   全站零依赖是这条产品线的一贯约束，构建脚本也不该例外——
 *   `node scripts/build-single.mjs` 和这个脚本都只依赖 Node 内置模块，
 *   换台机器 clone 下来就能跑。
 *
 * 只实现这个文档实际用到的那一小撮语法，够用且可预测：
 *   标题 / 段落 / 表格 / 有序与无序列表 / 围栏代码块 / 引用 / 分隔线
 *   行内：**粗体**、`代码`、[链接](url)
 */
import fs from 'node:fs';
import path from 'node:path';

const root = path.resolve(import.meta.dirname, '..');
const src = path.join(root, '作品说明.md');
const outDir = path.join(root, 'dist');
const outFile = path.join(outDir, '作品说明书.html');

const md = fs.readFileSync(src, 'utf8').replace(/\r\n/g, '\n');

/* ── 行内标记 ─────────────────────────────────────────── */
function esc(s) {
  return String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
}

function inline(s) {
  let t = esc(s);
  /* 代码要先处理：里面的 ** 和 [] 不该被当成标记 */
  const codes = [];
  t = t.replace(/`([^`]+)`/g, (m, c) => {
    codes.push(c);
    return '\u0000' + (codes.length - 1) + '\u0000';
  });
  t = t.replace(/\[([^\]]+)\]\(([^)]+)\)/g, (m, text, url) => '<a href="' + url + '">' + text + '</a>');
  t = t.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');
  t = t.replace(/\u0000(\d+)\u0000/g, (m, i) => '<code>' + codes[Number(i)] + '</code>');
  return t;
}

/* ── 块级解析 ─────────────────────────────────────────── */
function parse(md) {
  const lines = md.split('\n');
  const blocks = [];
  let i = 0;

  function flushPara(buf) {
    if (buf.length) {
      blocks.push({ t: 'p', html: inline(buf.join(' ')) });
      buf.length = 0;
    }
  }

  const para = [];
  while (i < lines.length) {
    const line = lines[i];

    /* 围栏代码块 */
    if (/^```/.test(line)) {
      flushPara(para);
      const body = [];
      i++;
      while (i < lines.length && !/^```/.test(lines[i])) body.push(lines[i++]);
      i++;
      blocks.push({ t: 'pre', html: esc(body.join('\n')) });
      continue;
    }

    /* 分隔线 */
    if (/^---+\s*$/.test(line)) {
      flushPara(para);
      blocks.push({ t: 'hr' });
      i++;
      continue;
    }

    /* 标题 */
    const h = line.match(/^(#{1,4})\s+(.*)$/);
    if (h) {
      flushPara(para);
      blocks.push({ t: 'h' + h[1].length, html: inline(h[2].trim()) });
      i++;
      continue;
    }

    /* 引用 */
    if (/^>\s?/.test(line)) {
      flushPara(para);
      const body = [];
      while (i < lines.length && /^>\s?/.test(lines[i])) body.push(lines[i++].replace(/^>\s?/, ''));
      blocks.push({ t: 'quote', html: inline(body.join(' ')) });
      continue;
    }

    /* 表格：表头 + 分隔行 + 数据行 */
    if (/^\|/.test(line) && /^\|[\s:|-]+\|\s*$/.test(lines[i + 1] || '')) {
      flushPara(para);
      const cells = (l) => l.replace(/^\||\|$/g, '').split('|').map((c) => c.trim());
      const head = cells(line);
      i += 2;
      const rows = [];
      while (i < lines.length && /^\|/.test(lines[i])) rows.push(cells(lines[i++]));
      blocks.push({
        t: 'table',
        head,
        rows
      });
      continue;
    }

    /* 列表（有序 / 无序，不嵌套——本文档没用到嵌套） */
    if (/^\s*([-*]|\d+\.)\s+/.test(line)) {
      flushPara(para);
      const ordered = /^\s*\d+\.\s+/.test(line);
      const items = [];
      while (i < lines.length && /^\s*([-*]|\d+\.)\s+/.test(lines[i])) {
        let item = lines[i++].replace(/^\s*([-*]|\d+\.)\s+/, '');
        /* 列表项的续行（缩进 2 空格以上且不是新条目） */
        while (i < lines.length && /^\s{2,}\S/.test(lines[i]) && !/^\s*([-*]|\d+\.)\s+/.test(lines[i])) {
          item += ' ' + lines[i++].trim();
        }
        items.push(inline(item));
      }
      blocks.push({ t: 'list', ordered, items });
      continue;
    }

    /* 空行 */
    if (!line.trim()) {
      flushPara(para);
      i++;
      continue;
    }

    para.push(line.trim());
    i++;
  }
  flushPara(para);
  return blocks;
}

/* ── 渲染 ─────────────────────────────────────────────── */
function renderBlock(b) {
  switch (b.t) {
    case 'p': return '<p>' + b.html + '</p>';
    case 'pre': return '<pre>' + b.html + '</pre>';
    case 'hr': return '<hr>';
    case 'quote': return '<blockquote>' + b.html + '</blockquote>';
    case 'h1': return '<h1 class="doc-h1">' + b.html + '</h1>';
    case 'h2': return '<h2>' + b.html + '</h2>';
    case 'h3': return '<h3>' + b.html + '</h3>';
    case 'h4': return '<h4>' + b.html + '</h4>';
    case 'list': {
      const tag = b.ordered ? 'ol' : 'ul';
      return '<' + tag + '>' + b.items.map((x) => '<li>' + x + '</li>').join('') + '</' + tag + '>';
    }
    case 'table':
      return '<table><thead><tr>' + b.head.map((c) => '<th>' + inline(c) + '</th>').join('') +
        '</tr></thead><tbody>' +
        b.rows.map((r) => '<tr>' + r.map((c) => '<td>' + inline(c) + '</td>').join('') + '</tr>').join('') +
        '</tbody></table>';
    default: return '';
  }
}

const blocks = parse(md);

/* 分页结构：
     · 第一个 h2 之前 = 封面
     · `## 目录` 那一节 = 目录页（用文档自带的，它带锚点链接，不再另生成一份）
     · 其后的每个 h2 起一页
   一开始这里犯过重复：既渲染了 Markdown 里的目录，又生成了一份，PDF 里出现两页目录。 */
const h2Idx = blocks.map((b, i) => (b.t === 'h2' ? i : -1)).filter((i) => i >= 0);
const tocIdx = blocks.findIndex((b) => b.t === 'h2' && /目录/.test(b.html.replace(/<[^>]+>/g, '')));
const firstSection = tocIdx >= 0
  ? (h2Idx.find((i) => i > tocIdx) ?? blocks.length)
  : h2Idx[0];

const cover = blocks.slice(0, tocIdx >= 0 ? tocIdx : h2Idx[0]);
const tocBlocks = tocIdx >= 0 ? blocks.slice(tocIdx, firstSection) : [];
const rest = blocks.slice(firstSection);

/* 封面要自己拼：标题、副标题、元信息表、引言各就各位。
   之前这里把 H1 从封面里 filter 掉却没补回去，结果打出来的封面没有标题。 */
const h1Block = cover.find((b) => b.t === 'h1');
const coverBody = cover.filter((b) =>
  b.t !== 'h1' && !(b.t === 'p' && /^作品说明书$/.test(b.html.replace(/<[^>]+>/g, ''))));

/* 按 h2 切页 */
const pages = [];
let cur = null;
rest.forEach((b) => {
  if (b.t === 'h2') {
    cur = [b];
    pages.push(cur);
  } else if (cur) {
    cur.push(b);
  }
});

const html = `<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<title>NL2SH · 作品说明书</title>
<style>
  @page { size: A4; margin: 15mm 14mm 14mm; }
  * { box-sizing: border-box; }
  body {
    margin: 0;
    font: 10pt/1.7 "Microsoft YaHei", "PingFang SC", "Hiragino Sans GB", sans-serif;
    color: #1b1b1b;
    background: #fff;
    -webkit-print-color-adjust: exact;
    print-color-adjust: exact;
  }
  a { color: #0a6b7a; text-decoration: none; border-bottom: 1px solid #a8d8e0; }

  /* ── 封面 ── */
  .cover { padding-top: 52mm; page-break-after: always; }
  .cover__eyebrow {
    font: 600 9.5pt/1.6 ui-monospace, Consolas, monospace;
    letter-spacing: .22em; color: #6b7c85; text-transform: uppercase;
  }
  .cover h1 {
    margin: 14px 0 6px;
    font-size: 27pt; line-height: 1.28; letter-spacing: -.01em; color: #10272e;
  }
  .cover__sub { margin: 0 0 26px; font-size: 13pt; color: #0a6b7a; letter-spacing: .3em; }
  .cover__rule { width: 64px; height: 3px; background: #89dceb; margin: 0 0 26px; }
  .cover blockquote {
    margin: 22px 0 0; padding: 12px 16px;
    border-left: 3px solid #a6e3a1; background: #f5faf6;
    font-size: 11pt; color: #2c4148;
  }
  .cover__foot {
    margin-top: 46mm; padding-top: 10px; border-top: 1px solid #dbe4e7;
    font: 500 9pt/1.7 ui-monospace, Consolas, monospace; color: #7b8b93;
  }

  /* ── 目录 ── */
  .toc { page-break-after: always; }
  .toc h2 { page-break-before: avoid; margin-top: 0; }
  .toc ol { padding-left: 20px; }
  .toc li { margin: 5px 0; font-size: 11pt; }

  /* ── 正文 ──
     刻意"不"给每章强制分页：12 章各自起新页会白白吃掉五六页半页空白，
     文档一下就冲到 20 页。让它自然流动，只在标题前置留白，页数才落在 10 页量级。 */
  h2 {
    margin: 22px 0 13px; padding-bottom: 7px;
    font-size: 15pt; color: #0a6b7a;
    border-bottom: 2px solid #89dceb;
    page-break-after: avoid;
  }
  .page:first-of-type > h2 { margin-top: 0; }
  h3 { margin: 17px 0 7px; font-size: 11.5pt; color: #12414c; page-break-after: avoid; }
  h4 { margin: 14px 0 5px; font-size: 10.5pt; color: #12414c; page-break-after: avoid; }
  .doc-h1 { font-size: 20pt; margin: 0 0 10px; }

  p { margin: 0 0 8px; }
  ul, ol { margin: 0 0 9px; padding-left: 22px; }
  li { margin: 2.5px 0; }
  li > p { margin: 0; }

  table {
    width: 100%; border-collapse: collapse; margin: 9px 0 12px;
    font-size: 8.4pt; page-break-inside: avoid;
  }
  th, td { border: 1px solid #cfdde1; padding: 4px 6px; text-align: left; vertical-align: top; line-height: 1.58; }
  th { background: #eef7f9; font-weight: 600; color: #12414c; }
  tr:nth-child(even) td { background: #fafcfd; }

  pre {
    margin: 9px 0 12px; padding: 8px 11px;
    background: #f5f8f9; border-left: 3px solid #89dceb; border-radius: 3px;
    font: 8.2pt/1.58 ui-monospace, Consolas, "Courier New", monospace;
    white-space: pre-wrap; overflow-wrap: anywhere;
    page-break-inside: avoid;
  }
  code {
    padding: .5px 3.5px; background: #eff3f5; border-radius: 3px;
    font: 8.6pt/1.5 ui-monospace, Consolas, monospace; color: #0c4a56;
  }
  pre code { background: none; padding: 0; font-size: inherit; color: inherit; }

  blockquote {
    margin: 9px 0 12px; padding: 7px 13px;
    border-left: 3px solid #a6e3a1; background: #f6fbf7; color: #2c4148;
  }
  hr { border: none; border-top: 1px solid #dbe4e7; margin: 14px 0; }
  strong { color: #10272e; }
</style>
</head>
<body>
<div class="cover">
  <p class="cover__eyebrow">GDUST Linux 协会 · AI 网页设计大赛 · 赛道三：智能交互与应用</p>
  <h1>${h1Block ? h1Block.html.replace(/^NL2SH\s*·\s*/, 'NL2SH ·<br>') : 'NL2SH'}</h1>
  <p class="cover__sub">作品说明书</p>
  <div class="cover__rule"></div>
  ${coverBody.map(renderBlock).join('\n  ')}
  <p class="cover__foot">2026 年 10 月 · 第二届网页 AI 设计大赛 · 赛道三：智能交互与应用</p>
</div>
${tocBlocks.length ? '<div class="toc">\n  ' + tocBlocks.map(renderBlock).join('\n  ') + '\n</div>' : ''}
${pages.map((p) => '<section class="page">\n  ' + p.map(renderBlock).join('\n  ') + '\n</section>').join('\n')}
</body>
</html>`;

fs.mkdirSync(outDir, { recursive: true });
fs.writeFileSync(outFile, html, 'utf8');

const kb = (Buffer.byteLength(html, 'utf8') / 1024).toFixed(1);
console.log('已生成 作品说明书.html   ' + kb + ' KB');
console.log('  封面 1 页 + 目录 1 页 + 正文 ' + pages.length + ' 页（按二级标题分页）');
console.log('  表格 ' + blocks.filter((b) => b.t === 'table').length +
  ' 个 · 代码块 ' + blocks.filter((b) => b.t === 'pre').length +
  ' 个 · 列表 ' + blocks.filter((b) => b.t === 'list').length + ' 个');
console.log('\n下一步：用无头 Chrome 打成 PDF（scripts/make-pdf.ps1），或直接在浏览器里 Ctrl+P → 另存为 PDF。');
