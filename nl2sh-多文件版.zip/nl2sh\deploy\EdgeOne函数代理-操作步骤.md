# 方案 B 操作手册 · 把模型代理搬到 EdgeOne（国内可直连）

> **这份手册解决的是最要命的那条**：实测 `*.workers.dev` 在大陆被 DNS 污染——
> `curl https://nl2sh-api.zibochen82.workers.dev/api/health` 21 秒超时零响应，
> DNS 解析返回 Facebook / Dropbox 的 IP。同一台机器浏览器能通，只是因为走了系统代理。
>
> **评委的校园网大概率没有代理。** 那样他看到的是「离线模式」，
> 赛道三最核心的那条评分点「AI 功能的技术实现与集成度」**一点都看不到**。
>
> 所以这不是优化项，是保命项。

---

## 先想清楚：要解决的是"两个东西都不可达"

| 东西 | 现在的地址 | 国内情况 |
|---|---|---|
| 静态页 | `muxinbo.github.io/nl2sh/` | ❌ 不稳（GitHub 全站在部分网络直接解析失败） |
| 模型代理 | `nl2sh-api.zibochen82.workers.dev` | ❌ **DNS 被污染**（实测） |

**两个都要换。** 只换一个，另一个还是断的。

本手册给出的组合是：

```
EdgeOne Pages（国内节点，免费）
├─ 静态站：index.html              →  https://你的名字.edgeone.dev/
└─ Cloud Function：/api/health、/api/chat  →  同一个域
```

**同域的好处是实打实的**：前端本来就优先请求同源 `/api/chat`，
同域之后**不需要 FALLBACK_ORIGIN、不需要跨源、没有预检**——
少一个域名，就少一个失败点。

---

## 目录里已经准备好的东西

本手册配套的代码在 `deploy/edgeone-functions/`：

```
deploy/edgeone-functions/
├─ cloud-functions/api/[[default]].js   ← 代理本体（Node + Express）
└─ package.json                         ← 依赖 express
```

`[[default]].js` 里的服务端加固那几段（安全约束注入、危险意图识别、上下文裁剪、限流阈值）
与 `worker/worker.js` **逐字相同**——而且 `scripts/audit.mjs` 里有一条检查会**逐字比对两份**，
一旦哪边被改过就红。**不靠"记得同步"。**

---

## 操作步骤

### 第 1 步：建项目、传静态页（约 3 分钟）

1. 打开 <https://pages.edgeone.ai/zh/drop>（腾讯云账号登录，你之前为 COS 注册过那个）
2. 新建一个空文件夹，把 `dist/index.html` **复制**进去
   - ⚠️ **只放这一个文件**。不要传整个 `dist/`（那里面还有 PDF、zip，评委会在根目录看到一堆无关文件）
3. **拖那个文件夹**进上传区（不是拖文件）
4. 起一个好记的子域名，例如 `nl2sh`
5. 等它上线，**先记下正式域名**（形如 `xxx.edgeone.dev`；以控制台显示的为准）

> 这一步做完，静态页就国内可达了。**先把这一步做完再说代理**——
> 它本身就能让评委打开作品，即使 AI 还没接上。

### 第 2 步：把代理作为 Cloud Function 挂上去

EdgeOne Pages 支持两种上传方式，选一种：

**方式一：控制台直接上传（不用命令行）**

在项目里新建 Cloud Function，把 `deploy/edgeone-functions/cloud-functions/api/[[default]].js`
的内容粘进去（若控制台要求目录结构，就按 `cloud-functions/api/` 建）。

**方式二：走 Git（推荐，改动可追溯）**

把 `deploy/edgeone-functions/` 的内容推到一个仓库，在 EdgeOne Pages 里
「导入 Git 仓库」，构建命令填 `edgeone pages build`（`package.json` 里已经配好）。

### 第 3 步：配环境变量（密钥落点）

在项目的**环境变量**里加一条：

| 名称 | 值 |
|---|---|
| `ZHIPU_API_KEY` | 你的智谱 key（和 Cloudflare Worker 里那个同一个） |

> 密钥只存在 EdgeOne 的服务端环境变量里，**前端依然没有**。
> 这一步做完，"密钥零泄露"这个结论不变。

### 第 4 步：验证代理（这一步不能省）

浏览器直接打开（把域名换成你的）：

```
https://你的名字.edgeone.dev/api/health
```

**期望**：返回 `{"ok":true,"hasKey":true,"models":{...},"via":"edgeone-pages-function"}`

- 返回 `hasKey:false` → 环境变量没生效，回第 3 步
- 返回 404 → 函数的挂载路径不对。看控制台显示的实际路径，
  把 `[[default]].js` 里的 `app.get('/health')` / `app.post('/chat')` 改成对应的相对路径
  （**这是本手册唯一需要你现场确认的地方**，因为挂载前缀由平台决定）
- 返回 500 → 看函数日志

### 第 5 步：让前端用上它

前端**本来就优先请求同源 `/api/chat`**，所以同域部署之后**什么都不用改**。

如果函数没能挂在同域（比如你只部署了静态页），那就把前端里的兜底域改掉：

```js
// assets/ai.js 里搜 FALLBACK_ORIGIN
var FALLBACK_ORIGIN = 'https://你的名字.edgeone.dev';
```

改完重新构建单文件产物：

```bash
node scripts/build-single.mjs
node scripts/sync-delivery.mjs      # 它会断言产物是单文件版，别手工复制
```

### 第 6 步：在 EdgeOne 控制台加一条限流（建议）

函数里的限流是"尽力而为"（实例会被回收）。真正的防线在控制台：
给 `/api/chat` 加一条速率限制规则，例如 **20 次/分钟/IP**——
和 `LIMITS` 里的数字保持一致。

---

## 验证清单（**必须用没挂代理的手机流量测**）

这一步我替不了你：**我这边所有网络检查都走系统代理，测不出真实评委的处境。**

用手机**关掉 WiFi、只开流量**，逐条打勾：

- [ ] 打开静态站，**不是**下载文件、不是 404
- [ ] 首屏顶栏显示 **「AI 已接入 · glm-4-flash」**（不是「离线模式」）
- [ ] 输入一句中文回车 → 命令**几秒内出现**，且结果卡顶部有「AI 调用凭证」
- [ ] 凭证里的**端点**是你那个 `edgeone.dev` 域名（不是 workers.dev）
- [ ] 点「开始分析」→ 能跑出日志分析结果
- [ ] 点「走一遍自验证闭环」→ 四阶段流程条亮起

**任何一条不过，先别交表。**

---

## 出问题自查

| 现象 | 原因 | 怎么办 |
|---|---|---|
| `/api/health` 返回 404 | 函数挂载路径不是 `/api/*` | 看控制台显示的实际路径，改 `[[default]].js` 里的相对路径 |
| `hasKey:false` | 环境变量没生效或名字拼错 | 检查是否叫 `ZHIPU_API_KEY`，改完要重新部署 |
| 页面显示「离线模式」但 `/api/health` 正常 | 前端还在用旧的兜底域 | 改 `FALLBACK_ORIGIN`（第 5 步）并重新构建 |
| 流式变成了"一次性出现" | 中间层把响应缓冲了 | 确认响应头带 `Cache-Control: no-cache, no-transform` 与 `X-Accel-Buffering: no` |
| 429 | 限流生效了 | 等一分钟；或确认第 6 步的阈值没设得太小 |
| 手机能开、电脑不能 | 电脑的 hosts/DNS 有污染记录 | 换网络重试；这不代表评委打不开 |

---

## 两个诚实的提醒

1. **EdgeOne 的 `*.edgeone.dev` 域名本身我无法在这里实测可达性**（我这边走代理）。
   所以第 4 步和第 6 步的"手机流量验证"不是形式，是**唯一**的确认手段。

2. **不要把这份函数当成 Cloudflare Worker 的自动替代**：
   两边的加固逻辑是同一份（有审计盯着），但**运行环境不同**——
   EdgeOne 的函数实例会被回收，所以那边必须靠控制台的限流规则兜底。
