/* nl2sh · 模型层自测（不联网）
 *
 * 覆盖四件最容易出错、又最难在界面上看出来的逻辑：
 *   · 从模型输出里抠 JSON（带围栏、带前后废话、字符串里含花括号）
 *   · 规格新结构 {command, segments[], risk_level, risk_note} 的归一化与容错
 *   · 安全改判：模型说 low 的危险命令必须被升级成 danger
 *   · 请求契约：同源 /api/chat、JSON mode 必开、前端绝不携带密钥
 *
 *     node scripts/ai-test.mjs
 */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const assets = path.join(here, '..', 'assets');

/* ai.js 只依赖 window 上的 AbortController / TextDecoder 之类的全局能力，
   在 Node 里直接给个 window 壳就能加载。注意：它已经不再碰 localStorage 了。 */
globalThis.window = globalThis;
const AI_SRC = fs.readFileSync(path.join(assets, 'ai.js'), 'utf8');
new Function('window', AI_SRC)(globalThis);
const AI = globalThis.window.NL2SH_AI;

let pass = 0, fail = 0;
const failures = [];
function check(name, cond, detail) {
  if (cond) { pass++; console.log('  ok   ' + name); }
  else {
    fail++; failures.push(name);
    console.log('  FAIL ' + name + (detail !== undefined ? '\n       → ' + detail : ''));
  }
}
function section(t) { console.log('\n' + t); }

/* ── 测试用的模型回答（规格里的新结构）─────────────── */
const GOOD = {
  command: "find . -name '*.tmp' -delete",
  segments: [
    { part: 'find .', label: '递归查找', explanation: '从当前目录开始递归查找' },
    { part: "-name '*.tmp'", label: '后缀', explanation: '按文件名匹配' },
    { part: "name '*.tmp' -delete", label: '重复', explanation: '这条和上一条重叠，应被丢弃' },
    { part: '不存在的片段', label: '无效', explanation: '在命令里定位不到，应被丢弃' },
    { part: '-delete', label: '删除', explanation: '对每个结果执行删除' }
  ],
  risk_level: 'high',
  risk_note: '直接删除文件，不进回收站',
  flow: '递归查找 → 逐个删除',
  see: ['find . -name "*.tmp" -print', '', 'find . -name "*.tmp" -mtime +30 -delete', '第四条应被截断', '第五条也应被截断']
};

/* ── 从模型输出里抠 JSON ─────────────────────────────── */
section('从模型输出里抠 JSON');

{
  const fenced = '```json\n' + JSON.stringify(GOOD) + '\n```';
  check('能剥掉 markdown 代码围栏（glm-4.7 实测仍会带围栏）', !!AI.extractJson(fenced));
  check('能跳过前后废话',
    !!AI.extractJson('好的，我来分析一下。\n' + JSON.stringify(GOOD) + '\n希望有帮助。'));
  const tricky = { command: 'echo "}"' };
  check('字符串里的花括号不会让配平提前结束',
    (AI.extractJson(JSON.stringify(tricky)) || {}).command === 'echo "}"',
    JSON.stringify(AI.extractJson(JSON.stringify(tricky))));
  check('完全不是 JSON 时返回 null', AI.extractJson('我无法完成这个请求') === null);
  check('半截 JSON 返回 null', AI.extractJson('{"command":"ls"') === null);
}

/* ── 非法转义修复 ──────────────────────────────────────
   这一组全部来自**真机实测**：部署后拿真实问句打 glm-4-flash，
   它把 shell 正则里的 \( \) 直接写进了 JSON 字符串，JSON.parse 当场报
   "Bad escaped character"，界面上什么都出不来。
   离线测试用手写的合法 JSON 永远照不出这个问题——所以把它固化成用例。 */
section('模型写坏 JSON 转义时的修复');

{
  /* 这是模型真实吐回来的原文（节选），一个字节都没改 */
  const realBroken = '{\n"command":"sed -i \'s/console.log\\(.*\\)/\\/\\/&/g\' src/**/*.js",\n' +
    '"segments":[{"part":"sed -i","label":"sed","explanation":"流编辑器"}],\n' +
    '"risk_level":"medium","risk_note":"会修改文件内容"}';
  const fixed = AI.extractJson(realBroken);
  check('模型把 shell 正则写进 JSON（\\( \\)）时仍能解析出来', !!fixed,
    'parse 结果：' + JSON.stringify(fixed));
  check('非法转义 \\( \\) 被补成字面反斜杠（否则 sed 的正则就废了）',
    !!fixed && fixed.command.indexOf('\\(.*\\)') > 0,
    fixed ? JSON.stringify(fixed.command) : '(null)');

  /* 这一条是**故意钉住**的行为，不是缺陷掩盖：
     JSON 允许 \/ 且它等价于 /，所以模型写的 \/\/ 会还原成 //。
     我们不去猜"模型其实想要反斜杠"——一律改会误伤合法的转义写法。
     坏掉的命令交给产品自己的机制兜：沙箱真跑会失败，
     自验证闭环再把真实 sed 报错喂回模型让它改（最多 3 轮）。 */
  check('\\/ 按 JSON 语义还原成 /（合法转义不动它），剩下的交给沙箱闭环去纠',
    !!fixed && fixed.command.indexOf('///&') > 0,
    fixed ? JSON.stringify(fixed.command) : '(null)');

  /* 合法 JSON 必须一个字节都不动：严格能解析时不允许走修复分支 */
  const keepQuote = '{"command":"echo \\"hi\\"","risk_level":"low"}';
  check('合法的 \\" 不被重复转义',
    (AI.extractJson(keepQuote) || {}).command === 'echo "hi"',
    JSON.stringify((AI.extractJson(keepQuote) || {}).command));

  const keepNewline = '{"command":"a\\nb","risk_level":"low"}';
  check('合法的 \\n 仍然解析成换行（不是字面反斜杠 n）',
    (AI.extractJson(keepNewline) || {}).command === 'a\nb',
    JSON.stringify((AI.extractJson(keepNewline) || {}).command));

  const keepSlash = '{"command":"a\\\\b","risk_level":"low"}';
  check('合法的 \\\\ 仍然是单个反斜杠',
    (AI.extractJson(keepSlash) || {}).command === 'a\\b',
    JSON.stringify((AI.extractJson(keepSlash) || {}).command));

  const keepUnicode = '{"command":"\\u4e2d\\u6587","risk_level":"low"}';
  check('合法的 \\uXXXX 仍然解析成对应字符',
    (AI.extractJson(keepUnicode) || {}).command === '中文',
    JSON.stringify((AI.extractJson(keepUnicode) || {}).command));

  /* 混合：一个合法转义 + 一个非法转义，两个都要对 */
  const mixed = '{"command":"grep -E \\\\d+ \\"f\\" \\\\(x\\\\)","risk_level":"low"}';
  const m = AI.extractJson(mixed);
  check('合法与非法转义混在一起时，各自处理正确',
    !!m && m.command === 'grep -E \\d+ "f" \\(x\\)',
    m ? JSON.stringify(m.command) : '(null)');
}

/* ── 新结构归一化 ────────────────────────────────────── */
section('新结构归一化（command / segments / risk_level / risk_note）');

{
  const item = AI.normalize(JSON.stringify(GOOD), '删除 .tmp');
  check('command 映射到 cmd', item.cmd === "find . -name '*.tmp' -delete", item.cmd);
  check('risk_level=high 映射成内部 danger', item.risk === 'danger', item.risk);
  check('risk_note 映射到 why', item.why.indexOf('回收站') >= 0, item.why);
  check('segments 里重叠的一段被丢弃', item.anno.length === 3, 'got ' + item.anno.length);
  check('segments 里定位不到的一段被丢弃',
    item.anno.every((a) => item.cmd.indexOf(a.t) >= 0), JSON.stringify(item.anno.map((a) => a.t)));
  check('part 映射成 t、explanation 映射成 n',
    item.anno[0].t === 'find .' && item.anno[0].n === '从当前目录开始递归查找', JSON.stringify(item.anno[0]));
  check('label 映射成 short', item.anno[0].short === '递归查找', item.anno[0].short);
  check('flow 保留', item.flow === '递归查找 → 逐个删除', item.flow);
  check('see 里的空字符串被过滤、超量被截断', item.see.length === 3, JSON.stringify(item.see));
  check('source 标记为 ai', item.source === 'ai');

  /* 关键：影响推演(sim)不再是模型的职责，应该完全不存在 */
  check('normalize 不再凭空造出 sim（改由影子沙箱真跑算出）', item.sim === undefined, JSON.stringify(item.sim));
}

{
  /* 模型没给 label 时要能从解释里截一个出来，否则节点卡片没有标题 */
  const noLabel = {
    command: 'df -h',
    segments: [{ part: 'df', explanation: '看各挂载点的磁盘使用情况' },
               { part: '-h', explanation: '人类可读单位' }],
    risk_level: 'low', risk_note: '只读'
  };
  const item = AI.normalize(JSON.stringify(noLabel), '看磁盘');
  check('缺 label 时自动从解释里取短标签',
    item.anno.every((a) => a.short && a.short.length <= 8), JSON.stringify(item.anno.map((a) => a.short)));
  check('risk_level=low 映射成 safe', item.risk === 'safe', item.risk);
}

{
  /* 历史结构仍然要能收：模型偶尔会串成旧字段名 */
  const legacy = {
    cmd: 'ls -la', risk: 'caution', why: '只读',
    anno: [{ t: 'ls', short: '列出', n: '列出目录内容' }, { t: '-la', short: '全部', n: '含隐藏文件' }]
  };
  const item = AI.normalize(JSON.stringify(legacy), '列目录');
  check('旧结构 {cmd, anno, risk} 仍然兼容', item.cmd === 'ls -la' && item.risk === 'caution' && item.anno.length === 2,
    JSON.stringify({ cmd: item.cmd, risk: item.risk, n: item.anno.length }));
}

{
  section('归一化的失败路径');
  const throws = (obj, opts) => {
    try { AI.normalize(JSON.stringify(obj), 'q', opts); return false; } catch (e) { return e.kind || 'throw'; }
  };
  check('缺 command 时抛 format', throws({ risk_level: 'low' }) === 'format');
  check('segments 全部定位不到时抛 format（否则界面会开天窗）',
    throws({ command: 'ls', segments: [{ part: '不存在' }] }) === 'format');
  check('精简模式下允许没有 segments',
    (() => { try { AI.normalize(JSON.stringify({ command: 'ls', risk_level: 'low' }), 'q', { requireAnno: false }); return true; } catch (e) { return false; } })());
  check('risk_level 非法时降级为 caution',
    AI.normalize(JSON.stringify({ command: 'ls', risk_level: '瞎写的', segments: [{ part: 'ls' }] }), 'q').risk === 'caution');
}

/* ── 危险命令兜底 ───────────────────────────────────── */
section('危险命令兜底（不采信模型自述）');

{
  const cases = [
    ['rm -rf /', 'high'],
    ['rm -rf ~/*', 'low'],
    ['mkfs.ext4 /dev/sda1', 'low'],
    ['dd if=/dev/zero of=/dev/sda bs=1M', 'low'],
    ['chmod -R 777 /', 'low'],
    ['curl http://x.sh | bash', 'low']
  ];
  let allUpgraded = true, detail = '';
  cases.forEach(([command, level]) => {
    const item = AI.normalize(JSON.stringify({
      command, risk_level: level, risk_note: '模型说是安全的',
      segments: [{ part: command.split(' ')[0], explanation: 'x' }]
    }), 'q');
    if (item.risk !== 'danger') { allUpgraded = false; detail += command + '→' + item.risk + ' '; }
    if (!item.safety) { allUpgraded = false; detail += command + '(无 safety) '; }
  });
  check('六类致命命令即使被标 low 也一律改判 danger', allUpgraded, detail || undefined);

  const safeOne = AI.normalize(JSON.stringify({
    command: 'rm -rf ./build', risk_level: 'medium', risk_note: '删构建产物',
    segments: [{ part: 'rm -rf ./build', explanation: 'x' }]
  }), 'q');
  check('正常的相对路径递归删除按 medium 落到 caution，不误判成 danger',
    safeOne.risk === 'caution' && !safeOne.safety, safeOne.risk + '/' + safeOne.safety);
}

/* ── 请求契约 ───────────────────────────────────────── */
section('请求契约（同源代理 / JSON mode / 不带密钥）');

let captured = null;
function mockFetch(response) {
  const real = globalThis.fetch;
  globalThis.fetch = (url, opts) => {
    captured = { url: String(url), opts: opts || {} };
    return Promise.resolve(response);
  };
  return () => { globalThis.fetch = real; };
}

function sseResponse(chunks) {
  const enc = new TextEncoder();
  const body = new ReadableStream({
    start(c) {
      chunks.forEach((s) => c.enqueue(enc.encode(s)));
      c.close();
    }
  });
  return { ok: true, status: 200, body };
}

function sseLine(delta) {
  return 'data: ' + JSON.stringify({ choices: [{ delta }] }) + '\n\n';
}

async function runGenerate(query, handlers, opts) {
  return new Promise((resolve) => {
    AI.generate(query, Object.assign({
      onDone: (item) => resolve({ kind: 'done', item }),
      onError: (err) => resolve({ kind: 'error', err }),
      onReasoning: (t) => { (handlers && handlers.reasoning || []).push(t); }
    }, handlers || {}), opts);
  });
}

{
  const restore = mockFetch(sseResponse([
    sseLine({ content: '{"command":"df -h",' }),
    sseLine({ content: '"segments":[{"part":"df","label":"磁盘","explanation":"看磁盘使用情况"}],' }),
    sseLine({ content: '"risk_level":"low","risk_note":"只读"}' }),
    'data: [DONE]\n\n'
  ]));

  const r = await runGenerate('看磁盘还剩多少');
  restore();

  check('请求打到同源 /api/chat，绝不直连模型厂商',
    captured.url === '/api/chat', captured.url);
  check('请求头里没有 Authorization（密钥只存在服务端）',
    !(captured.opts.headers && (captured.opts.headers.Authorization || captured.opts.headers.authorization)),
    JSON.stringify(captured.opts.headers));
  const payload = JSON.parse(captured.opts.body);
  /* 前端只声明"我要 JSON"，把它翻译成 response_format 是 Worker 的职责，
     那一半由 scripts/worker-test.mjs 独立验证。 */
  check('前端声明要 JSON 输出（由 Worker 翻译成 response_format）',
    payload.json === true, JSON.stringify({ json: payload.json, response_format: payload.response_format }));
  check('前端不会自己拼 response_format（避免两处定义漂移）',
    payload.response_format === undefined);
  check('默认不开 thinking（glm-4-flash 没有推理内容）', payload.thinking === undefined);
  check('system 提示词里写的是新结构 command/segments/risk_level',
    /"command"/.test(payload.messages[0].content) && /segments/.test(payload.messages[0].content));
  check('SSE 分片被正确拼成完整 JSON', r.kind === 'done' && r.item.cmd === 'df -h',
    r.kind === 'done' ? r.item.cmd : JSON.stringify(r.err));
}

{
  const reasoning = [];
  const restore = mockFetch(sseResponse([
    sseLine({ reasoning_content: '用户想统计磁盘' }),
    sseLine({ reasoning_content: '，用 df -h 最合适。' }),
    sseLine({ content: '{"command":"df -h","segments":[{"part":"df","explanation":"x"}],"risk_level":"low","risk_note":"只读"}' })
  ]));
  const r = await runGenerate('看磁盘', { reasoning }, { thinking: true });
  restore();

  const payload = JSON.parse(captured.opts.body);
  check('thinking 模式下请求里带 thinking: true', payload.thinking === true);
  check('thinking 模式输出预算更大（推理要占 token）', payload.max_tokens >= 1600, String(payload.max_tokens));
  check('reasoning_content 被单独送给可折叠面板，不混进正文',
    reasoning.length === 2 && reasoning[1].indexOf('df -h 最合适') > 0, JSON.stringify(reasoning));
  check('推理内容没有污染最终命令', r.kind === 'done' && r.item.cmd === 'df -h',
    r.kind === 'done' ? r.item.cmd : 'error');
  check('推理内容挂在 item.reasoning 上供界面回放', r.kind === 'done' && /df -h 最合适/.test(r.item.reasoning || ''));
}

{
  const restore = mockFetch(sseResponse([sseLine({ content: '{"command":"df","segments":[{"part":"df","explanation":"x"}],"risk_level":"low","risk_note":"只读"}' })]));
  await runGenerate('看磁盘', {}, { brief: true });
  restore();
  const payload = JSON.parse(captured.opts.body);
  check('极客终端模式换成精简提示词', !/逐行解释|硬性要求/.test(payload.messages[0].content));
  check('极客终端模式输出预算更小（免费额度下少输出就是快）', payload.max_tokens === 500, String(payload.max_tokens));
}

{
  const restore = mockFetch(sseResponse([sseLine({ content: '{"command":"df -h","segments":[{"part":"df","explanation":"x"}],"risk_level":"low","risk_note":"只读"}' })]));
  await runGenerate('把日志清一下', {}, {
    repair: { cmd: 'rm /var/log/x.log', code: 1, err: 'rm: cannot remove: Permission denied', attempt: 2 }
  });
  restore();
  const um = JSON.parse(captured.opts.body).messages[1].content;
  check('修正请求里带上了真实退出码', /退出码 1/.test(um), um.slice(0, 120));
  check('修正请求里带上了沙箱的真实 stderr', /Permission denied/.test(um));
  check('修正请求里带上了上一条命令', /rm \/var\/log\/x\.log/.test(um));
  check('修正请求仍然要求同样的 JSON 结构', /同样的 JSON 结构/.test(um));
}

/* ── 错误分类 ───────────────────────────────────────── */
section('错误分类');

{
  const cases = [[401, 'auth'], [403, 'auth'], [429, 'rate'], [500, 'server'], [400, 'format']];
  let ok = true, detail = '';
  for (const [status, kind] of cases) {
    const restore = mockFetch({ ok: false, status, text: () => Promise.resolve('{"error":{"message":"x"}}') });
    const r = await runGenerate('q');
    restore();
    if (r.kind !== 'error' || r.err.kind !== kind) { ok = false; detail += status + '→' + (r.err && r.err.kind) + ' '; }
  }
  check('401/403→auth、429→rate、5xx→server、4xx→format', ok, detail || undefined);
}

/* ── 连接状态 ───────────────────────────────────────── */
section('连接状态（密钥在服务端，前端只知道通不通）');

{
  const restore = mockFetch({
    ok: true, status: 200,
    json: () => Promise.resolve({ ok: true, hasKey: true, models: { fast: 'glm-4-flash', think: 'glm-4.7' } })
  });
  await AI.health();
  restore();
  const st = AI.state();
  check('health 探测成功时 state.ok 为 true', st.ok === true, JSON.stringify(st));
  check('state 暴露服务端实际可用的模型名', st.models.fast === 'glm-4-flash', JSON.stringify(st.models));

  const restore2 = mockFetch({
    ok: true, status: 200,
    json: () => Promise.resolve({ ok: true, hasKey: false, models: { fast: 'glm-4-flash' } })
  });
  await AI.health().catch(() => {});
  restore2();
  check('代理在但没写密钥时 state.ok 为 false 且给出原因',
    AI.state().ok === false && /ZHIPU_API_KEY/.test(AI.state().error), JSON.stringify({ ok: AI.state().ok, error: AI.state().error }));

  const restore3 = mockFetch({ ok: false, status: 502, text: () => Promise.resolve('') });
  await AI.health().catch(() => {});
  restore3();
  check('连不上代理时静默降级（不抛给界面）', AI.state().ok === false && AI.state().checked === true);

  /* 降级提示必须随"有没有配兜底地址"而变，两个分支都要覆盖：
       没配 → 点名 FALLBACK_ORIGIN，部署者才知道怎么修（可操作）
       配了 → 说明同源和兜底都不通；这时候再让人去"填 FALLBACK_ORIGIN"就是误导。
     作品现在真的配了兜底地址，所以这里按源码实际情况判定，
     再用改写源码的方式构造"没配"的那一份单独验。 */
  const fallbackConfigured = /var FALLBACK_ORIGIN = 'https?:\/\//.test(AI_SRC);
  check('降级原因与"是否配了兜底地址"一致',
    fallbackConfigured ? /兜底/.test(AI.state().error) : /FALLBACK_ORIGIN/.test(AI.state().error),
    'FALLBACK_ORIGIN 已配=' + fallbackConfigured + ' · ' + AI.state().error);

  {
    const bare = AI_SRC.replace(/var FALLBACK_ORIGIN = '[^']*';/, "var FALLBACK_ORIGIN = '';");
    const w2 = globalThis;
    delete w2.NL2SH_AI;
    new Function('window', bare)(w2);
    const AI2 = w2.NL2SH_AI;
    const restore4 = mockFetch({ ok: false, status: 502, text: () => Promise.resolve('') });
    await AI2.health().catch(() => {});
    restore4();
    check('没配兜底地址时，提示里点名 FALLBACK_ORIGIN（部署者才知道怎么修）',
      /FALLBACK_ORIGIN/.test(AI2.state().error), AI2.state().error);
  }
}

{
  /* 同源优先：同源能用时，health 与 generate 都必须走相对路径，
     不要去碰兜底地址——否则等于白配了一层跨域，还把同源这个安全前提丢了 */
  const calls = [];
  const real = globalThis.fetch;
  const enc = new TextEncoder();
  globalThis.fetch = (url) => {
    calls.push(String(url));
    return Promise.resolve({
      ok: true, status: 200,
      json: () => Promise.resolve({ ok: true, hasKey: true, models: { fast: 'glm-4-flash', think: 'glm-4.7' } }),
      body: new ReadableStream({
        start(c) {
          c.enqueue(enc.encode('data: ' + JSON.stringify({
            choices: [{ delta: { content: '{"command":"df -h","segments":[{"part":"df","explanation":"x"}],"risk_level":"low","risk_note":"只读"}' } }]
          }) + '\n\n'));
          c.close();
        }
      })
    });
  };
  await AI.health();
  await new Promise((resolve) => {
    AI.generate('q', { onDone: () => resolve(), onError: () => resolve() }, {});
  });
  globalThis.fetch = real;
  check('同源可用时健康检查与生成都走相对路径，不触发兜底',
    calls.length === 2 && calls.every((u) => u.indexOf('/api/') === 0), JSON.stringify(calls));
}

console.log('\n' + '─'.repeat(52));
console.log(fail === 0 ? `全部通过：${pass} 项` : `${pass} 项通过，${fail} 项失败`);
if (fail) {
  console.log('\n失败清单：');
  failures.forEach((f) => console.log('  · ' + f));
}
process.exit(fail === 0 ? 0 : 1);
