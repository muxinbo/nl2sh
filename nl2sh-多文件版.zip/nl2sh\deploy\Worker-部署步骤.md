# 模型代理部署（Cloudflare Worker）

## 为什么要有个代理

密钥不能进前端。页面是纯静态的，谁都能 F12 看源码——key 写进去等于公开送额度，
被刷爆之后评委打开就是报错。所以加一层边缘函数：**密钥只存在服务端环境变量里**，
浏览器只请求同源的 `/api/chat`。

它是无服务器边缘函数，不是后端服务：没有服务器要维护、没有常驻进程，
整站仍然是纯静态部署。

```
浏览器 ──POST /api/chat──▶ Cloudflare Worker ──▶ 智谱
                                ↑ 密钥只在这里
```

## 模型选择（2026-10-03 真实请求实测，别凭记忆改）

| 模型 | HTTP | 耗时 | 结论 |
|---|---|---|---|
| `glm-4.7-flash` | **500** | **75.9s** | ❌ **这个 ID 不存在**（「操作失败」） |
| **`glm-4-flash`** | **200** | **0.5s** | ✅ **主力模型** |
| `glm-5.3-flash` | 429 | 0.2s | ❌ 余额不足，需充值 |
| `glm-4.7` | 200 | 4.0s | ✅ 有 `reasoning_content`，「深度思考」开关用它 |

流式 + JSON mode 对照：

| 组合 | 首字节 | 总耗时 | 输出 |
|---|---|---|---|
| `glm-4-flash` 流式 | 2.31s | 8.87s | 带 ` ```json ` 围栏 ❌ |
| **`glm-4-flash` 流式 + JSON mode** | **0.43s** | **6.35s** | **可直接 `JSON.parse`** ✅ |
| `glm-4.7` 流式 + JSON mode | 3.98s | 23.25s | 仍带围栏 ❌ |

**结论：`response_format: {"type":"json_object"}` 是强制的**——它既去掉了围栏，
又把首字节从 2.31s 降到 0.43s（模型不再自由发挥）。这一条由 Worker 统一加上，
前端只声明 `json: true`，避免两处定义漂移。

---

## 部署步骤

```bash
cd worker
npm init -y
npm i -D wrangler

# 1) 登录 Cloudflare
npx wrangler login

# 2) 写入密钥（不会落盘、不进仓库）
npx wrangler secret put ZHIPU_API_KEY
#    粘贴你的智谱 key，回车

# 3) 本地验证
npx wrangler dev            # http://localhost:8787
curl http://localhost:8787/api/health
#    期望：{"ok":true,"hasKey":true,"models":{"fast":"glm-4-flash","think":"glm-4.7"}}

# 4) 上线
npx wrangler deploy
```

本地开发时密钥放 `.dev.vars`（**必须在 .gitignore 里**）：

```
ZHIPU_API_KEY=你的key
```

## 让前端请求到它

前端只会请求同源 `/api/chat`，所以有两条路：

**方案 A（推荐，无跨域）**：把静态站也放到 Cloudflare Pages，同项目下加一个
`functions/api/chat.js`，内容就是 `worker/worker.js` 改写成 `onRequestPost`。
同源、无预检、配置最少。

**方案 B**：Worker 单独部署，在 Cloudflare 面板给站点域名加一条路由把
`/api/*` 指到 Worker。这样前端看到的仍是同源。

> ⚠️ 不要把 Worker 地址写成前端里的绝对 URL（`https://xxx.workers.dev`）——
> 那就跨域了，还得维护 CORS，也把"同源"这个安全前提丢掉了。

## 限流

两层，建议都开：

1. `wrangler.toml` 里的 `[[ratelimits]]` 绑定（代码里已按它写了优先分支）
2. Cloudflare 面板 **Security → WAF → Rate limiting rules**（免费套餐可用，效果更稳）

代码里还有一条退化路径：没有绑定时按 isolate 内存计数，只挡得住单实例内的突发。

## 验证清单

- [ ] `curl .../api/health` 返回 `hasKey: true`
- [ ] `curl -N -X POST .../api/chat -d '{"messages":[{"role":"user","content":"看磁盘还剩多少"}]}'`
      能看到 `data:` 一行行往外冒（**不是一次性吐出**）
- [ ] 故意把密钥改错 → 前端应自动降级到「离线模式」而不是白屏
- [ ] 连打 22 次，确认后面开始返回 429
- [ ] 源码里搜不到 `sk-`：`grep -rInE 'sk-[A-Za-z0-9]{16,}' --exclude-dir=node_modules --exclude-dir=.git .`
- [ ] `git ls-files | grep -E '^\.dev\.vars$'` **无输出**
