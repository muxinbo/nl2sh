@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
cd /d "%~dp0"

echo.
echo   nl2sh 现场演示 —— 启动本地服务
echo   ================================================
echo.

if not exist "index.html" (
  echo   [错误] 这个文件夹里没有 index.html
  echo   请把 index.html 放在和本脚本同一个文件夹里再运行。
  echo.
  pause
  exit /b 1
)

set PORT=8777

rem 优先用 Python（几乎每台开发机都有）
where python >nul 2>nul
if %errorlevel%==0 (
  echo   使用 Python 启动：http://127.0.0.1:%PORT%/
  echo   浏览器会自动打开；关掉这个窗口就停止服务。
  echo.
  start "" "http://127.0.0.1:%PORT%/"
  python -m http.server %PORT% --bind 127.0.0.1
  goto :eof
)

where py >nul 2>nul
if %errorlevel%==0 (
  echo   使用 Python 启动：http://127.0.0.1:%PORT%/
  echo.
  start "" "http://127.0.0.1:%PORT%/"
  py -m http.server %PORT% --bind 127.0.0.1
  goto :eof
)

where node >nul 2>nul
if %errorlevel%==0 (
  if exist "server.mjs" (
    echo   使用 Node 启动（脚本会自己打开浏览器）
    echo.
    node server.mjs %PORT%
    goto :eof
  )
)

echo   这台机器上没找到 Python，也没找到 Node —— 起不了本地服务。
echo.
echo   两条替代路径：
echo     1. 直接双击 index.html：页面能开，但 AI 那条链路会被浏览器拦住
echo        （离线规则库仍然完整可用，演示不会中断）
echo     2. 用手机热点联网，打开线上地址（如果线上地址可访问）
echo.
pause
