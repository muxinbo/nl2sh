/* nl2sh · 交付目录同步（唯一正确的做法）
 *
 * 为什么要有这个脚本：把产物复制到交付目录这件小事，我**手工做错了三次**——
 * 每次都把源码版的 `index.html`（十几 KB，靠 <script src="assets/..."> 引外部文件）
 * 当成单文件产物（四百多 KB，JS/CSS 全内联）复制过去。
 * 前者传上 GitHub Pages 会直接白屏，而交付目录是我看不见的地方，
 * 三次都是靠"顺手核对一下文件大小"才发现的。
 *
 * 所以把这件事交给脚本，并且让脚本自己守两条底线：
 *   ① 源文件必须是**真产物**（体积、内联脚本数都达标），否则拒绝复制、非零退出；
 *   ② 复制完再做一次逐字节校验。
 *
 * 用法：node scripts/sync-delivery.mjs [目标目录]
 *       默认目标 D:/上传到GitHub
 */
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';

const root = path.resolve(import.meta.dirname, '..');
const DEST = process.argv[2] || 'D:/上传到GitHub';

/* 交付清单：源路径（相对项目根） → 目标文件名 */
const ITEMS = [
  ['dist/index.html', 'index.html', true],      /* true = 必须校验是单文件产物 */
  ['README.md', 'README.md', false],
  ['作品说明.md', '作品说明.md', false],
  ['dist/作品说明书.pdf', '作品说明书.pdf', false],
  ['dist/nl2sh-多文件版.zip', 'nl2sh-多文件版.zip', false]
];

const sha = (b) => crypto.createHash('sha256').update(b).digest('hex');

function assertSingleFile(file) {
  const buf = fs.readFileSync(file);
  const txt = buf.toString('utf8');
  const kb = buf.length / 1024;
  const external = (txt.match(/<script[^>]*\bsrc=/g) || []).length;
  const inline = (txt.match(/<script(?![^>]*\bsrc=)/g) || []).length;

  /* 三条底线：体积、没有外链脚本、内联脚本在。任一条不过就拒绝复制。 */
  const problems = [];
  if (kb < 200) problems.push('体积只有 ' + kb.toFixed(1) + ' KB（单文件产物应在 400 KB 以上；这个大小像**源码版**）');
  if (external > 0) problems.push('含 ' + external + ' 个外链 <script src>（单文件产物应为 0；外链会让线上白屏）');
  if (inline < 5) problems.push('内联脚本只有 ' + inline + ' 个（单文件产物应把 JS/CSS 全内联）');

  return { ok: problems.length === 0, kb, external, inline, problems, sha: sha(buf) };
}

console.log('交付目录：' + DEST + '\n');
if (!fs.existsSync(DEST)) { fs.mkdirSync(DEST, { recursive: true }); console.log('  （目录不存在，已创建）'); }

let bad = 0;
for (const [rel, name, mustBeProduct] of ITEMS) {
  const src = path.join(root, rel);
  if (!fs.existsSync(src)) { console.log('  ✗ 源文件不存在：' + rel); bad++; continue; }

  if (mustBeProduct) {
    const v = assertSingleFile(src);
    if (!v.ok) {
      console.log('  🔴 拒绝复制 ' + rel + '：');
      v.problems.forEach((p) => console.log('       · ' + p));
      bad++;
      continue;
    }
    const dst = path.join(DEST, name);
    const srcBuf = fs.readFileSync(src);
    fs.writeFileSync(dst, srcBuf);
    const same = sha(fs.readFileSync(dst)) === v.sha;
    console.log('  ' + (same ? '✓' : '✗') + ' ' + name.padEnd(24) +
      v.kb.toFixed(1).padStart(8) + ' KB · 外链脚本 ' + v.external + ' · 内联 ' + v.inline +
      ' · 逐字节一致 ' + (same ? '是' : '否') + ' · ' + v.sha.slice(0, 16) + '…');
    if (!same) bad++;
    continue;
  }

  fs.copyFileSync(src, path.join(DEST, name));
  const kb = (fs.statSync(src).size / 1024).toFixed(1);
  console.log('  ✓ ' + name.padEnd(24) + kb.padStart(8) + ' KB');
}

console.log('\n交付目录内容：');
for (const f of fs.readdirSync(DEST)) {
  const st = fs.statSync(path.join(DEST, f));
  if (st.isFile()) console.log('  ' + f.padEnd(26) + (st.size / 1024).toFixed(1).padStart(8) + ' KB');
}

if (bad) {
  console.log('\n❌ 有 ' + bad + ' 项没通过，交付目录不完整——**不要上传**。');
  process.exit(1);
}
console.log('\n✅ 交付目录已同步，且 index.html 确认是单文件产物。');
