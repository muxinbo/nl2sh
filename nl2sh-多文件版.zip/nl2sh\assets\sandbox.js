/* nl2sh · 浏览器沙箱引擎
 *
 * 一个跑在前端的内存文件系统 + 迷你 shell。它不是 Linux 内核，但实现了
 * find / ls / du / rm / chmod / chown / grep / sort / xargs / awk / sed / tar / zip
 * 这些命令的真实语义：路径解析、管道、重定向、退出码、属主与权限检查、递归副作用。
 * 目的是让"执行前推演"从模型的猜测变成可验证的事实：命令真的跑一遍，
 * 文件树真的变化（快照里带内容指纹，所以同长度的替换也看得见），然后可以一键回到执行前。
 *
 * 明确不做的：所有依赖内核与 systemd 的东西（systemctl / journalctl / ss / ps /
 * cwebp）走内置桩，输出由固定场景生成，UI 上会标注"模拟输出"，不假装是真的。
 *
 * 命令行层不依赖 DOM，可以在 Node 里直接跑，测试见 scripts。
 */
window.NL2SH_SANDBOX = (function () {
  'use strict';

  var S_IFDIR = 0o040000;
  var S_IFREG = 0o100000;

  /* ── 路径 ─────────────────────────────────────────── */
  function abs(cwd, p) {
    var raw = (p === undefined || p === null || p === '') ? cwd : String(p);
    var base, rest;
    if (raw === '~') { base = ['home', 'student']; rest = ''; }
    else if (raw.slice(0, 2) === '~/') { base = ['home', 'student']; rest = raw.slice(2); }
    else if (raw[0] === '/') { base = []; rest = raw; }
    else { base = cwd.split('/').filter(Boolean); rest = raw; }
    rest.split('/').forEach(function (seg) {
      if (!seg || seg === '.') return;
      if (seg === '..') base.pop();
      else base.push(seg);
    });
    return '/' + base.join('/');
  }

  function join(a, b) { return a === '/' ? '/' + b : a + '/' + b; }
  function baseName(p) { var s = p.split('/').filter(Boolean); return s.length ? s[s.length - 1] : '/'; }
  function dirName(p) { var s = p.split('/').filter(Boolean); s.pop(); return '/' + s.join('/'); }

  /* ── 文件系统 ─────────────────────────────────────── */
  function Fs(nodes) {
    this.nodes = nodes || {};   // 扁平表：绝对路径 -> 节点
    this.nodes['/'] = this.nodes['/'] || { t: 'd', mode: 0o755, uid: 0, mtime: 0 };
  }

  Fs.prototype.get = function (p) { return this.nodes[p] || null; };
  Fs.prototype.exists = function (p) { return !!this.nodes[p]; };

  Fs.prototype.isDir = function (p) { var n = this.nodes[p]; return !!n && n.t === 'd'; };

  /** 目录下的直接子项（不含自身），按名字排序 */
  Fs.prototype.children = function (p) {
    var prefix = p === '/' ? '/' : p + '/';
    var out = [];
    for (var k in this.nodes) {
      if (k === p) continue;
      if (k.slice(0, prefix.length) !== prefix) continue;
      var rest = k.slice(prefix.length);
      if (!rest || rest.indexOf('/') >= 0) continue;
      out.push(k);
    }
    out.sort();
    return out;
  };

  /** 递归遍历（含自身），深度优先，回调返回 false 可剪枝 */
  Fs.prototype.walk = function (p, cb, depth) {
    var self = this;
    var node = this.nodes[p];
    if (!node) return;
    if (cb(p, node, depth || 0) === false) return;
    if (node.t !== 'd') return;
    this.children(p).forEach(function (child) {
      self.walk(child, cb, (depth || 0) + 1);
    });
  };

  Fs.prototype.mkdirp = function (p, opts) {
    var parts = p.split('/').filter(Boolean);
    var cur = '';
    for (var i = 0; i < parts.length; i++) {
      cur = join(cur || '/', parts[i]);
      if (!this.nodes[cur]) {
        this.nodes[cur] = {
          t: 'd', mode: (opts && opts.mode) || 0o755,
          uid: (opts && opts.uid) || 0, mtime: (opts && opts.mtime) || 0
        };
      } else if (this.nodes[cur].t !== 'd') {
        return { err: 'ENOTDIR', path: cur };
      }
    }
    return { ok: true };
  };

  Fs.prototype.writeFile = function (p, data, opts) {
    opts = opts || {};
    var node = this.nodes[p];
    if (node) {
      if (node.t === 'd') return { err: 'EISDIR' };
      if (!opts.append) { node.data = data; node.size = byteLen(data); }
      else { node.data = (node.data || '') + data; node.size = byteLen(node.data); }
      node.mtime = opts.mtime === undefined ? nowStamp() : opts.mtime;
      if (opts.mode !== undefined) node.mode = opts.mode;
      return { ok: true, node: node };
    }
    var parent = dirName(p);
    if (!this.isDir(parent)) return { err: 'ENOENT' };
    node = {
      t: 'f', mode: opts.mode === undefined ? 0o644 : opts.mode,
      uid: opts.uid === undefined ? 0 : opts.uid,
      mtime: opts.mtime === undefined ? nowStamp() : opts.mtime,
      size: byteLen(data), data: data
    };
    this.nodes[p] = node;
    return { ok: true, node: node, created: true };
  };

  /** 只声明大小、不存内容的文件（用于构造大文件场景，cat 时不展开） */
  Fs.prototype.sparse = function (p, size, opts) {
    opts = opts || {};
    this.mkdirp(dirName(p), { uid: opts.uid || 0 });
    this.nodes[p] = {
      t: 'f', mode: opts.mode === undefined ? 0o644 : opts.mode,
      uid: opts.uid === undefined ? 0 : opts.uid,
      mtime: opts.mtime === undefined ? nowStamp() : opts.mtime,
      size: size, data: null
    };
    return this.nodes[p];
  };

  Fs.prototype.unlink = function (p) {
    var node = this.nodes[p];
    if (!node) return { err: 'ENOENT' };
    if (node.t === 'd') {
      var kids = this.children(p);
      if (kids.length) return { err: 'ENOTEMPTY' };
      delete this.nodes[p];
      return { ok: true };
    }
    delete this.nodes[p];
    return { ok: true };
  };

  Fs.prototype.unlinkTree = function (p) {
    var self = this;
    var doomed = [];
    this.walk(p, function (path) { doomed.push(path); });
    doomed.forEach(function (path) { delete self.nodes[path]; });
    return doomed.length;
  };

  Fs.prototype.totalBytes = function () {
    var total = 0;
    for (var k in this.nodes) {
      var n = this.nodes[k];
      if (n.t === 'f') total += n.size || 0;
    }
    return total;
  };

  /* ── 快照与 diff ──────────────────────────────────── */
  /* 便宜的内容指纹：只用来判断"内容变没变"。
     没有它，同样长度的替换（例如 sed 's/todo/done/'）在 diff 里是隐形的，
     而"跑完之后文件到底变没变"正是这个沙箱要回答的核心问题。 */
  function contentSig(n) {
    if (n.t !== 'f' || typeof n.data !== 'string' || !n.data.length) return '';
    if (n.data.length > 200000) return '';      // 大文件跳过，避免每次快照都哈希一遍
    var h = 5381;
    for (var i = 0; i < n.data.length; i++) h = ((h << 5) + h + n.data.charCodeAt(i)) | 0;
    return (h >>> 0).toString(16);
  }

  function manifest(fs) {
    var m = {};
    for (var k in fs.nodes) {
      var n = fs.nodes[k];
      m[k] = { t: n.t, size: n.size || 0, mode: n.mode, uid: n.uid, sig: contentSig(n) };
    }
    return m;
  }

  function diffManifests(before, after) {
    var out = [];
    var k;
    for (k in after) {
      if (!before[k]) out.push({ path: k, kind: 'add', t: after[k].t });
      else if (before[k].size !== after[k].size || before[k].mode !== after[k].mode ||
               before[k].uid !== after[k].uid || before[k].sig !== after[k].sig) {
        out.push({ path: k, kind: 'chg', t: after[k].t, size: after[k].size, mode: after[k].mode });
      }
    }
    for (k in before) {
      if (!after[k]) out.push({ path: k, kind: 'del', t: before[k].t });
    }
    out.sort(function (a, b) { return a.path < b.path ? -1 : a.path > b.path ? 1 : 0; });
    return out;
  }

  /* ── 小工具 ───────────────────────────────────────── */
  function byteLen(s) {
    if (s === null || s === undefined) return 0;
    /* 按 UTF-8 计长，和真实 du 的观感一致 */
    var n = 0;
    for (var i = 0; i < s.length; i++) {
      var c = s.charCodeAt(i);
      if (c < 0x80) n += 1;
      else if (c < 0x800) n += 2;
      else if (c >= 0xd800 && c <= 0xdbff) { n += 4; i++; }
      else n += 3;
    }
    return n;
  }

  function fmtSize(bytes) {
    if (bytes < 1024) return bytes + 'B';
    var units = ['K', 'M', 'G', 'T'];
    var v = bytes / 1024, i = 0;
    while (v >= 1024 && i < units.length - 1) { v /= 1024; i++; }
    return (v >= 10 ? Math.round(v) : v.toFixed(1)) + units[i];
  }

  function modeStr(mode) {
    var t = (mode & S_IFDIR) ? 'd' : '-';
    var bits = ['r', 'w', 'x'];
    var s = '';
    for (var i = 8; i >= 0; i--) s += (mode >> i) & 1 ? bits[(8 - i) % 3] : '-';
    return t + s;
  }

  function nowStamp() {
    /* 固定值：让 ls -l / find -mtime 的输出可复现，也让新文件落在"今天"里 */
    return 1790946060;
  }

  function stampToText(ts) {
    /* 固定成可读的日期，避免沙箱输出每次都不一样 */
    var d = new Date((ts || 0) * 1000);
    var p = function (n) { return (n < 10 ? '0' : '') + n; };
    return p(d.getMonth() + 1) + '月 ' + p(d.getDate()) + ' ' + p(d.getHours()) + ':' + p(d.getMinutes());
  }

  /** 把带 * ? [] 的通配符转成正则 */
  function fnmatch(pattern, name) {
    var re = '^';
    for (var i = 0; i < pattern.length; i++) {
      var c = pattern[i];
      if (c === '*') re += '[^/]*';
      else if (c === '?') re += '[^/]';
      else if (c === '[') {
        var j = pattern.indexOf(']', i);
        if (j < 0) re += '\\[';
        else { re += pattern.slice(i, j + 1).replace(/\\/g, '\\\\'); i = j; }
      } else re += c.replace(/[.+^${}()|\\]/g, '\\$&');
    }
    return new RegExp(re + '$').test(name);
  }

  function parseSizeToken(tok) {
    var m = /^([+-]?)(\d+(?:\.\d+)?)([cwbkKMGTP]?)$/.exec(tok);
    if (!m) return null;
    var mul = { c: 1, w: 2, b: 512, '': 512, k: 1024, K: 1024, M: 1048576, G: 1073741824, T: 1099511627776 }[m[3]];
    if (mul === undefined) mul = 512;
    return { cmp: m[1], value: Math.round(parseFloat(m[2]) * (m[3] ? mul : mul)) };
  }

  /* ── 命令行解析 ───────────────────────────────────── */
  /* 带引号感知：每个词都记下"是否被引号或反斜杠保护过"，
     因为 glob 展开只对没被保护的词生效 ——
     `find . -name '*.tmp'` 里的 *.tmp 绝对不能展开，
     而 `for f in *.png` 里的必须展开。 */
  function tokenize(line) {
    var toks = [], cur = '', has = false, quoted = false, i = 0;
    function flush() {
      if (has) { toks.push({ w: cur, q: quoted }); cur = ''; has = false; quoted = false; }
    }
    while (i < line.length) {
      var c = line[i];
      if (c === ' ' || c === '\t') { flush(); i++; continue; }
      if (c === "'") {
        var j = line.indexOf("'", i + 1);
        if (j < 0) j = line.length;
        cur += line.slice(i + 1, j); has = true; quoted = true; i = j + 1; continue;
      }
      if (c === '"') {
        i++;
        while (i < line.length && line[i] !== '"') {
          if (line[i] === '\\' && i + 1 < line.length) { cur += line[i + 1]; i += 2; }
          else { cur += line[i]; i++; }
        }
        has = true; quoted = true; i++; continue;
      }
      if (c === '\\' && i + 1 < line.length) { cur += line[i + 1]; has = true; quoted = true; i += 2; continue; }
      if (line.slice(i, i + 2) === '>>' || line.slice(i, i + 2) === '&&' || line.slice(i, i + 2) === '||') {
        flush(); toks.push({ op: line.slice(i, i + 2) }); i += 2; continue;
      }
      if (c === '|' || c === ';' || c === '>' || c === '<') {
        flush(); toks.push({ op: c }); i++; continue;
      }
      cur += c; has = true; i++;
    }
    flush();
    return toks;
  }

  /** 把 token 流切成若干个「管道 + 连接符」 */
  function parse(toks) {
    var groups = [], cur = { cmds: [] }, cmd = { argv: [], redir: null };
    var pendingOp = ';';
    function endCmd() {
      if (cmd.argv.length || cmd.redir) cur.cmds.push(cmd);
      cmd = { argv: [], redir: null };
    }
    function endGroup() {
      endCmd();
      if (cur.cmds.length) { cur.op = pendingOp; groups.push(cur); }
      cur = { cmds: [] };
    }
    for (var i = 0; i < toks.length; i++) {
      var t = toks[i];
      if (t.w !== undefined) { cmd.argv.push(t); continue; }
      if (t.op === '|') { endCmd(); continue; }
      if (t.op === '>' || t.op === '>>' || t.op === '<') {
        var target = toks[++i];
        cmd.redir = { kind: t.op, target: target && target.w !== undefined ? target.w : '' };
        continue;
      }
      if (t.op === ';' || t.op === '&&' || t.op === '||') {
        endGroup();
        pendingOp = t.op;
        continue;
      }
    }
    endGroup();
    return groups;
  }

  /** 在当前目录里按 glob 展开；没有匹配就原样返回（和 bash 默认行为一致） */
  function globMatch(fs, cwd, pattern) {
    var dir = '.', pat = pattern;
    var slash = pattern.lastIndexOf('/');
    if (slash >= 0) { dir = pattern.slice(0, slash) || '/'; pat = pattern.slice(slash + 1); }
    var base = abs(cwd, dir);
    if (!fs.isDir(base)) return [];
    var showHidden = pat[0] === '.';
    return fs.children(base).filter(function (p) {
      var name = baseName(p);
      if (!showHidden && name[0] === '.') return false;
      return fnmatch(pat, name);
    }).map(function (p) {
      return (slash >= 0 ? (dir === '/' ? '' : dir) + '/' : '') + baseName(p);
    });
  }

  /* ── 会话 ─────────────────────────────────────────── */
  var HELPERS = {
    abs: abs, join: join, baseName: baseName, dirName: dirName,
    byteLen: byteLen, fmtSize: fmtSize, modeStr: modeStr, fnmatch: fnmatch,
    parseSizeToken: parseSizeToken, stampToText: stampToText,
    S_IFDIR: S_IFDIR, S_IFREG: S_IFREG
  };

  function createSession(fixtureName) {
    var fixtures = window.NL2SH_SBX_FIXTURES || {};
    var commands = window.NL2SH_SBX_CMDS || {};
    var build = fixtures[fixtureName] || fixtures.default;
    if (!build) throw new Error('沙箱：找不到场景 ' + fixtureName);

    var session = {
      fs: null, cwd: '/home/student', euid: 1000, user: 'student',
      snapshots: {}, counters: { snapshot: 0 }, lastSnapshot: null
    };

    function reset() {
      var built = build();
      session.fs = new Fs(built.nodes);
      session.cwd = built.cwd || '/home/student';
      session.euid = 1000;
      session.user = 'student';
      session.now = built.now || 1790946000;
      session.snapshots = {};
      session.counters.snapshot = 0;
      session.services = built.services || {};
      session.processes = built.processes || [];
      session.sockets = built.sockets || [];
      session.lastSnapshot = snapshot();
      return session;
    }

    function snapshot() {
      var id = 'snap' + (++session.counters.snapshot);
      session.snapshots[id] = {
        manifest: manifest(session.fs),
        nodes: shallowCopyNodes(session.fs.nodes),
        cwd: session.cwd,
        services: JSON.parse(JSON.stringify(session.services || {})),
        at: Date.now()
      };
      session.lastSnapshot = id;
      return id;
    }

    function shallowCopyNodes(nodes) {
      var out = {};
      for (var k in nodes) {
        var n = nodes[k];
        out[k] = { t: n.t, mode: n.mode, uid: n.uid, mtime: n.mtime, size: n.size, data: n.data };
      }
      return out;
    }

    function restore(id) {
      var snap = session.snapshots[id];
      if (!snap) return { ok: false, err: '快照不存在' };
      session.fs.nodes = shallowCopyNodes(snap.nodes);
      session.cwd = snap.cwd;
      session.services = JSON.parse(JSON.stringify(snap.services));
      return { ok: true };
    }

    function diffSince(id) {
      var snap = session.snapshots[id];
      if (!snap) return [];
      return diffManifests(snap.manifest, manifest(session.fs));
    }

    /* 权限：euid 0 是 root，通吃；否则属主看 owner 位，非属主看 other 位
       （沙箱里只有一个普通用户，不模拟组成员关系） */
    function can(node, what, euid) {
      if (euid === 0) return true;
      var mode = node.mode || 0;
      var bits = node.uid === 1000 ? (mode >> 6) & 7 : (mode & 7);
      if (what === 'r') return !!(bits & 4);
      if (what === 'w') return !!(bits & 2);
      if (what === 'x') return !!(bits & 1);
      return false;
    }

    /** 写权限看的是父目录的 w 位，和人直觉一致 */
    function canWritePath(fs, path, euid) {
      var parent = dirName(path);
      var pn = fs.get(parent);
      if (!pn) return { ok: false, err: 'ENOENT' };
      if (can(pn, 'w', euid)) return { ok: true };
      return { ok: false, err: 'EACCES', on: parent };
    }

    function runOne(argv, stdin, redir, euid) {
      var name = argv[0];
      var fn = commands[name];
      if (!fn) {
        return {
          out: '', code: 127,
          err: name + ': command not found\n（沙箱只实现了常用命令，完整列表见下方说明）'
        };
      }
      var ctx = {
        argv: argv, stdin: stdin === undefined ? '' : stdin,
        fs: session.fs, helpers: HELPERS,
        euid: euid, session: session,
        cwd: session.cwd,
        outBuf: [], errBuf: [], code: 0,
        out: function (s) { if (s !== undefined) ctx.outBuf.push(s); },
        err: function (s) { if (s !== undefined) ctx.errBuf.push(s); },
        setCode: function (n) { ctx.code = n; },
        can: can, canWritePath: canWritePath,
        /* find -exec / xargs 需要回调执行子命令；子命令不再单独打快照 */
        runSub: function (line) { return execLine(line); },
        simulated: false
      };
      try {
        var r = fn(ctx);
        if (r && typeof r === 'object') {
          if (r.out !== undefined) ctx.outBuf.push(r.out);
          if (r.err !== undefined) ctx.errBuf.push(r.err);
          if (r.code !== undefined) ctx.code = r.code;
          if (r.cwd !== undefined) session.cwd = r.cwd;
        }
      } catch (e) {
        ctx.code = 1;
        ctx.errBuf.push((name || 'sandbox') + ': ' + e.message);
      }
      var result = { out: ctx.outBuf.join(''), err: ctx.errBuf.join(''), code: ctx.code, simulated: ctx.simulated, notice: ctx.notice };
      if (redir && redir.target) {
        var target = abs(session.cwd, redir.target);
        var perm = canWritePath(session.fs, target, euid);
        if (!perm.ok) {
          result.err += 'bash: ' + redir.target + ': Permission denied\n';
          result.code = 1;
          return result;
        }
        var w = session.fs.writeFile(target, result.out, { append: redir.kind === '>>', uid: euid === 0 ? 0 : 1000 });
        if (w.err) { result.err += 'bash: ' + redir.target + ': ' + w.err + '\n'; result.code = 1; }
        result.out = '';
      }
      return result;
    }

    /* ── shell 变量与命令替换：够用就好，但 for 循环要能跑 ── */
    function expandVars(text, vars) {
      if (!vars) return text;
      return String(text).replace(/\$\{(\w+)([%#])([^}]*)\}|\$\{(\w+)\}|\$(\w+)/g,
        function (m, n1, op, pat, n2, n3) {
          var name = n1 || n2 || n3;
          var val = vars[name];
          if (val === undefined) return m;
          if (op === '%') {
            var idx = val.lastIndexOf(pat);
            return idx >= 0 ? val.slice(0, idx) : val;
          }
          if (op === '#') {
            var i2 = val.indexOf(pat);
            return i2 >= 0 ? val.slice(i2 + pat.length) : val;
          }
          return val;
        });
    }

    function substituteCommands(line, vars) {
      var out = '', i = 0, guard = 0;
      while (i < line.length) {
        if (line[i] === '$' && line[i + 1] === '(' && guard < 10) {
          var depth = 1, j = i + 2;
          while (j < line.length && depth > 0) {
            if (line[j] === '(') depth++;
            else if (line[j] === ')') { depth--; if (depth === 0) break; }
            j++;
          }
          var inner = line.slice(i + 2, j);
          var r = execLine(substituteCommands(expandVars(inner, vars), vars), vars);
          out += String(r.out).replace(/\n+$/, '');
          i = j + 1; guard++;
          continue;
        }
        out += line[i]; i++;
      }
      return out;
    }

    function expandWord(word) {
      if (word.q || !/[*?\[]/.test(word.w)) return [word.w];
      var hits = globMatch(session.fs, session.cwd, word.w);
      return hits.length ? hits : [word.w];
    }

    /** for VAR in 列表; do 主体; done —— 不是命令，是 shell 语法，所以得在解析之前拦下来 */
    function tryForLoop(line, vars) {
      var m = /^\s*for\s+([A-Za-z_]\w*)\s+in\s+([\s\S]*?)\s*;?\s*do\s+([\s\S]*?)\s*;?\s*done\s*$/.exec(line);
      if (!m) return null;
      var name = m[1], listRaw = m[2], body = m[3];
      var words = [];
      tokenize(substituteCommands(expandVars(listRaw, vars), vars)).forEach(function (t) {
        if (t.w === undefined) return;
        words = words.concat(expandWord(t));
      });
      var acc = { out: '', err: '', code: 0, simulated: false };
      words.forEach(function (w) {
        var local = {};
        for (var k in vars) local[k] = vars[k];
        local[name] = w;
        var r = execLine(body, local);
        acc.out += r.out; acc.err += r.err; acc.code = r.code;
        if (r.simulated) acc.simulated = true;
    if (r.notice) acc.notice = (acc.notice ? acc.notice + '\n' : '') + r.notice;
      });
      return acc;
    }

    /** 执行一整行（不含快照），供顶层 run 与 -exec / xargs / for 复用 */
    function execLine(line, vars) {
      var trimmed = String(line || '').trim();
      if (!trimmed) return { out: '', err: '', code: 0, simulated: false };

      var loop = tryForLoop(trimmed, vars);
      if (loop) return loop;

      var expanded = substituteCommands(expandVars(trimmed, vars), vars);
      var groups = parse(tokenize(expanded));
      var stdout = '', stderr = '', code = 0, simulated = false, notice = '';
      var skipNext = false;

      for (var g = 0; g < groups.length; g++) {
        var grp = groups[g];
        if (skipNext && (grp.op === '&&' || grp.op === '||')) continue;
        var sudoNotice = false;
  var stdinData = '';
        var last;
        for (var c = 0; c < grp.cmds.length; c++) {
          var spec = grp.cmds[c];
          var euid = session.euid;
          var words = [];
          spec.argv.forEach(function (t) { words = words.concat(expandWord(t)); });
          /* sudo 改变的是后续命令的身份，它自己不是一条命令 */
          if (words[0] === 'sudo') {
            /* ⚠️ 原来这里是**静默剥掉** sudo：命令照样跑、退出码 0、属主真的改了。
               教学上"sudo 能用但被偷偷忽略"会让人以为提权成功了，所以如实说一句。
               注意：**不能写进 stderr** —— 自验证把"stderr 非空"判定为失败，
               那样每条 sudo 命令都会被冤枉地触发一轮修正。走独立的 notice 通道。 */
            sudoNotice = true;
            euid = 0;
            words = words.slice(1);
            while (words.length && words[0][0] === '-') words.shift();
            if (!words.length) { last = { out: '', err: 'usage: sudo command\n', code: 1 }; break; }
          }
          last = runOne(words, stdinData, spec.redir, euid);
          if (last.simulated) simulated = true;
          if (sudoNotice) {
            last.notice = (last.notice ? last.notice + '\n' : '') +
              'sudo: 沙箱按 root 执行了这条命令（演示用），但不会真的改变你机器的任何权限。';
          }
          stdinData = last.out;
        }
        if (!last) last = { out: '', err: '', code: 0 };
        stdout += last.out;
        stderr += last.err;
        code = last.code;
        if (last.notice) notice = (notice ? notice + '\n' : '') + last.notice;

        if (grp.op === '&&') skipNext = code !== 0;
        else if (grp.op === '||') skipNext = code === 0;
        else skipNext = false;
      }
      return { out: stdout, err: stderr, code: code, simulated: simulated, notice: notice, cwd: session.cwd };
    }

    /** 执行一整行；返回 stdout / stderr / 退出码 / 相对本次执行的变化 */
    function run(line) {
      var start = Date.now();
      if (!String(line || '').trim()) {
        return { out: '', err: '', code: 0, changes: [], snapshot: null, simulated: false, notice: '', ms: 0 };
      }
      var beforeId = snapshot();
      var r = execLine(line);
      r.changes = diffSince(beforeId);
      r.snapshot = beforeId;
      r.cwd = session.cwd;
      r.ms = Date.now() - start;
      return r;
    }

    /** 把解析出来的命令名收集起来，用于说明"哪些是模拟的" */
    function commandNames(line) {
      var names = [];
      try {
        parse(tokenize(String(line || ''))).forEach(function (grp) {
          grp.cmds.forEach(function (spec) {
            var a = spec.argv.map(function (t) { return t.w; });
            if (a[0] === 'sudo') a = a.slice(1);
            while (a.length && a[0][0] === '-') a.shift();
            if (a[0]) names.push(a[0]);
          });
        });
      } catch (e) { /* 解析失败就当没有命令名，交给执行阶段报错 */ }
      return names;
    }

    reset();

    return {
      run: run,
      commandNames: commandNames,
      snapshot: snapshot,
      restore: restore,
      diffSince: diffSince,
      reset: reset,
      state: function () { return session; },
      cwd: function () { return session.cwd; },
      tree: function (path) { return buildTree(session.fs, abs(session.cwd, path || '.')); },
      hasCommand: function (n) { return !!commands[n]; },
      isSimulated: function (n) { return !!(commands[n] && commands[n].simulated); },
      commandList: function () {
        return Object.keys(commands).sort().map(function (k) {
          return { name: k, simulated: !!commands[k].simulated, usage: commands[k].usage || '' };
        });
      }
    };
  }

  /** 给 UI 用的嵌套树 */
  function buildTree(fs, root) {
    var node = fs.get(root);
    if (!node) return null;
    function rec(p) {
      var n = fs.get(p);
      var out = {
        path: p, name: p === '/' ? '/' : baseName(p), t: n.t,
        size: n.size || 0, mode: n.mode, uid: n.uid,
        /* mtime 也要带出来：界面上的文件树悬浮详情要显示修改时间，
           和 ls -l / stat 显示的是同一个字段，不能一个有一个没有。 */
        mtime: n.mtime || 0
      };
      if (n.t === 'd') out.children = fs.children(p).map(rec);
      return out;
    }
    return rec(root);
  }

  return {
    createSession: createSession,
    _internals: { abs: abs, tokenize: tokenize, parse: parse, fnmatch: fnmatch, Fs: Fs, fmtSize: fmtSize }
  };
})();
