#!/usr/bin/env node
/**
 * 部署后的真机自测：拿真实网络、真实模型、真实沙箱跑一遍完整链路。
 *
 * 为什么需要它：
 *   另外四套测试全都"不联网"——它们能证明解析、归一化、安全改判是对的，
 *   但证明不了"线上那个 Worker 真的能用"。这个脚本补上这一段：
 *
 *     加载前端 ai.js → 走它自己的端点解析（同源失败 → 退回 FALLBACK_ORIGIN）
 *     → 真实请求已部署的 Worker → 真实调用 glm-4-flash
 *     → 把拿到的命令送进沙箱真跑一遍
 *
 * 跑法：node scripts/ai-live-test.mjs
 *   --json   只输出机器可读结果
 *
 * 注意：会消耗一点免费额度（一次完整生成 + 一次修正），也会真的访问网络。
 */
import fs from 'node:fs';
import path from 'node:path';
import { execFileSync } from 'node:child_process';

const root = path.resolve(import.meta.dirname, '..');
const asJson = process.argv.includes('--json');

/* 网络提示：国内直连 *.workers.dev 往往不通（DNS 会被污染成无关 IP，实测解析到
   了 Facebook 的 IPv6 段），而 **Node 的 fetch 默认不读系统代理** ——
   浏览器和 PowerShell 能通、Node 报 fetch failed，多半就是这个原因。
   Node 24 提供了 --use-env-proxy / NODE_USE_ENV_PROXY 让它读代理环境变量。
   这里把系统代理找出来，失败时给一句能直接照抄的命令。 */
function systemProxy() {
  if (process.env.HTTPS_PROXY || process.env.https_proxy) {
    return process.env.HTTPS_PROXY || process.env.https_proxy;
  }
  if (process.platform !== 'win32') return '';
  try {
    const out = execFileSync('reg', ['query',
      'HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Internet Settings',
      '/v', 'ProxyServer'], { encoding: 'utf8', stdio: ['ignore', 'pipe', 'ignore'] });
    const m = out.match(/ProxyServer\s+REG_SZ\s+(\S+)/);
    return m ? m[1] : '';
  } catch (e) { return ''; }
}

const proxy = systemProxy();
const proxyInUse = process.env.NODE_USE_ENV_PROXY === '1'
  || process.execArgv.some((a) => a.indexOf('use-env-proxy') >= 0)
  || !!(process.env.HTTPS_PROXY || process.env.https_proxy);

function proxyHint() {
  if (!proxy) return '这台机器没检测到系统代理；如果连不通请自行确认网络。';
  return '检测到系统代理 ' + proxy + '，而 Node 的 fetch 默认不读它。照这个跑：\n' +
    "       $env:HTTPS_PROXY='" + proxy + "'; node --use-env-proxy scripts/ai-live-test.mjs";
}

let pass = 0, fail = 0;
const failures = [];
function check(name, cond, detail) {
  if (cond) { pass++; if (!asJson) console.log('  ok   ' + name + (detail ? '\n       ' + detail : '')); }
  else {
    fail++; failures.push(name);
    if (!asJson) console.log('  FAIL ' + name + (detail ? '\n       → ' + detail : ''));
  }
}
function section(t) { if (!asJson) console.log('\n' + t); }

const aiSrc = fs.readFileSync(path.join(root, 'assets/ai.js'), 'utf8');
const origin = (aiSrc.match(/var FALLBACK_ORIGIN = '([^']*)'/) || [])[1] || '';

if (!asJson) {
  console.log('\n部署后真机自测 · NL2SH\n' + '═'.repeat(74));
  console.log('FALLBACK_ORIGIN = ' + (origin || '（空——纯静态主机上 AI 会一直停在离线模式）'));
}

if (!origin) {
  check('配了 FALLBACK_ORIGIN', false, 'ai.js 里的 FALLBACK_ORIGIN 是空的');
  if (asJson) console.log(JSON.stringify({ pass, fail, failures }, null, 2));
  else console.log('\n跳过联网检查：没有配兜底地址。\n');
  process.exit(1);
}

/* 在 Node 里给 ai.js 一个 window 壳。相对路径 /api/chat 在 Node 里必然失败，
   于是它会自动退回 FALLBACK_ORIGIN —— 正好就是纯静态主机上的真实路径。 */
globalThis.window = globalThis;
new Function('window', aiSrc)(globalThis);
const AI = globalThis.window.NL2SH_AI;

/* ── 1. 健康检查 ─────────────────────────────────────── */
section('代理连通性');
let st = null;
try {
  st = await AI.health();
} catch (e) {
  check('health 请求成功', false, String((e && e.message) || e) + '\n       ' + proxyHint());
}

if (st) {
  check('代理可达且已写入密钥', st.ok === true && st.hasKey !== false, JSON.stringify(st));
  check('服务端报出了模型名', !!(st.models && st.models.fast), JSON.stringify(st.models || {}));
  check('生效的基址是兜底地址（说明同源确实不通、回退生效）',
    AI.state().base === origin, 'state.base = ' + AI.state().base);
}

/* ── 2. 真实生成 ─────────────────────────────────────── */
section('真实生成（会消耗一次免费额度）');
const QUESTION = '把 src 目录里所有 js 文件的 console.log 去掉，改成注释';

let item = null, deltas = 0, reasoning = 0, err = null;
try {
  /* 注意：generate 是**回调式**的（结果走 onDone / onError），只有 health 返回 Promise。
     这里用 Promise 把它包起来，否则 await 到的是 { cancel } 那个控制对象。 */
  item = await new Promise(function (resolve, reject) {
    AI.generate(QUESTION, {
      onProgress: function (p) { if (p && p.chars) deltas = p.chars; },
      onReasoning: function () { reasoning++; },
      onDone: resolve,
      onError: reject
    }, { brief: false, thinking: false });
  });
} catch (e) {
  err = e;
}

check('生成请求成功返回', !!item && typeof item === 'object',
  err ? String((err && err.message) || err) + '\n       ' + proxyHint() : '拿到 ' + Object.keys(item || {}).length + ' 个字段');

if (item) {
  /* 注意内部字段名：normalize() 会把规格里的 command/segments 映射成
     界面层用的 cmd/anno（离线测试里有"command 映射到 cmd"这一条）。
     检查外部名字会得到 undefined —— 我自己在这里栽过一次。 */
  check('拿到了命令（item.cmd）', typeof item.cmd === 'string' && item.cmd.trim().length > 0,
    JSON.stringify(item.cmd) + '　字段：' + Object.keys(item).join(','));
  check('命令是单行可执行的（没有换行）', !/\n/.test(item.cmd || ''), JSON.stringify(item.cmd));
  check('带了解释分段（item.anno）', Array.isArray(item.anno) && item.anno.length > 0,
    (item.anno || []).length + ' 段');
  check('每段都是命令的逐字子串（否则界面上高亮会错位）',
    (item.anno || []).every((s) => item.cmd.indexOf(s.t) >= 0),
    JSON.stringify((item.anno || []).map((s) => s.t)));
  check('分段互不重叠', (() => {
    const rs = (item.anno || [])
      .map((s) => [item.cmd.indexOf(s.t), item.cmd.indexOf(s.t) + s.t.length])
      .sort((a, b) => a[0] - b[0]);
    for (let i = 1; i < rs.length; i++) if (rs[i][0] < rs[i - 1][1]) return false;
    return true;
  })(), '');
  check('给出了风险等级', ['safe', 'caution', 'danger'].indexOf(item.risk) >= 0, String(item.risk));
  check('流式过程有进度回调', deltas > 0, '累计 ' + deltas + ' 字符');

  /* 调用凭证：界面上那条绿色「AI 实时生成」就是靠它渲染的。
     字段必须都带真实数值，否则界面上会出现"—ms"这种一眼假的东西。
     用户提出的核心质疑正是"AI 干了活但没人看得见"，所以这条断言很关键。 */
  const tr = item.trace || {};
  check('带回了调用凭证（模型 / 首字节 / 总耗时 / 分片数 / 端点）',
    !!(tr.model && tr.firstByteMs > 0 && tr.totalMs > 0 && tr.chunks > 0 && tr.endpoint),
    JSON.stringify(tr));
  check('凭证里的模型名与服务端回报一致（不是前端写死的字面量）',
    tr.model === (st && st.models ? st.models.fast : ''),
    '凭证 ' + tr.model + ' vs 服务端 ' + (st && st.models ? st.models.fast : '(无)'));
  check('首字节不晚于总耗时（时间线合理）', tr.firstByteMs <= tr.totalMs,
    tr.firstByteMs + 'ms / ' + tr.totalMs + 'ms');
  check('端点指向已部署的 Worker（不是同源）',
    String(tr.endpoint).indexOf(origin) === 0, String(tr.endpoint));

  if (!asJson) {
    console.log('\n  ── 模型实际给出的内容 ──');
    console.log('  命令：' + item.cmd);
    console.log('  风险：' + item.risk + '　' + (item.why || ''));
    (item.anno || []).slice(0, 6).forEach((s) => {
      console.log('    · ' + s.t + '　' + (s.short || ''));
    });
    console.log('\n  ── 界面上那条调用凭证会显示 ──');
    console.log('  AI 实时生成 · 模型 ' + tr.model + ' · 首字节 ' +
      (tr.firstByteMs < 1000 ? tr.firstByteMs + 'ms' : (tr.firstByteMs / 1000).toFixed(1) + 's') +
      ' · 总耗时 ' + (tr.totalMs / 1000).toFixed(1) + 's · 流式分片 ' + tr.chunks +
      ' · 输出 ' + tr.chars + ' 字符');
    console.log('  端点 ' + tr.endpoint + ' · 密钥只在服务端');
  }
}

/* ── 3. 把模型给的命令送进沙箱真跑 ───────────────────── */
section('模型给的命令能不能真跑');
if (item && item.cmd) {
  const assets = path.join(root, 'assets');
  for (const f of ['sandbox-fixtures.js', 'sandbox-cmds.js', 'sandbox.js']) {
    new Function('window', fs.readFileSync(path.join(assets, f), 'utf8'))(globalThis);
  }
  const sb = globalThis.NL2SH_SANDBOX.createSession();
  const run = sb.run(item.cmd);
  check('沙箱能执行它（不是语法错误）',
    !/command not found|syntax error|unexpected/i.test(String(run.err || '')),
    'exit ' + run.code + ' · stderr: ' + String(run.err || '').split('\n')[0]);

  if (!asJson) {
    console.log('  退出码 ' + run.code + '　文件变化 ' + (run.changes || []).length + ' 项');
    if (run.out) console.log('  输出：' + String(run.out).trim().split('\n').slice(0, 3).join(' / '));
    if (run.err) console.log('  报错：' + String(run.err).trim().split('\n').slice(0, 2).join(' / '));
    console.log('  （退出码非 0 不算失败：这说明模型给的第一版可能在真实环境里跑不通，');
    console.log('    而这正是作品里"沙箱自验证自纠错闭环"要处理的情况。）');
  }
}

/* ── 汇总 ─────────────────────────────────────────────── */
if (asJson) {
  console.log(JSON.stringify({
    pass, fail, failures, origin,
    question: QUESTION,
    command: item ? item.cmd : null,
    risk: item ? item.risk : null,
    segments: item && item.anno ? item.anno.length : 0
  }, null, 2));
} else {
  console.log('\n' + '═'.repeat(74));
  console.log('共 ' + (pass + fail) + ' 项：通过 ' + pass + ' · 不通过 ' + fail);
  if (fail) {
    console.log('\n❌ 不通过：');
    failures.forEach((f) => console.log('   · ' + f));
  } else {
    console.log('\n✅ 线上链路完全可用。');
  }
  console.log('');
}
process.exit(fail ? 1 : 0);
