/* nl2sh · 向说明书「核心交互」清单追加一条（**自动编号**）
 *
 * 为什么要有这个脚本：
 *   我往这个清单里加内容时，习惯说"插在第 N 条前面"，而 N 中途会变成列表中间的一项，
 *   于是编号被打乱 —— **同一个错误我犯了八次**，每次都靠事后核对或审计才发现。
 *   光靠"下次注意"已经被证明无效，所以把编号这件事交给机器：
 *   脚本自己数出当前最大编号，把新条目**追加在列表末尾**，编号永远连续。
 *
 * 用法：
 *   node scripts/doc-append.mjs <标题> <正文文件>
 *   例：node scripts/doc-append.mjs "学习报告" /tmp/body.md
 *
 * 正文文件里可以写多行 markdown，会按 4 空格缩进接在标题下面。
 * 追加完会立刻复查编号连续性，不连续就非零退出（不会静默改坏）。
 */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.join(here, '..');
const DOC = path.join(root, '作品说明.md');

const [, , title, bodyFile] = process.argv;
if (!title || !bodyFile) {
  console.error('用法：node scripts/doc-append.mjs <标题> <正文文件>');
  process.exit(2);
}

const md = fs.readFileSync(DOC, 'utf8');

/* 定位「## 六、」到「## 七、」之间的清单 */
const sixAt = md.search(/^## 六、/m);
const sevenAt = md.search(/^## 七、/m);
if (sixAt < 0 || sevenAt < 0 || sevenAt < sixAt) {
  console.error('找不到「## 六、」或「## 七、」章节，放弃（不改文件）');
  process.exit(2);
}
/* ⚠️ 必须只扫「第六章」这一段。
   第一版写的是 md.slice(0, sevenAt)——从头到第七章，于是把第 71 行、291 行、308 行
   那些**别的**有序清单也当成了本清单的条目，算出 1,2,3,4,5,1,2,1,2,3,… 直接误判成"编号已断"。
   守卫本身是对的（它拒绝改文件），但它拦下的是一个假警报。 */
const before = md.slice(0, sixAt);
const body6 = md.slice(sixAt, sevenAt);
const after = md.slice(sevenAt);

const nums = [...body6.matchAll(/^(\d+)\. \*\*/gm)].map((m) => Number(m[1]));
if (!nums.length) {
  console.error('第六章里一条清单项都没找到，放弃（不改文件）');
  process.exit(2);
}
const expected = nums.length;
const broken = nums.filter((n, i) => n !== i + 1);
if (broken.length) {
  console.error('清单编号本来就断了（' + nums.join(',') + '），先修好再加，否则会越描越乱');
  process.exit(2);
}

const body = fs.readFileSync(bodyFile, 'utf8')
  .replace(/\r\n/g, '\n')
  .replace(/\n+$/, '')
  .split('\n')
  .map((l) => (l.trim() ? '    ' + l : ''))
  .join('\n');

/* 追加到清单末尾：找到第六章里最后一个 "N. **" 条目，插到它那一整段之后 */
const lastAt = body6.lastIndexOf('\n' + expected + '. **');
if (lastAt < 0) {
  console.error('找不到最后一条（' + expected + '）的位置，放弃（不改文件）');
  process.exit(2);
}
const restOfLast = body6.slice(lastAt + 1);
const blankAt = restOfLast.indexOf('\n\n');
const insertAt = blankAt < 0 ? body6.length : lastAt + 1 + blankAt;

const item = '\n' + (expected + 1) + '. **' + title + '**：' + body.replace(/^ {4}/, '') + '\n';
const newBody6 = body6.slice(0, insertAt) + item + body6.slice(insertAt);
const out = before + newBody6 + after;

fs.writeFileSync(DOC, out, 'utf8');

/* 立刻复查：**只看第六章**的编号是否仍然连续 */
const newSixAt = out.search(/^## 六、/m);
const newSevenAt = out.search(/^## 七、/m);
const recheck = [...out.slice(newSixAt, newSevenAt).matchAll(/^(\d+)\. \*\*/gm)].map((m) => Number(m[1]));
const bad = recheck.filter((n, i) => n !== i + 1);
if (bad.length) {
  console.error('追加后编号断了：' + recheck.join(',') + ' —— 已写入但请立刻检查');
  process.exit(1);
}
console.log('已追加第 ' + (expected + 1) + ' 条「' + title + '」，清单共 ' + recheck.length + ' 条，编号 1–' + recheck.length + ' 连续。');
