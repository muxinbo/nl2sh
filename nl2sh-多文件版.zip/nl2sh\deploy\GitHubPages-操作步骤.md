# 路线 2 操作手册 · GitHub Pages（全程网页操作，不用装 git）

> **为什么选这条**：我已经用真实 `GET` 实测过 GitHub Pages 的响应头——
> `Content-Type: text/html`、**没有 `Content-Disposition`**，浏览器会正常渲染网页。
> 不像腾讯云 COS 那样强制下载。
>
> **它唯一的短板是国内访问速度**：`github.io` 在国内时好时坏。
> 页面是**单个 205 KB 文件、只有 1 个请求**，能连上就很快；连不上就真的连不上。
> 所以**用手机流量先验一遍**再决定要不要用它。
>
> 如果你能把 EdgeOne 那个项目修好（国内节点），优先用那个。

---

## 第 1 步：注册 GitHub（约 3 分钟）

打开 <https://github.com/signup>，用邮箱注册。**记得去邮箱点验证链接**，不验证没法建 Pages。

> 已经有账号的直接跳到第 2 步。

## 第 2 步：建一个仓库（约 1 分钟）

1. 右上角 **+** → **New repository**
2. **Repository name** 填 `nl2sh`
3. 选 **Public**（⚠️ 必须是 Public，私有仓库的 Pages 要收费）
4. 下面的 README / .gitignore / license **全都不勾**
5. 点 **Create repository**

## 第 3 步：把文件传上去（约 2 分钟）

新建完的仓库页面中间会有一行小字：

> …or **uploading an existing file**

点它，然后把下面这个文件**拖进去**：

```
D:\dsh\downloads\nl2sh\dist\index.html
```

> ✅ **只拖这一个文件就行**。它是单文件版，CSS 和 JS 都已经内联在里面了，
> 不会出现"漏传 assets 导致白屏"的情况。
>
> 文件名必须正好是 **`index.html`**（本来就是，不用改）。

拖完往下拉，点绿色的 **Commit changes**。

**你应该看到**：仓库里出现一个 `index.html`。

## 第 4 步：开启 Pages（约 1 分钟）

1. 仓库上方 **Settings**
2. 左侧栏往下找 **Pages**
3. **Source** 选 **Deploy from a branch**
4. **Branch** 选 `main`，右边文件夹选 **/ (root)**
5. 点 **Save**

## 第 5 步：等它生成，拿链接（约 1 分钟）

停在 **Settings → Pages** 这个页面，**刷新几次**，顶部会出现一行绿色提示：

```
Your site is live at https://你的用户名.github.io/nl2sh/
```

**那就是你要填进报名表的链接。**

## 第 6 步：验证（不能省）

- [ ] 点开链接，看到「**一条命令，五个零件**」和引线图 → 说明是网页
- [ ] 点「**看一遍完整演示**」能跑完
- [ ] **手机关掉 WiFi、只用流量**再打开一次 ← 这一步决定能不能用它交

⚠️ 如果手机流量打不开，说明 `github.io` 在你那边的网络不通——**告我**，
我们改回 EdgeOne 那条路。

---

## 以后想改内容

1. 仓库里点 `index.html` → 右上角铅笔图标 → 改 → Commit
2. 或者删掉旧文件重新拖一个新的上去（覆盖）
3. 改完等 1 分钟左右生效，浏览器可能要 `Ctrl` + `F5` 强刷

## 报名表这样填

| 列 | 填什么 |
|---|---|
| E 所选的赛道 | **赛道三：智能交互与应用** |
| F 作品链接 | `https://你的用户名.github.io/nl2sh/` |

---

## 顺带一句：GitHub 仓库还有个附加好处

`https://github.com/你的用户名/nl2sh` 这个仓库地址本身就是"**源码链接**"。
如果评委想看代码，或者比赛后面要求补交源码，你直接把仓库地址给他就行——
`README.md` 也已经在仓库里了（如果你后面把整个 `nl2sh` 目录都传上去的话）。
