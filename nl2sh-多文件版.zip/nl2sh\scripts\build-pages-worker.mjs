/* 从 worker/worker.js 生成 Cloudflare Pages 的 _worker.js
 *
 * 为什么要"生成"而不是"手抄"：
 * 官方文档说迁移方式就是"把 Worker 代码粘进 _worker.js，再加一句 env.ASSETS.fetch" ✓，
 * 但手抄一份意味着**同一份加固逻辑存在三处**（Cloudflare Worker / EdgeOne Function / Pages _worker），
 * 这个项目里凡是需要手工同步两次以上的东西最后都漂过。所以这里由脚本生成，
 * 并且 audit 会把三份放在一起做行为比对。
 *
 * 与 Worker 的唯一区别：非 /api/* 的请求要交给静态资源（env.ASSETS.fetch），
 * 否则 _worker.js 接管全部请求之后，页面本身就打不开了。
 */
import fs from 'node:fs';
import path from 'node:path';

const root = path.resolve(import.meta.dirname, '..');
const src = fs.readFileSync(path.join(root, 'worker/worker.js'), 'utf8');

const HEADER = `/* ⚠️ 这个文件是 scripts/build-pages-worker.mjs 生成的，不要手改。
   改逻辑请改 worker/worker.js，然后重新运行：
     node scripts/build-pages-worker.mjs
   唯一与 Worker 版本的差别：非 /api/* 的请求交给静态资源
   （_worker.js 接管全部请求，不转发的话页面本身就打不开了）。 */
`;

/* 把 export default 之前的部分原样保留，加一句静态资源回退 */
let out = src.replace(
  `    if (url.pathname !== '/api/chat') return json({ error: 'not found' }, 404);`,
  `    /* ── 非 /api/* ：交给 Pages 的静态资源 ────────────────
       _worker.js 会接管**全部**请求，所以这一句不能少——
       少了它，index.html 也走不到，整站直接白屏。 */
    if (!url.pathname.startsWith('/api/')) return env.ASSETS.fetch(request);

    if (url.pathname !== '/api/chat') return json({ error: 'not found' }, 404);`
);

if (!out.includes('env.ASSETS.fetch(request)')) {
  console.error('  ✗ 没能插入静态资源回退——worker.js 的 /api/chat 判断行可能被改过，先看它现在长什么样');
  process.exit(1);
}

out = HEADER + out;

const destDir = path.join(root, 'deploy/cloudflare-pages');
fs.mkdirSync(destDir, { recursive: true });
fs.writeFileSync(path.join(destDir, '_worker.js'), out, 'utf8');
console.log('  ✓ 已生成 deploy/cloudflare-pages/_worker.js（' + (out.length / 1024).toFixed(1) + ' KB）');

/* 同时产出"可直接拖"的文件夹：index.html + _worker.js */
const stage = 'D:/上传到CloudflarePages';
fs.rmSync(stage, { recursive: true, force: true });
fs.mkdirSync(stage, { recursive: true });
fs.copyFileSync(path.join(root, 'dist/index.html'), path.join(stage, 'index.html'));
fs.copyFileSync(path.join(destDir, '_worker.js'), path.join(stage, '_worker.js'));
console.log('  ✓ 已备好可直接拖的文件夹：' + stage);
for (const f of fs.readdirSync(stage)) {
  console.log('      ' + f.padEnd(14) + (fs.statSync(path.join(stage, f)).size / 1024).toFixed(1).padStart(8) + ' KB');
}
