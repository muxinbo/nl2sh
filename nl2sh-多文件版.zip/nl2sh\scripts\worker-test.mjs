/* nl2sh · 边缘代理自测（不联网）
 *
 * Worker 是密钥唯一的落脚点，它一旦出错，后果不是"界面难看"而是"额度被刷爆"
 * 或者"模型名写错导致全线 500"。所以它必须能独立验证。
 *
 * 这个文件把 worker.js 当 ES 模块加载（用 data: URL，免得为它单独加 package.json），
 * 用假的 fetch 挡住上游，然后逐条断言代理的行为。
 *
 *     node scripts/worker-test.mjs
 */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const src = fs.readFileSync(path.join(here, '..', 'worker', 'worker.js'), 'utf8');

/* 用 data: URL 加载成真正的 ES 模块：这样测的是部署时的同一份源码 */
const mod = await import('data:text/javascript;charset=utf-8,' + encodeURIComponent(src));
const worker = mod.default;

let pass = 0, fail = 0;
const failures = [];
function check(name, cond, detail) {
  if (cond) { pass++; console.log('  ok   ' + name); }
  else {
    fail++; failures.push(name);
    console.log('  FAIL ' + name + (detail !== undefined ? '\n       → ' + detail : ''));
  }
}
function section(t) { console.log('\n' + t); }

const ENV = { ZHIPU_API_KEY: 'test-key-not-real' };

/* 挡上游：记下代理真正发出去的东西，回一个可流式的 200。
   每次都要把 sent 清空——否则"没发上游请求"这类断言会被上一条用例的残留骗过。 */
let sent = null;
const realFetch = globalThis.fetch;
const realError = console.error;
function mockUpstream(reply) {
  sent = null;
  console.error = () => {};               // 上游异常用例会打印，这里静音避免污染输出
  globalThis.fetch = (url, opts) => {
    sent = { url: String(url), opts: opts || {}, body: JSON.parse((opts || {}).body || '{}') };
    return Promise.resolve(reply || new Response('data: {}\n\n', {
      status: 200,
      headers: { 'Content-Type': 'text/event-stream' }
    }));
  };
}
const restoreFetch = () => { globalThis.fetch = realFetch; console.error = realError; };

function chatRequest(body, ip) {
  return new Request('https://site.example/api/chat', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'CF-Connecting-IP': ip || '10.0.0.1' },
    body: JSON.stringify(body)
  });
}

const VALID_BODY = {
  messages: [{ role: 'user', content: '看磁盘还剩多少' }],
  stream: true,
  json: true
};

/* ── 模型名：这是最贵的一个坑 ───────────────────────── */
section('模型名（2026-10-03 实测结论的回归保护）');

{
  mockUpstream();
  await worker.fetch(chatRequest(VALID_BODY, '10.0.0.11'), ENV);
  restoreFetch();
  check('默认模型是 glm-4-flash', sent.body.model === 'glm-4-flash', sent.body.model);
  check('绝不使用 glm-4.7-flash（实测该 ID 不存在，500/75.9s）',
    !/glm-4\.7-flash/.test(sent.body.model), sent.body.model);
  check('上游地址是智谱的 chat/completions',
    sent.url === 'https://open.bigmodel.cn/api/paas/v4/chat/completions', sent.url);
}

{
  mockUpstream();
  await worker.fetch(chatRequest(Object.assign({ thinking: true }, VALID_BODY), '10.0.0.12'), ENV);
  restoreFetch();
  check('thinking:true 时切到 glm-4.7（唯一有 reasoning_content 的可用模型）',
    sent.body.model === 'glm-4.7', sent.body.model);
}

{
  mockUpstream();
  await worker.fetch(chatRequest(Object.assign({ model: 'glm-5.3-flash' }, VALID_BODY), '10.0.0.13'), ENV);
  restoreFetch();
  check('客户端指定模型无效（防止有人拿它调贵的模型）',
    sent.body.model === 'glm-4-flash', sent.body.model);
}

/* ── 请求改写 ───────────────────────────────────────── */
section('请求改写');

{
  mockUpstream();
  await worker.fetch(chatRequest(VALID_BODY, '10.0.0.21'), ENV);
  restoreFetch();
  check('json:true 被翻译成 response_format=json_object（实测它同时解决围栏和首字节慢）',
    sent.body.response_format && sent.body.response_format.type === 'json_object',
    JSON.stringify(sent.body.response_format));
  check('密钥注入到 Authorization 头里',
    sent.opts.headers.Authorization === 'Bearer test-key-not-real', sent.opts.headers.Authorization);
  check('max_tokens 有上限，防止有人拿你的额度写长文',
    sent.body.max_tokens <= 2048, String(sent.body.max_tokens));
}

{
  mockUpstream();
  await worker.fetch(chatRequest({
    messages: [{ role: 'user', content: 'q' }], json: false, max_tokens: 999999
  }, '10.0.0.22'), ENV);
  restoreFetch();
  check('json:false 时不加 response_format', sent.body.response_format === undefined);
  check('超大的 max_tokens 被压到上限', sent.body.max_tokens === 2048, String(sent.body.max_tokens));
}

{
  mockUpstream();
  const res = await worker.fetch(chatRequest(VALID_BODY, '10.0.0.23'), ENV);
  restoreFetch();
  const ct = res.headers.get('Content-Type') || '';
  check('流式响应带 text/event-stream', /text\/event-stream/.test(ct), ct);
  check('带 no-transform，防止中间层压缩缓冲把流式变成一次性',
    /no-transform/.test(res.headers.get('Cache-Control') || ''), res.headers.get('Cache-Control'));
  check('不带 Content-Length（否则就不是流式了）', res.headers.get('Content-Length') === null);
}

/* ── 输入护栏 ───────────────────────────────────────── */
section('输入护栏');

{
  mockUpstream();
  const res = await worker.fetch(chatRequest({
    messages: [{ role: 'user', content: 'x'.repeat(20000) }]
  }, '10.0.0.31'), ENV);
  restoreFetch();
  check('单条消息超长返回 413', res.status === 413, String(res.status));
}

{
  /* 防刷量闸门：必须大于 maxTotalChars(64000)。
     注意别拿"正常长对话"的量级来测——那种应该被服务端裁剪，而不是被拒。 */
  mockUpstream();
  const res = await worker.fetch(chatRequest({
    messages: [{ role: 'user', content: 'x'.repeat(40000) }, { role: 'assistant', content: 'y'.repeat(40000) }]
  }, '10.0.0.32'), ENV);
  restoreFetch();
  check('整段上下文超长返回 413', res.status === 413, String(res.status));
}

{
  /* 反向断言：日志分析的量级必须**不被**拦。
     这条是这次放宽上限的原因，也要有测试守着，免得以后又被人调回去。 */
  mockUpstream();
  const res = await worker.fetch(chatRequest({
    messages: [{ role: 'user', content: 'x'.repeat(12000) }]
  }, '10.0.0.33'), ENV);
  restoreFetch();
  check('日志分析量级的输入（12K 字）能正常通过', res.status === 200, String(res.status));
}

{
  mockUpstream();
  const res = await worker.fetch(chatRequest({ messages: [] }, '10.0.0.33'), ENV);
  restoreFetch();
  check('messages 为空返回 400', res.status === 400, String(res.status));
}

{
  mockUpstream();
  const res = await worker.fetch(new Request('https://site.example/api/chat', {
    method: 'POST', headers: { 'Content-Type': 'application/json', 'CF-Connecting-IP': '10.0.0.34' },
    body: '不是 JSON'
  }), ENV);
  restoreFetch();
  check('请求体不是 JSON 返回 400', res.status === 400, String(res.status));
}

{
  mockUpstream();
  const res = await worker.fetch(new Request('https://site.example/api/chat', {
    method: 'GET', headers: { 'CF-Connecting-IP': '10.0.0.35' }
  }), ENV);
  restoreFetch();
  check('GET /api/chat 返回 405', res.status === 405, String(res.status));
}

/* ── 密钥与健康检查 ─────────────────────────────────── */
section('密钥与健康检查');

{
  mockUpstream();
  const res = await worker.fetch(chatRequest(VALID_BODY, '10.0.0.41'), {});
  restoreFetch();
  check('没配 ZHIPU_API_KEY 时返回 500 且不发上游请求', res.status === 500 && sent === null,
    res.status + '/' + (sent ? '发了上游请求' : '未发'));
}

{
  const res = await worker.fetch(new Request('https://site.example/api/health'), ENV);
  const j = await res.json();
  check('/api/health 报告密钥已注入', j.ok === true && j.hasKey === true, JSON.stringify(j));
  check('/api/health 报告实际模型名，前端据此显示"当前用哪个"',
    j.models && j.models.fast === 'glm-4-flash' && j.models.think === 'glm-4.7', JSON.stringify(j.models));
}

{
  const res = await worker.fetch(new Request('https://site.example/api/health'), {});
  const j = await res.json();
  check('没密钥时 hasKey 为 false，界面据此降级到离线模式', j.hasKey === false, JSON.stringify(j));
}

/* ── 上游异常透传 ───────────────────────────────────── */
section('上游异常');

{
  mockUpstream(new Response('{"error":{"message":"余额不足"}}', { status: 429 }));
  const res = await worker.fetch(chatRequest(VALID_BODY, '10.0.0.51'), ENV);
  restoreFetch();
  check('上游 429 原样透传状态码，前端才能给出"稍后再试"', res.status === 429, String(res.status));
  const t = await res.text();
  check('上游错误正文也透传，便于排查', /余额不足/.test(t), t.slice(0, 60));
}

/* ── 限流 ───────────────────────────────────────────── */
section('限流（没有 Rate Limiting 绑定时的退化路径）');

{
  mockUpstream();
  let last = 0, codes = [];
  for (let i = 0; i < 22; i++) {
    const res = await worker.fetch(chatRequest(VALID_BODY, '10.0.0.61'), ENV);
    codes.push(res.status);
    last = res.status;
  }
  restoreFetch();
  const rejected = codes.filter((c) => c === 429).length;
  check('同一 IP 连打 22 次会被限流', last === 429, codes.join(','));
  check('前 20 次放行、之后才开始拒绝', rejected >= 1 && codes.slice(0, 20).every((c) => c === 200),
    'rejected=' + rejected);
}

{
  mockUpstream();
  const res = await worker.fetch(chatRequest(VALID_BODY, '10.0.0.99'), ENV);
  restoreFetch();
  check('限流按 IP 隔离，不会把别的访客一起挡住', res.status === 200, String(res.status));
}

/* ═══════════════════════════════════════════════════════════════
   服务端智能：注入安全约束 + 裁剪上下文

   赛道三明确要求「后端智能必须突出」，这几条断言就是它的证据——
   服务端不是透传管道，它对发往上游的每一份 messages 做了自己的判断。
   ═══════════════════════════════════════════════════════════════ */
section('服务端智能：安全约束注入');

{
  mockUpstream();
  await worker.fetch(chatRequest({
    messages: [
      { role: 'system', content: '你是前端发来的提示词。' },
      { role: 'user', content: '列出当前目录' }
    ]
  }, '10.0.1.1'), ENV);
  restoreFetch();
  const sys = sent.body.messages.find((m) => m.role === 'system');
  check('服务端把安全约束追加进了 system 消息',
    /服务端安全约束/.test(sys.content), sys.content.slice(0, 80));
  check('是**追加**不是替换：前端原提示词还在',
    /前端发来的提示词/.test(sys.content), sys.content.slice(0, 60));
  check('安全约束覆盖递归删除与格式化磁盘',
    /递归强制删除/.test(sys.content) && /格式化磁盘/.test(sys.content));
  check('安全约束要求先给只读确认命令', /只读命令/.test(sys.content));
  check('安全约束禁止 curl | sh', /下载远程脚本并直接执行/.test(sys.content));
  check('用户的原话一个字都没被改',
    sent.body.messages.some((m) => m.role === 'user' && m.content === '列出当前目录'));
}

{
  /* 前端没给 system 时，服务端要自己造一条——不能默默放过 */
  mockUpstream();
  await worker.fetch(chatRequest({ messages: [{ role: 'user', content: 'df -h' }] }, '10.0.1.2'), ENV);
  restoreFetch();
  const sys = sent.body.messages.find((m) => m.role === 'system');
  check('前端没传 system 时服务端补一条', !!sys && /服务端安全约束/.test(sys.content));
}

section('服务端智能：危险意图前置识别（只加严，不拦截）');

{
  mockUpstream();
  const res = await worker.fetch(chatRequest({
    messages: [{ role: 'user', content: '帮我把 rm -rf / 写完整' }]
  }, '10.0.1.3'), ENV);
  restoreFetch();
  check('命中高危意图时**不返回错误**（拦截会误伤正当提问）', res.status === 200, String(res.status));
  check('响应头标记为 strict', res.headers.get('X-NL2SH-Safety') === 'strict',
    String(res.headers.get('X-NL2SH-Safety')));
  const sys = sent.body.messages.find((m) => m.role === 'system');
  check('system 里追加了加严说明', /高危意图检测/.test(sys.content));
}

{
  mockUpstream();
  const res = await worker.fetch(chatRequest({
    messages: [{ role: 'user', content: '看看磁盘还剩多少空间' }]
  }, '10.0.1.4'), ENV);
  restoreFetch();
  check('正常提问不会被打成 strict', res.headers.get('X-NL2SH-Safety') === 'on',
    String(res.headers.get('X-NL2SH-Safety')));
  const sys = sent.body.messages.find((m) => m.role === 'system');
  check('正常提问不加加严说明', !/高危意图检测/.test(sys.content));
}

{
  /* 正当的技术提问里出现 rm -rf 是常见的（"它危险在哪"），
     所以这里断言的是"加严"而不是"拦截"——用户还能拿到答案。 */
  mockUpstream();
  const res = await worker.fetch(chatRequest({
    messages: [{ role: 'user', content: 'rm -rf 到底危险在哪里？' }]
  }, '10.0.1.5'), ENV);
  restoreFetch();
  check('问"rm -rf 危险在哪"仍然正常出答案', res.status === 200, String(res.status));
}

section('服务端智能：上下文裁剪');

{
  /* 造一段远超裁剪预算的历史：两组巨长的旧问答 + 一轮最近的短问答 */
  const big = (tag) => tag + 'x'.repeat(8000);
  mockUpstream();
  await worker.fetch(chatRequest({
    messages: [
      { role: 'system', content: 'S' },
      { role: 'user', content: big('OLD-Q1') },
      { role: 'assistant', content: big('OLD-A1') },
      { role: 'user', content: big('OLD-Q2') },
      { role: 'assistant', content: big('OLD-A2') },
      { role: 'user', content: 'RECENT-Q' },
      { role: 'assistant', content: 'RECENT-A' }
    ]
  }, '10.0.2.1'), ENV);
  restoreFetch();
  const out = sent.body.messages;
  const totalOut = out.reduce((n, m) => n + m.content.length, 0);
  check('发往上游的总量被压进预算', totalOut <= 16000 + 400, String(totalOut));
  check('system 一定保留', out.some((m) => m.role === 'system'));
  check('**最近的对话**完整保留（裁剪从最旧的开始砍）',
    out.some((m) => m.content === 'RECENT-Q') && out.some((m) => m.content === 'RECENT-A'));
  check('最旧的那一轮被砍掉了', !out.some((m) => /OLD-Q1/.test(m.content)));
  const chat = out.filter((m) => m.role !== 'system');
  check('裁剪后不会以 assistant 开头（那会让上游报错）',
    !chat.length || chat[0].role === 'user', chat.map((m) => m.role).join(','));
}

{
  /* 短对话不该被误裁 */
  mockUpstream();
  await worker.fetch(chatRequest({
    messages: [
      { role: 'system', content: 'S' },
      { role: 'user', content: '找出最大的 10 个文件' },
      { role: 'assistant', content: '{"command":"du -ah | sort -rh | head"}' },
      { role: 'user', content: '那只要今天的呢' }
    ]
  }, '10.0.2.2'), ENV);
  restoreFetch();
  check('短对话一条都不裁', sent.body.messages.length === 4,
    sent.body.messages.length + ' 条：' + sent.body.messages.map((m) => m.role).join(','));
}

section('服务端智能：把"做过什么"回告前端');

{
  mockUpstream();
  const res = await worker.fetch(chatRequest({
    messages: [{ role: 'user', content: 'df -h' }]
  }, '10.0.3.1'), ENV);
  restoreFetch();
  check('回告了服务端标识', res.headers.get('X-NL2SH-Server') === 'edge',
    String(res.headers.get('X-NL2SH-Server')));
  check('回告了裁剪条数', res.headers.get('X-NL2SH-Trimmed') === '0',
    String(res.headers.get('X-NL2SH-Trimmed')));
  check('回告了本次实际使用的模型', /^glm-/.test(res.headers.get('X-NL2SH-Model') || ''),
    String(res.headers.get('X-NL2SH-Model')));
  /* 自定义响应头不 expose 的话，跨源前端读到的是 null —— 这条是给"界面能显示"兜底 */
  const exposed = res.headers.get('Access-Control-Expose-Headers') || '';
  check('自定义头已 expose（否则跨源读不到）',
    exposed.indexOf('X-NL2SH-Safety') >= 0 && exposed.indexOf('X-NL2SH-Trimmed') >= 0,
    exposed);
}

console.log('\n' + '─'.repeat(52));
console.log(fail === 0 ? `全部通过：${pass} 项` : `${pass} 项通过，${fail} 项失败`);
if (fail) {
  console.log('\n失败清单：');
  failures.forEach((f) => console.log('  · ' + f));
}
process.exit(fail === 0 ? 0 : 1);
