/* nl2sh · 粒子引擎
 *
 * 设计原则：粒子必须承载信息，不做装饰。
 *   · 环境字符场 —— 粒子是终端字符（> _ $ | 0 1），不是圆点；连线编码邻近关系
 *   · 管道粒子流 —— 沿命令从左向右流动，"经过"某个零件时点亮，表达管道语义
 *   · 执行爆散   —— 沙箱真跑时粒子从按钮放射，撤销时反向回流
 *
 * 性能与可访问性：
 *   · DPR 上限 2，粒子数按面积估算并封顶
 *   · 页面隐藏 / canvas 离开视口时暂停
 *   · prefers-reduced-motion 下只画一帧静态画面，不起循环
 */
window.NL2SH_FX = (function () {
  'use strict';

  /* 只用命令行的字符，和主题同源 */
  var GLYPHS = ['>', '_', '$', '|', '/', '~', '#', '0', '1', '{', '}', '[', ']', ':', ';', '+', '=', '*', '-'];

  var REDUCED = !!(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);

  function themeColors(el) {
    var cs = getComputedStyle(el || document.documentElement);
    function pick(name, fallback) {
      var v = (cs.getPropertyValue(name) || '').trim();
      return v || fallback;
    }
    return {
      dot: pick('--signal', '#0b6ba8'),
      line: pick('--rule-strong', '#93aabd'),
      glyph: pick('--ink-3', '#7e97ad'),
      warn: pick('--caution', '#a8640a'),
      bad: pick('--danger', '#b33325'),
      safe: pick('--safe', '#0d7466')
    };
  }

  function dpr() { return Math.min(window.devicePixelRatio || 1, 2); }

  function fitCanvas(canvas) {
    var rect = canvas.getBoundingClientRect();
    var r = dpr();
    var w = Math.max(1, Math.round(rect.width));
    var h = Math.max(1, Math.round(rect.height));
    if (canvas.width !== w * r || canvas.height !== h * r) {
      canvas.width = w * r;
      canvas.height = h * r;
    }
    var ctx = canvas.getContext('2d');
    ctx.setTransform(r, 0, 0, r, 0, 0);
    return { w: w, h: h, ctx: ctx };
  }

  /* ── 环境字符场（铺满视口，垫在内容下面）──────────────── */
  function Field(canvas) {
    this.canvas = canvas;
    this.colors = themeColors();
    this.particles = [];
    this.bursts = [];
    this.pointer = { x: -9999, y: -9999, active: false };
    this.running = false;
    this.visible = true;
    this.raf = 0;
    this.last = 0;

    var self = this;
    this._measure();
    this._seed();
    this._drawOnce();          // 先出一帧：首屏不空白，rAF 迟到也不影响观感
    this._bind();
    this.start();

    window.addEventListener('resize', function () { self._debouncedResize(); }, { passive: true });
  }

  Field.prototype._measure = function () {
    var m = fitCanvas(this.canvas);
    this.w = m.w;
    this.h = m.h;
    this.ctx = m.ctx;
  };

  Field.prototype._count = function () {
    var area = this.w * this.h;
    var n = Math.round(area * 0.000088);           // 面积密度
    var cap = this.w < 700 ? 46 : 130;             // 移动端降量
    return Math.max(20, Math.min(cap, n));
  };

  Field.prototype._seed = function () {
    var n = this._count();
    this.particles = [];
    for (var i = 0; i < n; i++) this.particles.push(this._spawn());
  };

  Field.prototype._spawn = function () {
    var isGlyph = Math.random() < 0.34;
    return {
      x: Math.random() * this.w,
      y: Math.random() * this.h,
      vx: (Math.random() - 0.5) * 0.34,
      vy: (Math.random() - 0.5) * 0.34,
      r: isGlyph ? 11 + Math.random() * 5 : 1.1 + Math.random() * 1.5,
      a: 0.26 + Math.random() * 0.38,
      glyph: isGlyph ? GLYPHS[(Math.random() * GLYPHS.length) | 0] : '',
      isGlyph: isGlyph
    };
  };

  Field.prototype._bind = function () {
    var self = this;
    window.addEventListener('pointermove', function (e) {
      self.pointer.x = e.clientX;
      self.pointer.y = e.clientY;
      self.pointer.active = true;
    }, { passive: true });
    window.addEventListener('pointerleave', function () { self.pointer.active = false; }, { passive: true });
    document.addEventListener('visibilitychange', function () {
      if (document.hidden) self.pause(); else self.start();
    });
    if (window.ResizeObserver) {
      var ro = new ResizeObserver(function () { self._debouncedResize(); });
      ro.observe(document.documentElement);
    }
  };

  Field.prototype._debouncedResize = function () {
    var self = this;
    clearTimeout(this._rz);
    this._rz = setTimeout(function () {
      var ratioChanged = Math.abs(self.w - document.documentElement.clientWidth) > 4;
      self._measure();
      if (ratioChanged || self.particles.length !== self._count()) self._seed();
      self._drawOnce();
    }, 140);
  };

  Field.prototype.setTheme = function () {
    this.colors = themeColors();
    this._drawOnce();
  };

  Field.prototype.burst = function (x, y, opts) {
    opts = opts || {};
    var n = opts.count || 16;
    var power = opts.power || 2.6;
    var glyphs = opts.glyphs || GLYPHS;
    for (var i = 0; i < n; i++) {
      var ang = (Math.PI * 2 * i) / n + Math.random() * 0.5;
      var sp = power * (0.4 + Math.random() * 0.8);
      this.bursts.push({
        x: x, y: y,
        vx: Math.cos(ang) * sp,
        vy: Math.sin(ang) * sp,
        life: 1,
        decay: 0.014 + Math.random() * 0.016,
        glyph: Math.random() < 0.5 ? glyphs[(Math.random() * glyphs.length) | 0] : '',
        color: opts.color || this.colors.dot,
        r: 1 + Math.random() * 1.6
      });
    }
    if (!REDUCED) this.start();
  };

  Field.prototype.start = function () {
    if (REDUCED) { this._drawOnce(); return; }
    if (this.running || document.hidden) return;
    this.running = true;
    var self = this;
    this.last = performance.now();
    (function loop(now) {
      if (!self.running) return;
      var dt = Math.min(34, now - self.last);
      self.last = now;
      self._step(dt);
      self._draw();
      self.raf = requestAnimationFrame(loop);
    })(this.last);
  };

  Field.prototype.pause = function () {
    this.running = false;
    if (this.raf) cancelAnimationFrame(this.raf);
    this.raf = 0;
  };

  Field.prototype._step = function (dt) {
    var f = dt / 16.67;
    for (var i = 0; i < this.particles.length; i++) {
      var p = this.particles[i];
      p.x += p.vx * f;
      p.y += p.vy * f;

      /* 指针排斥：让场对鼠标有反应，但很轻 */
      if (this.pointer.active) {
        var dx = p.x - this.pointer.x, dy = p.y - this.pointer.y;
        var d2 = dx * dx + dy * dy;
        if (d2 < 13000 && d2 > 1) {
          var d = Math.sqrt(d2);
          var push = (1 - d / 114) * 0.34;
          p.x += (dx / d) * push * f;
          p.y += (dy / d) * push * f;
        }
      }

      if (p.x < -20) p.x = this.w + 20;
      if (p.x > this.w + 20) p.x = -20;
      if (p.y < -20) p.y = this.h + 20;
      if (p.y > this.h + 20) p.y = -20;
    }
    for (var b = this.bursts.length - 1; b >= 0; b--) {
      var q = this.bursts[b];
      q.x += q.vx * f; q.y += q.vy * f;
      q.vx *= 0.965; q.vy *= 0.965;
      q.life -= q.decay * f;
      if (q.life <= 0) this.bursts.splice(b, 1);
    }
  };

  Field.prototype._draw = function () {
    var ctx = this.ctx, c = this.colors;
    ctx.clearRect(0, 0, this.w, this.h);

    var ps = this.particles;
    /* 邻近连线：先画线，让点和字符盖在上面 */
    if (this.w >= 700) {
      ctx.lineWidth = 1;
      var limit = 138, limit2 = limit * limit;
      for (var i = 0; i < ps.length; i++) {
        for (var j = i + 1; j < ps.length; j++) {
          var dx = ps[i].x - ps[j].x, dy = ps[i].y - ps[j].y;
          var d2 = dx * dx + dy * dy;
          if (d2 > limit2) continue;
          var t = 1 - d2 / limit2;
          ctx.strokeStyle = c.line;
          ctx.globalAlpha = t * 0.21;
          ctx.beginPath();
          ctx.moveTo(ps[i].x, ps[i].y);
          ctx.lineTo(ps[j].x, ps[j].y);
          ctx.stroke();
        }
      }
    }

    for (var k = 0; k < ps.length; k++) {
      var p = ps[k];
      if (p.isGlyph) {
        ctx.globalAlpha = p.a;
        ctx.fillStyle = c.glyph;
        ctx.font = '500 ' + Math.round(p.r) + 'px Consolas, "Cascadia Mono", monospace';
        ctx.fillText(p.glyph, p.x, p.y);
      } else {
        ctx.globalAlpha = p.a;
        ctx.fillStyle = c.dot;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.r, 0, 6.2832);
        ctx.fill();
      }
    }

    for (var b = 0; b < this.bursts.length; b++) {
      var q = this.bursts[b];
      ctx.globalAlpha = Math.max(0, q.life) * 0.85;
      ctx.fillStyle = q.color;
      if (q.glyph) {
        ctx.font = '600 11px Consolas, "Cascadia Mono", monospace';
        ctx.fillText(q.glyph, q.x, q.y);
      } else {
        ctx.beginPath();
        ctx.arc(q.x, q.y, q.r * q.life, 0, 6.2832);
        ctx.fill();
      }
    }
    ctx.globalAlpha = 1;
  };

  Field.prototype._drawOnce = function () {
    this._measure();
    this._draw();
  };

  /* ── 管道粒子流（沿命令从左往右）──────────────────────
     这就是"管道"的物理隐喻：数据从左边流进，从右边流出。
     经过某个零件（token）的横向范围时，粒子提亮。 */
  function Flow(canvas, opts) {
    this.canvas = canvas;
    this.getBand = opts.getBand;
    this.tokens = opts.getTokens || function () { return []; };
    this.colors = themeColors();
    this.parts = [];
    this.running = false;
    this.raf = 0;
    this.acc = 0;

    var self = this;
    this._measure();
    this._prime();             // 预置粒子铺在管道上，首帧就能看到流动带
    this._drawOnce();
    window.addEventListener('resize', function () { self._measure(); self._prime(); self._drawOnce(); }, { passive: true });
    if (window.ResizeObserver) {
      var ro = new ResizeObserver(function () { self._measure(); self._drawOnce(); });
      ro.observe(canvas.parentElement || canvas);
    }
    document.addEventListener('visibilitychange', function () {
      if (document.hidden) self.pause(); else self.start();
    });
    this.start();
  }

  /** 沿管道铺一批粒子（位置随机），让静态首帧也有内容 */
  Flow.prototype._prime = function () {
    var band = this._band();
    if (!band || band.right <= band.left) return;
    this.parts = [];
    for (var i = 0; i < 26; i++) {
      this.parts.push({
        x: band.left + Math.random() * (band.right - band.left),
        y: band.y + (Math.random() - 0.5) * 18,
        v: 1.0 + Math.random() * 1.7,
        a: 0.34 + Math.random() * 0.46,
        glyph: Math.random() < 0.42 ? GLYPHS[(Math.random() * GLYPHS.length) | 0] : '',
        life: 1
      });
    }
  };

  Flow.prototype._measure = function () {
    var m = fitCanvas(this.canvas);
    this.w = m.w; this.h = m.h; this.ctx = m.ctx;
  };

  Flow.prototype._band = function () {
    if (!this.getBand) return null;
    var host = this.canvas.parentElement;
    if (!host) return null;
    var hr = host.getBoundingClientRect();
    var br = this.getBand().getBoundingClientRect();
    if (!br.width) return null;
    return { left: br.left - hr.left, right: br.right - hr.left, y: br.top - hr.top + br.height / 2 };
  };

  Flow.prototype._tokenSpans = function () {
    var host = this.canvas.parentElement;
    if (!host) return [];
    var hr = host.getBoundingClientRect();
    return this.tokens().map(function (el) {
      var r = el.getBoundingClientRect();
      return { l: r.left - hr.left, r: r.right - hr.left, hot: el.classList.contains('is-lit') };
    });
  };

  Flow.prototype.start = function () {
    if (REDUCED) { this._drawOnce(); return; }
    if (this.running || document.hidden) return;
    this.running = true;
    var self = this;
    (function loop() {
      if (!self.running) return;
      self._step();
      self._draw();
      self.raf = requestAnimationFrame(loop);
    })();
  };

  Flow.prototype.pause = function () {
    this.running = false;
    if (this.raf) cancelAnimationFrame(this.raf);
    this.raf = 0;
  };

  Flow.prototype.setTheme = function () { this.colors = themeColors(); this._drawOnce(); };

  Flow.prototype._step = function () {
    var band = this._band();
    if (!band) return;
    this.acc += 1;
    if (this.acc % 5 === 0) {
      this.parts.push({
        x: band.left - 8,
        y: band.y + (Math.random() - 0.5) * 18,
        v: 1.0 + Math.random() * 1.7,
        a: 0.34 + Math.random() * 0.46,
        glyph: Math.random() < 0.42 ? GLYPHS[(Math.random() * GLYPHS.length) | 0] : '',
        life: 1
      });
    }
    for (var i = this.parts.length - 1; i >= 0; i--) {
      var p = this.parts[i];
      p.x += p.v;
      if (p.x > band.right + 12) { this.parts.splice(i, 1); continue; }
      if (p.life < 1) p.life = Math.min(1, p.life + 0.08);
    }
  };

  Flow.prototype._draw = function () {
    var ctx = this.ctx, c = this.colors;
    ctx.clearRect(0, 0, this.w, this.h);
    var band = this._band();
    if (!band) return;
    var spans = this._tokenSpans();

    for (var i = 0; i < this.parts.length; i++) {
      var p = this.parts[i];
      var hot = false;
      for (var s = 0; s < spans.length; s++) {
        if (p.x >= spans[s].l && p.x <= spans[s].r) { hot = true; break; }
      }
      var alpha = p.a * p.life * (hot ? 1 : 0.62);
      var color = hot ? c.warn : c.dot;

      /* 拖尾：固定长度线段，读起来就是"在流动" */
      var trail = p.v * 9;
      ctx.globalAlpha = alpha * 0.42;
      ctx.strokeStyle = color;
      ctx.lineWidth = hot ? 1.4 : 1;
      ctx.beginPath();
      ctx.moveTo(p.x - trail, p.y);
      ctx.lineTo(p.x, p.y);
      ctx.stroke();

      ctx.globalAlpha = alpha;
      ctx.fillStyle = color;
      if (p.glyph) {
        ctx.font = '600 12px Consolas, "Cascadia Mono", monospace';
        ctx.fillText(p.glyph, p.x, p.y + 4);
      } else {
        ctx.beginPath();
        ctx.arc(p.x, p.y, hot ? 2.3 : 1.5, 0, 6.2832);
        ctx.fill();
      }
    }
    ctx.globalAlpha = 1;
  };

  Flow.prototype._drawOnce = function () { this._measure(); this._draw(); };

  /* ── 对外接口 ─────────────────────────────────────── */
  var api = {
    reduced: REDUCED,
    Field: Field,
    Flow: Flow,
    colors: themeColors
  };

  api.init = function (opts) {
    var out = { field: null, flow: null };
    var el = typeof opts.field === 'string' ? document.querySelector(opts.field) : opts.field;
    if (el && el.getContext) out.field = new Field(el);
    var fl = typeof opts.flow === 'string' ? document.querySelector(opts.flow) : opts.flow;
    if (fl && fl.getContext && opts.getBand) {
      out.flow = new Flow(fl, { getBand: opts.getBand, getTokens: opts.getTokens });
    }
    out.setTheme = function () {
      if (out.field) out.field.setTheme();
      if (out.flow) out.flow.setTheme();
    };
    out.burst = function (x, y, o) { if (out.field) out.field.burst(x, y, o); };
    /* 在某个元素中心爆散（用视口坐标，因为 field 是 position:fixed） */
    out.burstAt = function (target, o) {
      var node = typeof target === 'string' ? document.querySelector(target) : target;
      if (!node || !out.field) return;
      var r = node.getBoundingClientRect();
      out.field.burst(r.left + r.width / 2, r.top + r.height / 2, o);
    };
    return out;
  };

  return api;
})();
