# 方案 C 操作手册 · 把 AI 代理做成 Pages 的同域函数（最省事的一条）

> **为什么值得做**：现在 AI 住在 `nl2sh-api.zibochen82.workers.dev`，
> 而作品页面住在别处——**这是两个域名，页面能打开不代表 AI 能用**。
> 把代理作为 `_worker.js` 放进 Pages 项目之后，`/api/chat` 变成**同域**：
> 前端那句"优先请求同源"直接命中，**不需要 FALLBACK_ORIGIN、不需要跨源、没有预检**。
>
> 少一个域名，就少一个失败点。
>
> ⚠️ **但它不等于解决了"国内可达"**：`pages.dev` 与 `workers.dev` 都是 Cloudflare 的通配域名，
> 同族同命。**真正的国内可达仍然要靠 `EdgeOne函数代理-操作步骤.md`。**
> 这一步的价值是"把两个域名合成一个"，成本几乎为零，所以顺手做掉。

---

## 官方依据

Cloudflare 文档（[Advanced mode](https://developers.cloudflare.com/pages/functions/advanced-mode/)）原话：

> To migrate an existing Worker to your Pages project, **copy your Worker code and paste it into your new
> `_worker.js` file**. Then handle static assets by adding: `return env.ASSETS.fetch(request);`

也就是说：**我们的 `worker/worker.js` 几乎原样就能用**，只需补一句静态资源回退
（`_worker.js` 会接管**全部**请求，少了这句页面本身就白屏）。

那一句已经由脚本生成好了，**不用你手抄**：

```bash
node scripts/build-pages-worker.mjs
```

它会产出 `deploy/cloudflare-pages/_worker.js`，并备好一个**可直接拖**的文件夹：

```
D:\上传到CloudflarePages\
├─ index.html      478 KB
└─ _worker.js       14 KB
```

---

## 操作步骤

### 第 1 步：给 Pages 项目配环境变量（**这一步不做，代理会返回 500**）

进入你在 Cloudflare Pages 上的项目 → **Settings → Environment variables** → 添加：

| 名称 | 值 | 环境 |
|---|---|---|
| `ZHIPU_API_KEY` | 你的智谱 key（和 Worker 里那个同一个） | Production（建议 Preview 也加） |

密钥只存在服务端，**前端依然没有**。

### 第 2 步：把两个文件一起拖上去

把 `D:\上传到CloudflarePages\` **整个文件夹**拖进 Pages 的上传区
（⚠️ 不是只拖 `index.html`——少了 `_worker.js` 代理就不存在）。

### 第 3 步：验证（两条都要过）

1. **静态页没坏**：打开 `https://nl2sh.pages.dev/` → 首屏正常，顶栏显示作品身份
2. **代理活着**：打开 `https://nl2sh.pages.dev/api/health`
   → 期望 `{"ok":true,"hasKey":true,...}`

- `/api/health` 返回 500 或 `hasKey:false` → 环境变量没生效（回第 1 步，改完要重新部署）
- 静态页白屏 → `_worker.js` 里的 `env.ASSETS.fetch` 那句丢了，重新生成一次
- 返回 404 → 部署时没把 `_worker.js` 放进根目录

### 第 4 步：换掉前端里的兜底域（可选但建议）

同域之后前端**本来就优先请求同源**，理论上什么都不用改。
但为了在 EdgeOne 那条线也铺好，建议改成"同源优先、兜底域不写死"：

等 EdgeOne 那边的域名上线后，改 `assets/ai.js` 里的 `FALLBACK_ORIGIN` 一行，
然后 `node scripts/build-single.mjs` 重新构建。

---

## 三份代理的关系（别搞混）

| 文件 | 跑在哪 | 国内裸网络 |
|---|---|---|
| `worker/worker.js` | Cloudflare Worker（`workers.dev`） | ✗ 部分网络解析被污染 |
| `deploy/cloudflare-pages/_worker.js` | Cloudflare Pages（`pages.dev`） | ✗ 同族，同命 |
| `deploy/edgeone-functions/` | **EdgeOne Pages（腾讯云国内节点）** | ✅ **这条才是解法** |

三份的加固逻辑由 `scripts/audit.mjs` **行为比对**守着（比常量值 + 用同一组含高危意图的
样例跑一遍 `harden`）——**不靠"记得同步"**。
