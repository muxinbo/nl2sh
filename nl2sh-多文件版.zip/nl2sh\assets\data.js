/* nl2sh · 演示数据
 *
 * 原型不联网。这一层扮演"模型返回的结构化结果"：
 * 接入真实模型后，同样的 JSON 结构由 API 流式返回，
 * 前端渲染逻辑一行都不用改。
 *
 * 字段说明
 *   q      用户那句中文
 *   cmd    生成的命令（anno[].t 必须是 cmd 的子串，用于定位高亮范围）
 *   flow   管道/步骤的流向，可省
 *   risk   safe | caution | danger
 *   why    风险等级的判断依据（显示在风险印章下方）
 *   anno   逐行解释：t 原文片段，short 短标签（解剖图用），n 说明
 *   sim    执行前推演：scope 影响范围，sudo，irreversible，note，tree[] 文件变更
 *   see    SEE ALSO：相关命令
 */
window.NL2SH = {

  hero: {
    cmd: "ps aux | grep nginx | awk '{print $2}' | xargs -r kill -HUP",
    flow: "列出进程 → 筛出 nginx → 取出 PID → 变成参数 → 通知重载配置",
    annos: [
      { t: "ps aux",           short: "列出全部进程",   n: "列出所有进程的完整信息。" },
      { t: "grep nginx",       short: "只留 nginx 的行", n: "从上一段的输出里，只保留名字含 nginx 的行。" },
      { t: "awk '{print $2}'", short: "取出第 2 列",     n: "按空白分列，取出第 2 列——也就是 PID。" },
      { t: "xargs -r",         short: "变成命令参数",    n: "把上一段输出的每一行，变成下一条命令的参数；-r 表示没有输入时不执行。" },
      { t: "kill -HUP",        short: "通知重载配置",    n: "发送 HUP 信号。nginx 收到后会重新读取配置，正在处理的请求不会断。" }
    ]
  },

  items: [
    {
      q: "找出当前目录下最大的 10 个文件",
      cmd: "du -ah . | sort -rh | head -n 10",
      flow: "统计每个文件的大小 → 从大到小排序 → 只留前 10 行",
      risk: "safe",
      why: "只读取文件大小，不写入、不删除任何内容。",
      anno: [
        { t: "du -ah .", n: "du 统计磁盘占用；-a 连普通文件一起列（默认只列目录），-h 换成人看得懂的单位（K/M/G）。" },
        { t: "sort -rh", n: "sort 排序；-r 从大到小，-h 按人类可读的容量比较——不加 -h 的话 9M 会排在 10K 前面。" },
        { t: "head -n 10", n: "只保留前 10 行，后面的直接丢掉。" }
      ],
      sim: {
        scope: "只读", sudo: false, irreversible: false,
        note: "不会写入、修改或删除任何文件。",
        tree: [{ p: "./", s: "read" }, { p: "./ 下所有子目录", s: "read" }]
      },
      see: ["du -sh * | sort -rh | head", "find . -type f -size +100M", "ncdu ."]
    },
    {
      q: "看看是谁占着我的 80 端口",
      cmd: "sudo ss -lptn 'sport = :80'",
      risk: "caution",
      why: "只是查看，但要管理员权限才能看到别人的进程名。",
      anno: [
        { t: "sudo", n: "以管理员权限运行。看不到进程名的时候，通常就是漏了它。" },
        { t: "ss -lptn", n: "ss 查看网络连接：-l 只看正在监听的，-p 显示进程，-t 只看 TCP，-n 不做域名和服务名解析（更快、更准）。" },
        { t: "'sport = :80'", n: "过滤条件：只看本地（source）80 端口。" }
      ],
      sim: {
        scope: "只读", sudo: true, irreversible: false,
        note: "只查询内核里的连接表，不改动任何配置。",
        tree: [{ p: "内核连接表", s: "read" }]
      },
      see: ["lsof -i :80", "fuser -n tcp 80", "systemctl status nginx"]
    },
    {
      q: "找出昨天修改过的所有文件",
      cmd: "find . -type f -newermt yesterday ! -newermt today",
      risk: "safe",
      why: "只遍历目录读取时间戳。",
      anno: [
        { t: "find .", n: "从当前目录开始递归查找。" },
        { t: "-type f", n: "只要普通文件，排除目录、软链接等。" },
        { t: "-newermt yesterday", n: "修改时间晚于昨天零点。" },
        { t: "! -newermt today", n: "并且不晚于今天零点。两个条件一起，才夹出「昨天一整天」。" }
      ],
      sim: {
        scope: "只读", sudo: false, irreversible: false,
        note: "只读时间戳，不改动文件。",
        tree: [{ p: "./", s: "read" }]
      },
      see: ["find . -type f -mtime -1", "find . -type f -newer marker.txt"]
    },
    {
      q: "实时盯着 nginx 的错误日志",
      cmd: "tail -f /var/log/nginx/error.log",
      risk: "safe",
      why: "只读日志文件。",
      anno: [
        { t: "tail", n: "显示文件末尾的内容。" },
        { t: "-f", n: "follow：文件被追加新内容时持续输出。按 Ctrl+C 退出。" },
        { t: "/var/log/nginx/error.log", n: "nginx 的错误日志路径，实际路径以你的配置文件为准。" }
      ],
      sim: {
        scope: "只读", sudo: false, irreversible: false,
        note: "会一直占用这个终端窗口，直到你按 Ctrl+C。",
        tree: [{ p: "/var/log/nginx/error.log", s: "read" }]
      },
      see: ["tail -n 200 /var/log/nginx/error.log", "journalctl -u nginx -f", "grep -i error /var/log/nginx/error.log"]
    },
    {
      q: "把当前目录打包并按日期命名",
      cmd: "tar -czf \"backup-$(date +%F).tar.gz\" .",
      risk: "caution",
      why: "会在当前目录新建一个压缩包文件。",
      anno: [
        { t: "tar", n: "打包工具，把很多文件收进一个归档。" },
        { t: "-czf", n: "三个开关合一：-c 新建归档，-z 走 gzip 压缩，-f 指定归档文件名。" },
        { t: "\"backup-$(date +%F).tar.gz\"", n: "$(...) 会先执行里面的命令：date +%F 得到 2026-10-02 这样的日期，再拼进文件名。" }
      ],
      sim: {
        scope: "当前目录", sudo: false, irreversible: false,
        note: "只新增一个压缩包，不改动原有文件。",
        tree: [{ p: "./", s: "read" }, { p: "./backup-2026-10-02.tar.gz", s: "add" }]
      },
      see: ["tar -tzf backup.tar.gz", "tar -xzf backup.tar.gz", "tar -czf backup.tar.gz --exclude=node_modules ."]
    },
    {
      q: "批量把 PNG 转成 WebP",
      cmd: "for f in uploads/*.png; do cwebp -q 80 \"$f\" -o \"${f%.png}.webp\"; done",
      risk: "caution",
      why: "每张图都会在旁边生成一个新的 .webp 文件。",
      anno: [
        { t: "for f in uploads/*.png", n: "遍历 uploads 目录下每一个 .png 文件，循环变量叫 f。注意：不递归子目录。" },
        { t: "cwebp -q 80", n: "Google 的 WebP 编码器，-q 80 表示质量 80，通常体积能降一半以上。" },
        { t: "\"${f%.png}.webp\"", n: "${f%.png} 表示去掉结尾的 .png，再拼上 .webp 作为输出名，所以原图不会被覆盖。" }
      ],
      sim: {
        scope: "uploads 目录", sudo: false, irreversible: false,
        note: "原 PNG 保留，只是多出同名的 .webp 文件。",
        tree: [{ p: "./uploads/avatar.png", s: "read" }, { p: "./uploads/avatar.webp", s: "add" }, { p: "./uploads/banner.webp", s: "add" }]
      },
      see: ["cwebp -q 80 in.png -o out.webp", "mogrify -format webp *.png", "for f in uploads/*.png; do cwebp -q 80 \"$f\" -o \"${f%.png}.webp\"; done"]
    },
    {
      q: "找出并删除所有 .tmp 文件",
      cmd: "find . -name '*.tmp' -delete",
      risk: "danger",
      why: "直接删除文件，不进回收站，删掉就没有了。",
      anno: [
        { t: "find .", n: "从当前目录开始递归查找。" },
        { t: "-name '*.tmp'", n: "按文件名匹配，引号是必须的——不加的话 shell 会先替你展开 *.tmp。" },
        { t: "-delete", n: "对每个匹配结果执行删除。建议先去掉这一段跑一遍，确认列出来的文件都没问题，再加回来。" }
      ],
      sim: {
        scope: "当前目录及子目录", sudo: false, irreversible: true,
        note: "删除不经回收站，无法撤销。",
        tree: [{ p: "./cache/session.tmp", s: "del" }, { p: "./build/old.tmp", s: "del" }, { p: "./tmp/", s: "read" }]
      },
      see: ["find . -name '*.tmp' -print", "find . -name '*.tmp' -ok rm {} \\;", "find . -name '*.tmp' -mtime +30 -delete"]
    },
    {
      q: "递归把上传目录改成任何人可读写",
      cmd: "chmod -R 777 ./uploads",
      risk: "danger",
      why: "递归放宽到所有人都可读写执行，是 Web 站点最常见的入侵入口。",
      anno: [
        { t: "chmod", n: "修改文件权限。" },
        { t: "-R", n: "递归作用到目录下每一个文件，范围很容易失控。" },
        { t: "777", n: "所有者、所属组、其他人都可读可写可执行。上传目录通常只需要 755 给目录、644 给文件。" },
        { t: "./uploads", n: "确认这个路径没写错再回车——写错目录就会改到别的地方。" }
      ],
      sim: {
        scope: "uploads 及全部子项", sudo: false, irreversible: true,
        note: "权限改动不会被记录下来，改回去要靠记忆。",
        tree: [{ p: "./uploads/", s: "edit" }, { p: "./uploads/2026/a.png", s: "edit" }]
      },
      see: ["chmod 755 ./uploads", "chmod 644 ./uploads/*", "namei -l ./uploads"]
    },
    {
      q: "看看磁盘还剩多少空间",
      cmd: "df -h",
      risk: "safe",
      why: "只读取挂载点信息。",
      anno: [
        { t: "df", n: "disk free：显示各个挂载点的磁盘使用情况。" },
        { t: "-h", n: "人类可读单位，输出成 G、M 而不是一堆字节。" }
      ],
      sim: {
        scope: "只读", sudo: false, irreversible: false,
        note: "不写任何东西。",
        tree: [{ p: "挂载点信息", s: "read" }]
      },
      see: ["df -h /", "du -xhd1 / | sort -rh | head", "lsblk"]
    },
    {
      q: "统计日志里出现最多的 10 个 IP",
      cmd: "awk '{print $1}' /var/log/nginx/access.log | sort | uniq -c | sort -rn | head -10",
      flow: "取第一列 → 排序 → 去重并计数 → 按次数倒排 → 取前 10",
      risk: "safe",
      why: "只读日志文件。",
      anno: [
        { t: "awk '{print $1}'", n: "按空白分列，打印每行的第 1 列——nginx 日志里就是来访 IP。" },
        { t: "uniq -c", n: "合并相邻的重复行并统计次数。它只能处理相邻重复，所以前面必须先 sort。" },
        { t: "sort -rn", n: "按数值倒序排列，出现次数最多的排最前面。" }
      ],
      sim: {
        scope: "只读", sudo: false, irreversible: false,
        note: "只读取 nginx 的访问日志，不写入任何文件。",
        tree: [{ p: "/var/log/nginx/access.log", s: "read" }]
      },
      see: ["goaccess /var/log/nginx/access.log --log-format=COMBINED", "awk '{print $1}' /var/log/nginx/access.log | sort -u | wc -l", "grep -c ' 404 ' /var/log/nginx/access.log"]
    },
    {
      q: "重启 nginx 并跟着看日志",
      cmd: "sudo systemctl restart nginx && journalctl -u nginx -f",
      flow: "重启服务 → 成功才继续 → 实时跟随日志",
      risk: "caution",
      why: "重启会短暂中断服务；不过在生产环境里更推荐 reload。",
      anno: [
        { t: "sudo", n: "以管理员权限运行。" },
        { t: "systemctl restart nginx", n: "重启 nginx 服务。只想重载配置用 reload 更安全，连接不会断。" },
        { t: "&&", n: "前一条命令成功（退出码为 0）才执行后一条；失败就停下，不会白等日志。" },
        { t: "journalctl -u nginx -f", n: "查看 nginx 这个服务的 systemd 日志，-f 表示持续跟随。按 Ctrl+C 退出。" }
      ],
      sim: {
        scope: "nginx 服务", sudo: true, irreversible: false,
        note: "重启期间新连接会被拒绝，通常不到一秒。",
        tree: [{ p: "nginx 进程", s: "edit" }]
      },
      see: ["nginx -t && sudo systemctl reload nginx", "systemctl status nginx", "journalctl -u nginx -n 100 --no-pager"]
    },
    {
      q: "找出全盘大于 1G 的文件并逐个确认删除",
      cmd: "find / -type f -size +1G -exec rm -i {} \\;",
      risk: "danger",
      why: "全盘扫描加上删除，通常需要 sudo，且删除不可撤销。",
      expect: "denied",
      anno: [
        { t: "find /", n: "从根目录开始找，会扫描整块磁盘，比较慢，也容易扫到系统文件。" },
        { t: "-size +1G", n: "只匹配大于 1GB 的文件。" },
        { t: "-exec rm -i {} \\;", n: "对每个匹配结果执行一条命令：rm -i 删除前会问你一次；{} 是文件名占位符；\\; 表示这条子命令到此结束。" }
      ],
      sim: {
        scope: "整个文件系统", sudo: true, irreversible: true,
        note: "全盘范围。建议先换成 -print 跑一遍看清列表。这是本作品里少数「注定会失败」的示例：属于 root 的文件会返回 Permission denied，而这正是权限规则在起作用，不是沙箱坏了。",
        tree: [{ p: "/", s: "read" }, { p: "/var/log/big.log", s: "del" }]
      },
      see: ["find / -type f -size +1G -print", "du -xhd1 / | sort -rh | head", "find / -xdev -type f -size +1G -print"]
    },
    {
      q: "查看 nginx 各进程占了多少内存",
      cmd: "ps -o pid,rss,cmd -C nginx --sort=-rss",
      risk: "safe",
      why: "只读取进程信息。",
      anno: [
        { t: "-o pid,rss,cmd", n: "只输出这三列：进程号、常驻内存（单位 KB）、完整命令行。比默认输出干净得多。" },
        { t: "-C nginx", n: "按进程名精确筛选，不会像 grep 那样把 grep 自己也算进去。" },
        { t: "--sort=-rss", n: "按常驻内存倒序排列，占得最多的排最前面。" }
      ],
      sim: {
        scope: "只读", sudo: false, irreversible: false,
        note: "不发送任何信号，不改变进程状态。",
        tree: [{ p: "进程表", s: "read" }]
      },
      see: ["ps -o pid,rss,cmd -C nginx --sort=-rss", "top -o %MEM -p $(pgrep -d, nginx)", "systemctl status nginx"]
    },
    {
      q: "找出 7 天没被动过的文件",
      cmd: "find . -type f -mtime +7",
      flow: "从当前目录递归 → 只看普通文件 → 只留修改时间超过 7 天的",
      risk: "safe",
      why: "只读取文件时间戳，不做任何修改。",
      anno: [
        { t: "find .", n: "从当前目录开始递归查找。把点换成斜杠就是全盘扫描，会很慢。" },
        { t: "-type f", n: "-type 限定类型：f 是普通文件、d 是目录、l 是软链接。" },
        { t: "-mtime +7", n: "mtime 是内容修改时间；+7 表示 7 天以前，不含最近 7 天。单位是天，不是分钟。" }
      ],
      sim: {
        scope: "只读", sudo: false, irreversible: false,
        note: "只遍历时间戳，不写不删。",
        tree: [{ p: "./", s: "read" }, { p: "./ 下所有子目录", s: "read" }]
      },
      see: ["find . -type f -mtime -1", "find . -type f -newermt '7 days ago'", "find . -type f -mtime +7 -exec ls -l {} \\;"]
    },
    {
      q: "只看当前目录下一层有哪些子目录",
      cmd: "find . -maxdepth 1 -type d",
      risk: "safe",
      why: "只列目录名，不读取内容。",
      anno: [
        { t: "find .", n: "从当前目录开始找。" },
        { t: "-maxdepth 1", n: "只往下走一层，不递归。目录很深时能省掉大量时间。" },
        { t: "-type d", n: "只要目录，不要文件。" }
      ],
      sim: {
        scope: "只读", sudo: false, irreversible: false,
        note: "只列名字。",
        tree: [{ p: "./", s: "read" }]
      },
      see: ["ls -d */", "find . -maxdepth 2 -type d", "du -sh * | sort -rh"]
    },
    {
      q: "按修改时间列出最近动过的文件",
      cmd: "ls -lt | head -n 6",
      risk: "safe",
      why: "只读取目录项信息。",
      anno: [
        { t: "ls", n: "列出目录内容。" },
        { t: "-lt", n: "-l 长格式（权限、属主、大小、时间都列出来），-t 按修改时间从新到旧排。" },
        { t: "head -n 6", n: "只看前 6 行。目录里文件多的时候不加它会被刷屏。" }
      ],
      sim: {
        scope: "只读", sudo: false, irreversible: false,
        note: "不写入任何内容。",
        tree: [{ p: "./", s: "read" }]
      },
      see: ["ls -ltr | head", "stat notes.txt", "find . -maxdepth 1 -type f | head"]
    },
    {
      q: "看当前目录里每项各占多少空间",
      cmd: "du -sh * | sort -rh",
      risk: "safe",
      why: "只统计大小，需要遍历一遍目录。",
      anno: [
        { t: "du -sh", n: "-s 每项只给一个总计（不展开子目录），-h 用 K/M/G 显示而不是一串字节。" },
        { t: "*", n: "由 shell 先展开成当前目录下的每一项。它不含隐藏文件——以点开头的会被跳过。" },
        { t: "sort -rh", n: "按容量从大到小排；-h 让它按人类可读的单位比较，否则 9M 会排在 10K 前面。" }
      ],
      sim: {
        scope: "只读", sudo: false, irreversible: false,
        note: "只统计，不修改。",
        tree: [{ p: "./", s: "read" }]
      },
      see: ["du -sh * | sort -rh | head -n 5", "du -ah . | sort -rh | head -n 10", "df -h"]
    },
    {
      q: "看 inode 有没有被用满",
      cmd: "df -i",
      risk: "safe",
      why: "只读取文件系统统计。",
      anno: [
        { t: "df", n: "disk free：显示各个挂载点的使用情况。" },
        { t: "-i", n: "这次看的是 inode 数量而不是字节数。磁盘还剩很多空间但 inode 用满，同样会创建不了新文件。" }
      ],
      sim: {
        scope: "只读", sudo: false, irreversible: false,
        note: "不写任何东西。",
        tree: [{ p: "挂载点信息", s: "read" }]
      },
      see: ["df -h", "df -hT", "find / -xdev -type f | wc -l"]
    },
    {
      q: "看一个文件的权限、大小和三个时间戳",
      cmd: "stat notes.txt",
      risk: "safe",
      why: "只读取文件元信息。",
      anno: [
        { t: "stat", n: "打印文件的元信息，比 ls -l 详细：三个时间戳、inode 号、块数都在这里。" },
        { t: "notes.txt", n: "要看的目标文件。" }
      ],
      sim: {
        scope: "只读", sudo: false, irreversible: false,
        note: "不修改时间戳，也不读取内容。",
        tree: [{ p: "./notes.txt", s: "read" }]
      },
      see: ["ls -l notes.txt", "file notes.txt", "stat -c '%a %U %s %n' notes.txt"]
    },
    {
      q: "数一数访问日志里有多少条 500 错误",
      cmd: "grep -c ' 500 ' /var/log/nginx/access.log",
      risk: "safe",
      why: "只读日志。",
      anno: [
        { t: "grep", n: "按内容筛选行。" },
        { t: "-c", n: "不打印匹配的行，只打印匹配的条数。" },
        { t: "' 500 '", n: "前后各留一个空格，免得把 1500、2500 这类数字也匹配进来——这是 grep 最常见的翻车点。" },
        { t: "/var/log/nginx/access.log", n: "nginx 的访问日志路径。" }
      ],
      sim: {
        scope: "只读", sudo: false, irreversible: false,
        note: "只读日志，不写入。",
        tree: [{ p: "/var/log/nginx/access.log", s: "read" }]
      },
      see: ["grep -c ' 404 ' /var/log/nginx/access.log", "awk '{print $9}' /var/log/nginx/access.log | sort | uniq -c", "grep ' 500 ' /var/log/nginx/access.log | head -n 20"]
    },
    {
      q: "看被访问最多的 URL 是哪些",
      cmd: "awk '{print $7}' /var/log/nginx/access.log | sort | uniq -c | sort -rn | head -n 10",
      flow: "取出请求路径 → 排序 → 去重并计数 → 按次数倒排 → 取前 10",
      risk: "safe",
      why: "只读日志。",
      anno: [
        { t: "awk '{print $7}'", n: "nginx 日志按空格分列，第 7 列是请求路径（第 1 列是 IP，第 9 列是状态码）。" },
        { t: "uniq -c", n: "合并相邻的重复行并统计次数。它只处理相邻重复，所以前面必须先 sort。" },
        { t: "sort -rn", n: "按次数数值倒序，访问最多的排最前面。" },
        { t: "head -n 10", n: "只要前 10 名。" }
      ],
      sim: {
        scope: "只读", sudo: false, irreversible: false,
        note: "只读日志。",
        tree: [{ p: "/var/log/nginx/access.log", s: "read" }]
      },
      see: ["awk '{print $7}' /var/log/nginx/access.log | sort | uniq -c | sort -rn | head -n 5", "awk '{print $1}' /var/log/nginx/access.log | sort | uniq -c | sort -rn | head", "grep -c '/api/health' /var/log/nginx/access.log"]
    },
    {
      q: "看日志里的 HTTP 状态码分布",
      cmd: "awk '{print $9}' /var/log/nginx/access.log | sort | uniq -c | sort -rn",
      flow: "取出状态码 → 排序 → 去重计数 → 按次数倒排",
      risk: "safe",
      why: "只读日志。",
      anno: [
        { t: "awk '{print $9}'", n: "第 9 列是 HTTP 状态码。" },
        { t: "sort | uniq -c", n: "先排序让相同状态码挨在一起，再由 uniq -c 数出每种出现多少次。" },
        { t: "sort -rn", n: "出现次数多的排前面，一眼就能看出 200 占了多少、错误有多少。" }
      ],
      sim: {
        scope: "只读", sudo: false, irreversible: false,
        note: "只读日志。",
        tree: [{ p: "/var/log/nginx/access.log", s: "read" }]
      },
      see: ["grep -c ' 404 ' /var/log/nginx/access.log", "awk '$9 >= 500' /var/log/nginx/access.log | head", "grep -c ' 500 ' /var/log/nginx/access.log"]
    },
    {
      q: "把一段文本全部转成大写",
      cmd: "cat notes.txt | tr 'a-z' 'A-Z'",
      risk: "safe",
      why: "只把结果打印出来，原文件不动。",
      anno: [
        { t: "cat notes.txt", n: "把文件内容送进管道。tr 自己不读文件参数，靠管道喂给它。" },
        { t: "tr 'a-z' 'A-Z'", n: "tr 按字符替换：小写区间的每个字符映射成对应的大写字符。" },
        { t: "|", n: "管道：左边命令的输出直接变成右边命令的输入。两边是同时跑的，不会先存成临时文件。" }
      ],
      sim: {
        scope: "只读", sudo: false, irreversible: false,
        note: "结果只打印在屏幕上，原文件保持不变。想存下来得自己重定向。",
        tree: [{ p: "./notes.txt", s: "read" }]
      },
      see: ["cat notes.txt | tr -d ' '", "cat notes.txt | tr ' ' '\\n' | head", "cat notes.txt | tr 'a-z' 'A-Z' > upper.txt"]
    },
    {
      q: "打包 src 目录，并立刻确认包里有什么",
      cmd: "tar -czf src-$(date +%F).tar.gz ./src && tar -tzf src-$(date +%F).tar.gz",
      flow: "打包成按日期命名的归档 → 成功才继续 → 列出包内清单核对",
      risk: "caution",
      why: "会在当前目录生成一个新文件；原目录不动，但同名归档会被直接覆盖。",
      anno: [
        { t: "tar -czf", n: "c 创建归档，z 用 gzip 压缩，f 后面紧跟归档文件名。这三个字母的顺序不能乱。" },
        { t: "src-$(date +%F).tar.gz", n: "$(date +%F) 会先执行、把结果插进命令里，于是得到形如 src-2026-10-02.tar.gz 的文件名。" },
        { t: "&&", n: "前一条成功（退出码为 0）才执行后一条，打包失败就不用去列了。" },
        { t: "tar -tzf", n: "t 表示只列出归档内容、不解包。打完包顺手核对一下，确认没漏东西。" }
      ],
      sim: {
        scope: "当前目录", sudo: false, irreversible: false,
        note: "新增一个 .tar.gz 文件，不删不改 ./src。",
        tree: [{ p: "./src", s: "read" }, { p: "./src-2026-10-02.tar.gz", s: "add" }]
      },
      see: ["tar -tzf backup.tar.gz", "tar -xzf src.tar.gz -C /tmp", "du -sh ./src"]
    },
    {
      q: "给部署脚本加上执行权限",
      cmd: "chmod +x scripts/deploy.sh && ls -l scripts/deploy.sh",
      risk: "caution",
      why: "改了文件权限。改动本身可逆，但给来路不明的脚本加执行权限再运行，性质完全不同。",
      anno: [
        { t: "chmod +x", n: "+x 给所有者、组、其他人**都**加上执行位。只想让自己能跑，用 u+x 更保守。" },
        { t: "scripts/deploy.sh", n: "目标文件。" },
        { t: "ls -l scripts/deploy.sh", n: "改完立刻看一眼权限列，确认真的生效——权限位在终端里是看不见的，必须查。" }
      ],
      sim: {
        scope: "单个文件", sudo: false, irreversible: false,
        note: "只改权限位，随时能改回来。",
        tree: [{ p: "./scripts/deploy.sh", s: "edit" }]
      },
      see: ["chmod u+x scripts/deploy.sh", "chmod 755 scripts/deploy.sh", "ls -l scripts/"]
    },
    {
      q: "看本机在监听哪些端口",
      cmd: "ss -lntp",
      risk: "caution",
      why: "只是查看，但要管理员权限才能看到别人进程的名字。",
      anno: [
        { t: "ss", n: "查看网络连接，是 netstat 的现代替代品。" },
        { t: "-lnt", n: "-l 只看监听状态，-n 不做域名和服务名解析（更快更准），-t 只看 TCP。" },
        { t: "p", n: "显示占用端口的进程。查别的用户的进程需要 sudo，否则进程名那一列是空的。" }
      ],
      sim: {
        scope: "只读", sudo: false, irreversible: false,
        note: "只查询内核里的连接表，不改动任何配置。",
        tree: [{ p: "连接表", s: "read" }]
      },
      see: ["sudo ss -lptn 'sport = :80'", "ss -tnp state established", "ss -s"]
    },
    {
      q: "看哪个进程在吃 CPU",
      cmd: "ps aux --sort=-%cpu | head -n 5",
      risk: "safe",
      why: "只读取进程信息，不发送任何信号。",
      anno: [
        { t: "ps aux", n: "a 显示所有用户的进程，u 用面向用户的格式（带 CPU、内存百分比），x 连没有终端的进程也列出来。" },
        { t: "--sort=-%cpu", n: "按 CPU 使用率倒序排列。负号表示从大到小，只写 %cpu 会变成升序。" },
        { t: "head -n 5", n: "只看前 5 行。ps 看一眼就够，不用刷一屏。" }
      ],
      sim: {
        scope: "只读", sudo: false, irreversible: false,
        note: "只读进程表，不改变任何进程状态。",
        tree: [{ p: "进程表", s: "read" }]
      },
      see: ["ps aux --sort=-rss | head", "ps -o pid,%cpu,cmd -C nginx --sort=-%cpu", "top -b -n1 | head -n 12"]
    },
    {
      q: "把文件里的 todo 换成 done（先看结果，不改文件）",
      cmd: "sed 's/todo/done/' notes.txt",
      flow: "读入文件 → 逐行替换 → 结果打到屏幕，原文件不动",
      risk: "safe",
      why: "sed 不加 -i 就只把结果打印出来，不碰原文件。",
      anno: [
        { t: "sed", n: "流编辑器：读一行、按脚本改一行、输出一行。它不打开编辑器界面，天生适合脚本里用。" },
        { t: "'s/todo/done/'", n: "s 是 substitute（替换）：把每行里**第一处** todo 换成 done。注意没加 g，所以一行里第二处不会被换。" },
        { t: "notes.txt", n: "输入文件。sed 把结果打到标准输出，原文件保持不变——想真改要加 -i。" }
      ],
      sim: {
        scope: "只读", sudo: false, irreversible: false,
        note: "原文件不会被修改。这是改配置之前最该先跑的一遍。",
        tree: [{ p: "./notes.txt", s: "read" }]
      },
      see: ["sed 's/todo/done/g' notes.txt", "sed -n '/todo/p' notes.txt", "sed 's/todo/done/' notes.txt > new.txt"]
    },
    {
      q: "就地替换文件里的文字",
      cmd: "sed -i 's/todo/done/' notes.txt",
      risk: "caution",
      why: "直接改写原文件；写错了没有回收站，只能靠备份或版本控制。",
      anno: [
        { t: "sed", n: "流编辑器。" },
        { t: "-i", n: "in-place：把结果写回原文件。**这个参数是 sed 里最容易造成损失的一个**——加之前先用不加 -i 的形式看一遍。" },
        { t: "'s/todo/done/'", n: "把每行第一处 todo 换成 done。" },
        { t: "notes.txt", n: "被就地修改的文件。" }
      ],
      sim: {
        scope: "单个文件", sudo: false, irreversible: true,
        note: "内容被直接改写。想反悔只能靠 -i.bak 留下的备份，或者你手上的版本控制。",
        tree: [{ p: "./notes.txt", s: "edit" }]
      },
      see: ["sed 's/todo/done/' notes.txt", "sed -i.bak 's/todo/done/' notes.txt", "cp notes.txt notes.txt.bak && sed -i 's/todo/done/' notes.txt"]
    },
    {
      q: "改版本号，同时自动留一份备份",
      cmd: "sed -i.bak 's/0.3.1/0.4.0/' package.json",
      risk: "caution",
      why: "会改写 package.json，同时生成一个 .bak 副本。",
      anno: [
        { t: "sed -i.bak", n: "就地修改，并且在改之前把原文件复制成 package.json.bak。**这一步等于给自己留了后悔药**，改配置文件时值得养成习惯。" },
        { t: "'s/0.3.1/0.4.0/'", n: "把每行第一处 0.3.1 换成 0.4.0。版本号里的点会匹配任意字符，但在这里不影响结果。" },
        { t: "package.json", n: "目标文件。" }
      ],
      sim: {
        scope: "单个文件", sudo: false, irreversible: false,
        note: "新增一个 .bak 备份文件，原文件被改写。反悔就 mv 回来。",
        tree: [{ p: "./package.json", s: "edit" }, { p: "./package.json.bak", s: "add" }]
      },
      see: ["sed -i 's/0.3.1/0.4.0/' package.json", "git diff package.json", "cp package.json package.json.bak"]
    },
    {
      q: "把某一处字符全部替换掉",
      cmd: "sed 's/o/0/g' notes.txt",
      risk: "safe",
      why: "只打印结果，不改文件。",
      anno: [
        { t: "sed", n: "流编辑器。" },
        { t: "'s/o/0/g'", n: "g 是 global：每行里**所有**的小写 o 都换成数字 0。不加 g 只换第一处——这是 sed 最常被搞混的一点。" },
        { t: "notes.txt", n: "输入文件。" }
      ],
      sim: {
        scope: "只读", sudo: false, irreversible: false,
        note: "原文件不变。",
        tree: [{ p: "./notes.txt", s: "read" }]
      },
      see: ["sed 's/o/0/' notes.txt", "sed 's/[0-9]/N/g' notes.txt", "sed 's/o/0/g' notes.txt > out.txt"]
    },
    {
      q: "只打印包含某个词的行",
      cmd: "sed -n '/uploads/p' notes.txt",
      risk: "safe",
      why: "只读，只输出。",
      anno: [
        { t: "sed -n", n: "-n 关掉默认输出：不加它 sed 会把每一行都打出来。关掉之后，只有你显式要求打印的行才会出现。" },
        { t: "'/uploads/p'", n: "斜杠里是模式，末尾的 p 表示 print。合起来就是「只打印匹配这个模式的行」。" },
        { t: "notes.txt", n: "输入文件。" }
      ],
      sim: {
        scope: "只读", sudo: false, irreversible: false,
        note: "不修改任何文件。",
        tree: [{ p: "./notes.txt", s: "read" }]
      },
      see: ["grep 'uploads' notes.txt", "sed -n '/todo/p' notes.txt", "sed -n '1,2p' notes.txt"]
    },
    {
      q: "给文件的每一行加两个空格缩进",
      cmd: "sed 's/^/  /' notes.txt",
      risk: "safe",
      why: "只打印结果，不改文件。",
      anno: [
        { t: "sed", n: "流编辑器。" },
        { t: "'s/^/  /'", n: "^ 匹配行首。把行首替换成两个空格，效果就是整体缩进。同理 s/$/x/ 会在行尾加内容。" },
        { t: "notes.txt", n: "输入文件。" }
      ],
      sim: {
        scope: "只读", sudo: false, irreversible: false,
        note: "原文件不变。",
        tree: [{ p: "./notes.txt", s: "read" }]
      },
      see: ["sed 's/^/    /' notes.txt", "sed 's/$/  <- 这一行结束/' notes.txt", "sed -i 's/^/  /' notes.txt"]
    },
    {
      q: "改系统日志被权限拒绝（这是好事）",
      cmd: "sed -i 's/warn/WARN/' /var/log/nginx/error.log",
      risk: "caution",
      why: "目标是 root 拥有的日志文件，普通用户改不动——这个失败是权限规则在起作用。",
      expect: "denied",
      anno: [
        { t: "sed -i", n: "就地修改，需要对这个文件有写权限。" },
        { t: "'s/warn/WARN/'", n: "把 warn 换成大写的 WARN。" },
        { t: "/var/log/nginx/error.log", n: "系统日志，属主是 root、权限 640：普通用户连读都不行，更别说改。" }
      ],
      sim: {
        scope: "无（会被拒绝）", sudo: false, irreversible: false,
        note: "命令会返回 Permission denied 并且不修改任何东西。要改系统日志得用 sudo，而且通常应该改日志轮转配置，而不是手改日志内容。",
        tree: [{ p: "/var/log/nginx/error.log", s: "read" }]
      },
      see: ["sudo sed -i 's/warn/WARN/' /var/log/nginx/error.log", "ls -l /var/log/nginx/", "id"]
    },
    {
      q: "把部署脚本的属主交给 root",
      cmd: "sudo chown root scripts/deploy.sh",
      risk: "caution",
      why: "改属主需要 root；改完之后普通用户就不能再修改这个文件了。",
      anno: [
        { t: "sudo", n: "以管理员权限运行。chown 是少数**必须** root 才能执行的命令之一。" },
        { t: "chown", n: "change owner：改文件的属主。" },
        { t: "root", n: "新的属主。也可以写 student 交回给自己。" },
        { t: "scripts/deploy.sh", n: "目标文件。改完之后它的属主变成 root，你这个普通用户就只能读、不能写了。" }
      ],
      sim: {
        scope: "单个文件", sudo: true, irreversible: false,
        note: "只是属主字段变化，用 sudo chown student 就能改回来。但要意识到：交给 root 之后，普通用户就失去了修改权。",
        tree: [{ p: "./scripts/deploy.sh", s: "edit" }]
      },
      see: ["sudo chown student scripts/deploy.sh", "ls -l scripts/", "stat scripts/deploy.sh"]
    },
    {
      q: "普通用户改属主会被拒绝",
      cmd: "chown root notes.txt",
      risk: "caution",
      why: "chown 只有 root 能执行，这是内核的硬性限制，不是配置问题。",
      expect: "denied",
      anno: [
        { t: "chown", n: "改属主。它和 chmod 的关键区别：chmod 改权限位、自己有文件就能改，chown 改归属、**永远要 root**。" },
        { t: "root", n: "想改成的新属主。" },
        { t: "notes.txt", n: "目标文件。命令会在动手之前就被拒绝，文件不会有任何变化。" }
      ],
      sim: {
        scope: "无（会被拒绝）", sudo: false, irreversible: false,
        note: "返回 Operation not permitted，文件不受影响。想让它成功必须加 sudo。",
        tree: [{ p: "./notes.txt", s: "read" }]
      },
      see: ["sudo chown root notes.txt", "chmod 644 notes.txt", "id"]
    },
    {
      q: "递归把整个目录的属主交出去",
      cmd: "sudo chown -R root ./cache",
      risk: "danger",
      why: "递归改属主会让普通用户失去整个目录树的写权限，之后连缓存都写不进去。",
      anno: [
        { t: "sudo", n: "以 root 执行。" },
        { t: "chown -R", n: "-R 递归：目录本身和它下面**每一个**文件都会被改。作用范围很容易超出预期。" },
        { t: "root", n: "新的属主。注意 chown 改的是归属，决定「谁有资格改这个文件」；而 chmod 改的是权限位，决定「谁能读、能写」。两者不是一回事。" },
        { t: "./cache", n: "目标目录。执行完这个目录对普通用户就变成只读了。" }
      ],
      sim: {
        scope: "cache 及全部子项", sudo: true, irreversible: false,
        note: "权限与属主改动不会被记录下来，改回去要靠记忆或重新 chown。生产环境里这通常是个事故。",
        tree: [{ p: "./cache/", s: "edit" }, { p: "./cache/index.tmp", s: "edit" }, { p: "./cache/session.tmp", s: "edit" }]
      },
      see: ["sudo chown -R student ./cache", "ls -l ./cache", "sudo chown -R www-data:www-data ./uploads"]
    },
    {
      q: "把源码目录打包成 zip",
      cmd: "zip -r src.zip ./src",
      risk: "caution",
      why: "会在当前目录生成一个新的 zip 文件。",
      anno: [
        { t: "zip", n: "打 zip 包。和 tar 的最大区别：zip 会同时压缩和归档，不用再记 z 这种字母。" },
        { t: "-r", n: "递归。**打目录必须加**，否则 zip 会直接拒绝并告诉你原因。" },
        { t: "src.zip", n: "归档文件名。不写 .zip 后缀时 zip 会自动补上。" },
        { t: "./src", n: "要打包的目录。包里会保留 src/ 这一层。" }
      ],
      sim: {
        scope: "当前目录", sudo: false, irreversible: false,
        note: "新增一个 src.zip；原目录只读。",
        tree: [{ p: "./src", s: "read" }, { p: "./src.zip", s: "add" }]
      },
      see: ["zip -r src.zip ./src && unzip -l src.zip", "tar -czf src.tar.gz ./src", "unzip -l src.zip"]
    },
    {
      q: "把几个文件打成一个包",
      cmd: "zip release.zip package.json notes.txt",
      risk: "caution",
      why: "生成新文件；同名包会被覆盖。",
      anno: [
        { t: "zip", n: "打 zip 包。" },
        { t: "release.zip", n: "归档名。文件列表写在归档名后面。" },
        { t: "package.json notes.txt", n: "要打的几个文件。打**文件**不需要 -r，只有打目录才需要。" }
      ],
      sim: {
        scope: "当前目录", sudo: false, irreversible: false,
        note: "新增 release.zip；两个源文件都不动。",
        tree: [{ p: "./package.json", s: "read" }, { p: "./notes.txt", s: "read" }, { p: "./release.zip", s: "add" }]
      },
      see: ["zip -r release.zip ./src ./uploads", "unzip -l release.zip", "tar -czf release.tar.gz package.json notes.txt"]
    },
    {
      q: "打包之后立刻核对包里有什么",
      cmd: "zip -r src.zip ./src && unzip -l src.zip",
      flow: "递归打包目录 → 成功才继续 → 列出包内清单",
      risk: "caution",
      why: "生成新文件；清单只读。",
      anno: [
        { t: "zip -r src.zip ./src", n: "递归打包 ./src 目录。" },
        { t: "&&", n: "打包成功才去列清单。打包失败时继续列只会看到一堆没用的报错。" },
        { t: "unzip -l src.zip", n: "-l 只列出内容、不解包。**打完包顺手核对一遍**，是避免「交上去才发现漏了文件」的最便宜的习惯。" }
      ],
      sim: {
        scope: "当前目录", sudo: false, irreversible: false,
        note: "新增一个 src.zip。",
        tree: [{ p: "./src", s: "read" }, { p: "./src.zip", s: "add" }]
      },
      see: ["unzip -l src.zip", "tar -tzf src.tar.gz", "zip -r src.zip ./src"]
    },
    {
      q: "把源码打包再解到一个干净的目录",
      cmd: "zip -r s.zip ./src && mkdir -p restore && unzip s.zip -d restore",
      flow: "打包 → 建目标目录 → 解包进去",
      risk: "caution",
      why: "生成一个 zip 和一个新目录，并往新目录里写入文件。",
      anno: [
        { t: "zip -r s.zip ./src", n: "先把目录打成包。" },
        { t: "mkdir -p restore", n: "-p 表示父目录不存在就一起建、目录已存在也不报错。脚本里建目录基本都用它。" },
        { t: "unzip s.zip -d restore", n: "-d 指定解到哪个目录。不加 -d 会直接解在当前目录，容易和已有文件混在一起。" }
      ],
      sim: {
        scope: "当前目录与 restore/", sudo: false, irreversible: false,
        note: "新增 s.zip 和 restore/ 目录；源目录不动。",
        tree: [{ p: "./s.zip", s: "add" }, { p: "./restore/", s: "add" }, { p: "./restore/app.js", s: "add" }]
      },
      see: ["unzip -l s.zip", "unzip -o s.zip -d restore", "tar -xzf s.tar.gz -C restore"]
    },
    {
      q: "看日志开头 20 行",
      cmd: "head -n 20 /var/log/nginx/access.log",
      risk: "safe",
      why: "只读日志。",
      anno: [
        { t: "head", n: "取文件开头若干行。日志文件很大时，直接 cat 会刷爆终端。" },
        { t: "-n 20", n: "取前 20 行。不写 -n 默认是 10 行。" },
        { t: "/var/log/nginx/access.log", n: "nginx 访问日志。它的每行格式是：IP、时间、请求行、状态码、字节数、来源、UA。" }
      ],
      sim: {
        scope: "只读", sudo: false, irreversible: false,
        note: "不写入任何文件。",
        tree: [{ p: "/var/log/nginx/access.log", s: "read" }]
      },
      see: ["tail -n 20 /var/log/nginx/access.log", "head -n 5 package.json", "sed -n '1,20p' /var/log/nginx/access.log"]
    },
    {
      q: "把健康检查的噪音从日志里滤掉",
      cmd: "grep -v '/health' /var/log/nginx/access.log | head -n 15",
      flow: "读日志 → 丢掉包含 /health 的行 → 取前 15 行",
      risk: "safe",
      why: "只读日志。",
      anno: [
        { t: "grep -v", n: "-v 是 invert：**不**匹配的行才保留。查日志时它比正向匹配更常用——因为噪音总是占大多数。" },
        { t: "'/health'", n: "要排除的内容。" },
        { t: "/var/log/nginx/access.log", n: "日志文件。" },
        { t: "head -n 15", n: "滤完还是会很长，只取前 15 行。" }
      ],
      sim: {
        scope: "只读", sudo: false, irreversible: false,
        note: "只读日志，不写入任何文件。",
        tree: [{ p: "/var/log/nginx/access.log", s: "read" }]
      },
      see: ["grep -c '/api/health' /var/log/nginx/access.log", "grep -v '/health' /var/log/nginx/access.log | wc -l", "awk '{print $7}' /var/log/nginx/access.log | sort | uniq -c | sort -rn | head"]
    },
    {
      q: "忽略大小写搜索错误",
      cmd: "grep -i 'error' /var/log/nginx/error.log | head -n 3",
      risk: "safe",
      why: "只读日志。",
      anno: [
        { t: "grep -i", n: "-i 忽略大小写：Error、ERROR、error 都能匹配上。查日志时几乎总该加它。" },
        { t: "'error'", n: "要找的内容。" },
        { t: "/var/log/nginx/error.log", n: "nginx 错误日志。" },
        { t: "head -n 3", n: "只看前 3 条，先确认格式对不对。" }
      ],
      sim: {
        scope: "只读", sudo: false, irreversible: false,
        note: "只读取日志，不修改任何内容。",
        tree: [{ p: "/var/log/nginx/error.log", s: "read" }]
      },
      see: ["grep -in 'error' /var/log/nginx/error.log | tail -n 10", "grep -c 'error' /var/log/nginx/error.log", "tail -n 20 /var/log/nginx/error.log"]
    },
    {
      q: "看最新的错误日志",
      cmd: "tail -n 20 /var/log/nginx/error.log",
      risk: "safe",
      why: "只读日志。",
      anno: [
        { t: "tail", n: "取文件末尾若干行——排障时看的是**最近**发生了什么，所以 tail 比 head 用得多。" },
        { t: "-n 20", n: "取最后 20 行。" },
        { t: "/var/log/nginx/error.log", n: "nginx 错误日志。" }
      ],
      sim: {
        scope: "只读", sudo: false, irreversible: false,
        note: "不写入。想持续盯着新日志用 tail -f。",
        tree: [{ p: "/var/log/nginx/error.log", s: "read" }]
      },
      see: ["tail -f /var/log/nginx/error.log", "tail -n 50 /var/log/nginx/error.log", "journalctl -u nginx -n 50"]
    },
    {
      q: "看目录里文件的大小（带单位）",
      cmd: "ls -lh uploads/",
      risk: "safe",
      why: "只读目录信息。",
      anno: [
        { t: "ls", n: "列出目录内容。" },
        { t: "-lh", n: "-l 长格式，-h 把字节数换成人看的 K/M/G。**没有 -h 的话，184007 和 73007 这两个数字很难一眼比出大小。**" },
        { t: "uploads/", n: "目标目录。目录名末尾加斜杠可以避免和同名文件混淆。" }
      ],
      sim: {
        scope: "只读", sudo: false, irreversible: false,
        note: "不修改任何东西。",
        tree: [{ p: "./uploads/", s: "read" }]
      },
      see: ["ls -lah uploads/", "du -sh uploads/", "stat uploads/avatar.png"]
    },
    {
      q: "连隐藏文件一起列出来",
      cmd: "ls -la",
      risk: "safe",
      why: "只读目录信息。",
      anno: [
        { t: "ls", n: "列出目录内容。" },
        { t: "-la", n: "-a 连以点开头的隐藏文件也列出来，-l 长格式。**排查「为什么这里有个配置」时，十有八九答案在隐藏文件里。**" }
      ],
      sim: {
        scope: "只读", sudo: false, irreversible: false,
        note: "不修改任何东西。",
        tree: [{ p: "./", s: "read" }]
      },
      see: ["ls -la uploads/", "ls -l", "find . -maxdepth 1 -type f"]
    },
    {
      q: "看文件系统类型和容量",
      cmd: "df -hT",
      risk: "safe",
      why: "只读挂载点信息。",
      anno: [
        { t: "df", n: "disk free：各挂载点的使用情况。" },
        { t: "-hT", n: "-h 人类可读单位，-T 多显示一列文件系统类型（ext4、xfs、tmpfs……）。查「这台机器的盘是什么格式」就看它。" }
      ],
      sim: {
        scope: "只读", sudo: false, irreversible: false,
        note: "不写任何东西。",
        tree: [{ p: "挂载点信息", s: "read" }]
      },
      see: ["df -h", "df -i", "mount | column -t"]
    },
    {
      q: "看某个目录总共占多大",
      cmd: "du -sh node_modules",
      risk: "safe",
      why: "只统计大小，需要遍历该目录。",
      anno: [
        { t: "du", n: "disk usage：统计目录/文件的磁盘占用。" },
        { t: "-sh", n: "-s 只输出一个总计，不把每个子目录都列出来；-h 用 K/M/G 显示。" },
        { t: "node_modules", n: "目标目录。依赖目录通常是项目里最占地方的那个。" }
      ],
      sim: {
        scope: "只读", sudo: false, irreversible: false,
        note: "只统计，不修改。",
        tree: [{ p: "./node_modules", s: "read" }]
      },
      see: ["du -sh * | sort -rh", "du -ah . | sort -rh | head -n 10", "df -h"]
    },
    {
      q: "看已经建立起来的连接",
      cmd: "ss -tnp state established",
      risk: "caution",
      why: "只是查看，但要看别人的进程名需要管理员权限。",
      anno: [
        { t: "ss", n: "查看网络连接，netstat 的替代品。" },
        { t: "-tnp", n: "-t 只看 TCP，-n 不做名称解析（更快更准），-p 显示占用连接的进程。" },
        { t: "state established", n: "过滤条件：只看已经建立（正在通信）的连接。想只看监听中的用 ss -lntp。" }
      ],
      sim: {
        scope: "只读", sudo: false, irreversible: false,
        note: "只查询内核连接表。",
        tree: [{ p: "连接表", s: "read" }]
      },
      see: ["ss -lntp", "ss -s", "sudo ss -tnp state established"]
    }
  ]
};
