/* nl2sh · 沙箱自测
 *
 * 沙箱的命令语义是这个作品的技术底座，必须能自动验证。
 * 这个文件不依赖 DOM，直接跑：
 *     node scripts/sandbox-test.mjs
 * 它会用真实场景把规则库里那 13 条命令全部跑一遍，并对输出与文件系统副作用做断言。
 */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const assets = path.join(here, '..', 'assets');

/* ── 先查语法：一个漏掉的括号会让整个页面白屏，且现象很难反推 ── */
console.log('脚本语法');
let syntaxBad = 0;
for (const f of ['data.js', 'sandbox-fixtures.js', 'sandbox-cmds.js', 'sandbox.js', 'ai.js', 'fx.js', 'app.js']) {
  try {
    new Function(fs.readFileSync(path.join(assets, f), 'utf8'));
    console.log('  ok   ' + f);
  } catch (e) {
    syntaxBad++;
    console.log('  FAIL ' + f + '\n       → ' + e.message);
  }
}
if (syntaxBad) {
  console.log('\n语法没过，后续测试没有意义。');
  process.exit(1);
}

globalThis.window = globalThis;
for (const f of ['sandbox-fixtures.js', 'sandbox-cmds.js', 'sandbox.js']) {
  new Function('window', fs.readFileSync(path.join(assets, f), 'utf8'))(globalThis);
}
const SBX = globalThis.NL2SH_SANDBOX;

let pass = 0, fail = 0;
const failures = [];

function check(name, cond, detail) {
  if (cond) { pass++; console.log('  ok   ' + name); }
  else {
    fail++; failures.push(name);
    console.log('  FAIL ' + name + (detail !== undefined ? '\n       → ' + detail : ''));
  }
}

function section(title) { console.log('\n' + title); }

/* 每个用例都用全新会话，避免互相污染 */
function fresh() { return SBX.createSession('default'); }

function lines(s) { return String(s).split('\n').filter(Boolean); }

/* ── 规则库里的 13 条命令 ───────────────────────────── */
section('规则库 13 条命令');

{
  const sh = fresh();
  const r = sh.run("du -ah . | sort -rh | head -n 10");
  const out = lines(r.out);
  check('du|sort -rh|head 输出 10 行', out.length === 10, out.length + ' 行');
  check('排序确实是从大到小', /G\t/.test(out[0]) || /M\t/.test(out[0]), out[0]);
  check('只读命令不产生任何文件变化', r.changes.length === 0, JSON.stringify(r.changes.slice(0, 3)));
}

{
  const sh = fresh();
  const r = sh.run("sudo ss -lptn 'sport = :80'");
  check('ss 能按端口过滤到 nginx', /nginx/.test(r.out), r.out.slice(0, 120));
  check('ss 被标记为模拟输出', r.simulated === true);
}

{
  const sh = fresh();
  const r = sh.run("find . -type f -newermt yesterday ! -newermt today");
  const out = lines(r.out);
  check('find -newermt 只命中"昨天"的文件', out.length === 1 && /src\/index\.js$/.test(out[0]),
    JSON.stringify(out));
}

{
  const sh = fresh();
  const r = sh.run('cat /var/log/nginx/error.log');
  check('普通用户读不了 root 的 640 日志', /Permission denied/.test(r.err), r.err);
  check('读失败退出码非 0', r.code !== 0, r.code);
  const r2 = sh.run('sudo cat /var/log/nginx/error.log');
  check('加 sudo 后能读到', /upstream/.test(r2.out), r2.out.slice(0, 80));
}

{
  const sh = fresh();
  const r = sh.run('tar -czf "backup-$(date +%F).tar.gz" .');
  check('$(date +%F) 被真的执行并替换', r.out.length >= 0 && sh.state().fs.exists('/home/student/project/backup-2026-10-02.tar.gz'),
    r.out + ' | ' + r.err);
  check('归档被记为新增文件', r.changes.some(c => c.kind === 'add' && /backup-2026-10-02/.test(c.path)),
    JSON.stringify(r.changes.map(c => c.path)));
}

{
  const sh = fresh();
  const r = sh.run('for f in uploads/*.png; do cwebp -q 80 "$f" -o "${f%.png}.webp"; done');
  const added = r.changes.filter(c => c.kind === 'add').map(c => c.path);
  check('for 循环跑了两次并生成 2 个 webp', added.length === 2, JSON.stringify(added));
  check('${f%.png} 正确去掉后缀', added.every(p => /\.webp$/.test(p)) && added.every(p => !/\.png\.webp$/.test(p)),
    JSON.stringify(added));
  check('glob 只展开了 png，没碰 .gitkeep', added.every(p => !/gitkeep/.test(p)));
}

{
  const sh = fresh();
  const before = sh.run("find . -name '*.tmp' -print");
  const list = lines(before.out);
  check("find -name '*.tmp' 找到 3 个（且引号让 *.tmp 没被 shell 展开）", list.length === 3, JSON.stringify(list));
  const r = sh.run("find . -name '*.tmp' -delete");
  const deleted = r.changes.filter(c => c.kind === 'del');
  check('find -delete 真的删掉 3 个文件', deleted.length === 3, JSON.stringify(deleted.map(c => c.path)));
  check('被删的是 .tmp 而不是别的', deleted.every(c => /\.tmp$/.test(c.path)));
}

{
  const sh = fresh();
  const r = sh.run('chmod -R 777 ./uploads');
  const chg = r.changes.filter(c => c.kind === 'chg');
  check('chmod -R 递归改到目录和所有子项', chg.length === 4, chg.length + ' 项: ' + JSON.stringify(chg.map(c => c.path)));
  check('权限位确实变成 777', chg.every(c => c.mode === 0o777), JSON.stringify(chg.map(c => c.mode.toString(8))));
}

{
  const sh = fresh();
  const r = sh.run('df -h');
  check('df 输出挂载点', /\/dev\/vda1/.test(r.out), r.out.split('\n')[0]);
  /* ⚠️ 这条断言原来写的是 /6[0-9]%|3[0-9]%/.test(r.out)——
     它**靠的正是那个 bug 才通过**：2GB 的 tmpfs 行显示 361%，于是匹配上了 3x%。
     修掉 df 之后它必然失败（实测就是它报的红，说明测试网确实在起作用）。
     本意是对的——"df 要反映沙箱里真实存在的数据"——所以把落点改到**根分区那一行**：
     根分区 = 21G 固定基底 + 沙箱真实数据量（fixture 约 7.2G），落在 44% 附近。
     真正的数学不变量（Used ≤ Size、Avail ≥ 0、Use% ≤ 100）由本节前面的
     「df：读数必须数学成立」逐行断言。 */
  const rootRow = String(r.out).split('\n')[1] || '';
  check('df 的根分区已用含沙箱真实数据（约 44%，不是固定值）',
    /4[0-9]%/.test(rootRow) && /\/dev\/vda1/.test(rootRow), rootRow);
}

{
  const sh = fresh();
  const r = sh.run("awk '{print $1}' ../logs/access.log | sort | uniq -c | sort -rn | head -5");
  const out = lines(r.out);
  check('日志统计管道产出 5 行', out.length === 5, out.length + ' 行');
  check('每行是「次数 IP」格式', /^\s*\d+\s+[\d.]+$/.test(out[0]), JSON.stringify(out[0]));
  check('次数是降序的', (() => {
    const nums = out.map(l => parseInt(l.trim().split(/\s+/)[0], 10));
    return nums.every((n, i) => i === 0 || nums[i - 1] >= n);
  })(), JSON.stringify(out));
}

{
  const sh = fresh();
  const r = sh.run('sudo systemctl restart nginx && journalctl -u nginx -f');
  check('&& 之后 journalctl 真的跑了', /nginx\[1\]/.test(r.out), r.out.slice(0, 160));
  check('重启被记录进服务状态', sh.state().services.nginx.startedAt === sh.state().now);
  check('两个命令都标记为模拟输出', r.simulated === true);
}

{
  const sh = fresh();
  const r = sh.run("find / -type f -size +1G -exec rm -i {} \\;");
  const deleted = r.changes.filter(c => c.kind === 'del').map(c => c.path);
  check('find / -size +1G 命中大文件', deleted.length >= 1, JSON.stringify(deleted));
  check('删掉了能删的（学生自己的 ISO）', deleted.some(p => /ubuntu/.test(p)), JSON.stringify(deleted));
  check('删不掉的给出 Permission denied（root 的 ibdata1）', /Permission denied/.test(r.err), r.err.slice(0, 200));
  check('-i 的询问在沙箱里被显式应答并说明', /一律按 y 应答/.test(r.out), r.out.slice(0, 200));
}

{
  const sh = fresh();
  const r = sh.run('ps -o pid,rss,cmd -C nginx --sort=-rss');
  const body = lines(r.out).slice(1);
  check('ps 按内存倒序输出 3 个 nginx 进程', body.length === 3, JSON.stringify(body));
  check('内存最大的排最前', /31204/.test(body[0]), body[0]);
}

/* ── 边界与安全 ─────────────────────────────────────── */
section('边界与安全行为');

{
  const sh = fresh();
  const before = sh.run('ls /var/log/nginx').out;
  const r = sh.run('rm /var/log/nginx/error.log');
  check('rm 动不了 root 目录里的文件', /Permission denied/.test(r.err), r.err);
  check('被拒绝时文件系统没有变化', r.changes.length === 0, JSON.stringify(r.changes));
  check('加 sudo 就能删', (() => {
    const r2 = sh.run('sudo rm /var/log/nginx/error.log');
    return r2.code === 0 && r2.changes.some(c => c.kind === 'del');
  })());
}

{
  const sh = fresh();
  const r = sh.run('echo leaked > /var/log/nginx/test.log');
  check('重定向到无权限目录会被拒绝', /Permission denied/.test(r.err), r.err);
  check('拒绝时不会留下半个文件', !sh.state().fs.exists('/var/log/nginx/test.log'));
}

{
  const sh = fresh();
  const r = sh.run('notacommand --help');
  check('未知命令返回 127', r.code === 127, r.code);
  check('未知命令给出可读提示', /command not found/.test(r.err), r.err);
}

{
  const sh = fresh();
  const r = sh.run('cd /home/student && ls');
  check('cd 能改工作目录', sh.cwd() === '/home/student', sh.cwd());
  check('cd 之后 ls 列的是新目录', /project/.test(r.out), r.out);
}

/* ── 快照与回滚 ─────────────────────────────────────── */
section('快照与时光倒流');

{
  const sh = fresh();
  const iso = '/home/student/Downloads/ubuntu-24.04.3-desktop-amd64.iso';
  const r = sh.run('rm -rf /home/student/Downloads');
  check('删掉整个 Downloads 目录', r.changes.filter(c => c.kind === 'del').length >= 3,
    r.changes.length + ' 项变化');
  check('删除后文件确实不在了', !sh.state().fs.exists(iso));
  const restored = sh.restore(r.snapshot);
  check('回滚成功', restored.ok === true);
  check('文件被原样恢复', sh.state().fs.exists(iso));
  check('恢复后目录也回来了', sh.state().fs.isDir('/home/student/Downloads'));
  const after = sh.diffSince(r.snapshot);
  check('回滚之后 diff 应该为空', after.length === 0, JSON.stringify(after));
}

{
  const sh = fresh();
  const r = sh.run('mkdir -p a/b/c && touch a/b/c/x.txt && ls -R a 2>/dev/null; find a');
  check('mkdir -p 建出多层目录', sh.state().fs.isDir('/home/student/project/a/b/c'));
  check('touch 建出文件', sh.state().fs.exists('/home/student/project/a/b/c/x.txt'));
  check('find 能看到新建的文件', /a\/b\/c\/x\.txt/.test(r.out), r.out);
}

{
  const sh = fresh();
  const r = sh.run('ls -l uploads');
  check('ls -l 输出权限位与属主', /-rw-r--r--/.test(r.out) && /student/.test(r.out), r.out.split('\n')[0]);
  check('ls -l 有 total 行', /^total \d+/m.test(r.out), r.out.split('\n')[0]);
}

/* ── 场景自洽性 ─────────────────────────────────────── */
section('场景自洽性');

{
  const sh = fresh();
  const nodes = sh.state().fs.nodes;
  const orphans = [];
  Object.keys(nodes).forEach(p => {
    if (p === '/') return;
    const parts = p.split('/').filter(Boolean);
    parts.pop();
    let cur = '';
    parts.forEach(seg => {
      cur += '/' + seg;
      if (!nodes[cur]) orphans.push(p + ' 缺少上级 ' + cur);
    });
  });
  check('每个节点的上级目录都存在（否则整棵子树会在遍历里消失）',
    orphans.length === 0, orphans.slice(0, 4).join(' | '));

  /* 大文件要真的能被 du / find 看见 */
  const big = sh.run("find . -type f -size +400k");
  check('find -size +400k 能找到 node_modules 里的大文件',
    /typescript|application|lodash/.test(big.out), JSON.stringify(lines(big.out).slice(0, 3)));
  const top = lines(sh.run('du -ah . | sort -rh | head -n 3').out);
  check('du 先列根的合计、再列子目录，且 node_modules 没被漏掉',
    /project$/.test(top[0]) && /node_modules$/.test(top[1]), JSON.stringify(top));
}

/* ── sed ─────────────────────────────────────────────── */
section('sed：替换、就地修改与权限');

{
  const sh = fresh();
  const r1 = sh.run("sed 's/todo/done/' notes.txt");
  check('sed 默认只把结果打印到标准输出', r1.code === 0 && /^done:/.test(r1.out), JSON.stringify(r1.out));
  check('sed 不加 -i 时原文件不变', sh.run('cat notes.txt').out.startsWith('todo:'), sh.run('cat notes.txt').out);

  const r2 = sh.run("sed 's/o/0/g' notes.txt");
  check('sed 的 g 标志替换每一处', /t0d0/.test(r2.out) && /upl0ads/.test(r2.out), r2.out);

  const r3 = sh.run("sed -n '/uploads/p' notes.txt");
  check('sed -n /模式/p 只打印匹配的行', lines(r3.out).length === 1 && /uploads/.test(r3.out), r3.out);

  const r4 = sh.run("sed 's|uploads|UPLOADS|' notes.txt");
  check('sed 支持自定义分隔符 s|旧|新|', /UPLOADS/.test(r4.out), r4.out);

  const r5 = sh.run("sed 's/todo/[&]/' notes.txt");
  check('替换串里的 & 代表整个匹配', /\[todo\]/.test(r5.out), r5.out);

  const r6 = sh.run("sed 's/(.*): (.*)/[\\1] \\2/' notes.txt");
  check('分组用 ( ) 而不是 \\( \\)，\\1 能用', /\[todo\]/.test(r6.out), r6.out);

  const r7 = sh.run("cat notes.txt | sed 's/todo/done/'");
  check('sed 能从管道读输入', r7.code === 0 && /^done:/.test(r7.out), JSON.stringify(r7.out));

  /* ── 地址形式 /模式/d 与 /模式/ s/// ──────────────────
     加这两条是因为真机实测踩到了：需求「把 src 里所有 js 的 console.log 删掉」，
     模型连续两轮给出 `sed -i '/console\.log/d'` 与 `/console\.log/ s// /g` ——
     在真实 Linux 上都是正确写法，但沙箱不认，于是自纠错闭环卡在
     "永远修不好"上。模型没错，是沙箱不完整。
     断言重点是三件事：地址形式能用、**前导空格不能被吃掉**、
     以及不支持的脚本仍然要明确拒绝（不能假装支持）。 */
  const addrSh = fresh();
  addrSh.run("echo 'a' > /home/student/project/t.txt");
  addrSh.run("echo 'console.log(1)' >> /home/student/project/t.txt");
  addrSh.run("echo 'b' >> /home/student/project/t.txt");
  addrSh.run("echo 'console.log(2)' >> /home/student/project/t.txt");

  const a1 = addrSh.run("sed -i '/console\\.log/ s/console/X/' t.txt");
  check('/模式/ s/旧/新/ 只在匹配行上替换（注意地址后面那个空格）',
    a1.code === 0 && /X\.log\(1\)/.test(addrSh.run('cat t.txt').out) && /\nb\n/.test(addrSh.run('cat t.txt').out),
    'exit ' + a1.code + ' · ' + JSON.stringify(addrSh.run('cat t.txt').out));
  check('替换只落在匹配行：不含该模式的行一字未动',
    addrSh.run('cat t.txt').out.indexOf('b') >= 0 && addrSh.run('cat t.txt').out.indexOf('a\n') === 0,
    JSON.stringify(addrSh.run('cat t.txt').out));

  const a2 = addrSh.run("sed -i '/X\\.log/d' t.txt");
  check('/模式/d 删掉匹配的整行',
    a2.code === 0 && addrSh.run('cat t.txt').out.indexOf('X.log') < 0,
    'exit ' + a2.code + ' · ' + JSON.stringify(addrSh.run('cat t.txt').out));

  const a3 = addrSh.run("sed -i '/绝不匹配的模式/d' t.txt");
  check('地址不匹配任何行时：退出码 0 且文件不变',
    a3.code === 0 && addrSh.run('cat t.txt').out.indexOf('a\n') === 0,
    'exit ' + a3.code + ' · ' + JSON.stringify(addrSh.run('cat t.txt').out));

  const a4 = addrSh.run("sed 'p' t.txt");
  check('没有地址的 p 会被明确拒绝（不能假装支持）',
    a4.code !== 0 && /p 前面要有模式/.test(String(a4.err)), 'exit ' + a4.code + ' · ' + String(a4.err).trim());

  const a5 = addrSh.run("sed 'y/a/b/' t.txt");
  check('y/// 这类没实现的脚本仍然明确报错',
    a5.code !== 0 && /沙箱只实现了/.test(String(a5.err)), 'exit ' + a5.code + ' · ' + String(a5.err).trim());
}

{
  /* 这条守的是"内容指纹"：todo → done 长度相同，
     只看 size 的 diff 会完全看不见这次修改 */
  const sh = fresh();
  const snap = sh.snapshot();
  const r = sh.run("sed -i 's/todo/done/' notes.txt");
  const d = sh.diffSince(snap);
  const node = sh.state().fs.get('/home/student/project/notes.txt');
  check('sed -i 真的改写了文件', r.code === 0 && sh.run('cat notes.txt').out.startsWith('done:'), sh.run('cat notes.txt').out);
  check('同长度替换也能出现在 diff 里（内容指纹）',
    d.some(x => /notes\.txt$/.test(x.path) && x.kind === 'chg'), JSON.stringify(d.slice(0, 3)));
  check('sed -i 不动属主与权限', node.uid === 1000 && node.mode === 0o644,
    'uid=' + node.uid + ' mode=' + node.mode.toString(8));
}

{
  const sh = fresh();
  const snap = sh.snapshot();
  const r = sh.run("sed -i.bak 's/todo/done/' notes.txt");
  const d = sh.diffSince(snap);
  check('sed -i.bak 会留下备份文件',
    r.code === 0 && d.some(x => /notes\.txt\.bak$/.test(x.path) && x.kind === 'add'),
    JSON.stringify(d.map(x => x.kind + ' ' + x.path.split('/').pop())));
  check('备份里保存的是改动前的内容', sh.run('cat notes.txt.bak').out.startsWith('todo:'), sh.run('cat notes.txt.bak').out);
}

{
  const sh = fresh();
  const r = sh.run("sed -i 's/x/y/' /var/log/nginx/error.log");
  check('sed -i 改 root 的文件被拒绝', r.code === 2 && /Permission denied/.test(r.err), r.err);
  check('报错顶的是 sed 自己的名字（不借别人的）', /^sed:/.test(r.err.trim()), r.err);
}

{
  const sh = fresh();
  const r = sh.run("sed 'd' notes.txt");
  /* 意图不变：不支持的写法必须明确报错、不能静默无事。
     支持了地址形式之后，这条的报错变得**更具体**了
     （从"只实现了 s/// 与 /模式/p"变成"d 前面要有模式或行号，例如 /模式/d"），
     所以断言从匹配某个词改成匹配"确实报错且说清了原因"。 */
  check('未实现的 sed 脚本明确报错而不是静默无事',
    r.code !== 0 && /^sed:/.test(String(r.err)) && String(r.err).length > 12,
    'exit ' + r.code + ' · ' + String(r.err).trim());
  check('报错里给出了正确写法（既帮人排查，也让模型的修正有依据）',
    /例如 \/模式\/d/.test(String(r.err)), String(r.err).trim());
}

/* ── grep --include / --exclude ──────────────────────────
   加这组是因为真实实测踩到了：模型写 `grep -R --include *.js TODO .`，
   沙箱把 --include 当成普通位置参数，于是报出"无效的正则：*.js"——
   一个跟真实原因毫不相干的错，模型看了也改不对（实测修正轮仍失败）。
   而这两个参数是真实 grep 最常用的。断言重点是三种写法都要认、
   而且要**真的按扩展名过滤**（只认参数不生效等于没实现）。 */
section('grep：--include / --exclude 的三种写法与过滤语义');

{
  const sh = fresh();
  sh.run('mkdir -p gt');
  sh.run("echo '// TODO: 改这里' > gt/a.js");
  sh.run("echo 'TODO 不该被 *.js 搜到' > gt/b.txt");

  const eq = sh.run('grep -R --include=*.js TODO gt');
  check('--include=*.js（等号）能执行且只命中 js',
    eq.code === 0 && /gt\/a\.js/.test(eq.out) && !/gt\/b\.txt/.test(eq.out),
    'exit ' + eq.code + ' · ' + JSON.stringify(eq.out));

  const sp = sh.run("grep -R --include '*.js' TODO gt");
  check('--include "*.js"（空格）也认',
    sp.code === 0 && /gt\/a\.js/.test(sp.out) && !/gt\/b\.txt/.test(sp.out),
    'exit ' + sp.code + ' · ' + JSON.stringify(sp.out));

  const q = sh.run("grep -R --include='*.js' TODO gt");
  check('--include=\'*.js\'（引号）也认',
    q.code === 0 && /gt\/a\.js/.test(q.out) && !/gt\/b\.txt/.test(q.out),
    'exit ' + q.code + ' · ' + JSON.stringify(q.out));

  const ex = sh.run('grep -R --exclude=*.js TODO gt');
  check('--exclude=*.js 真的排除掉 js',
    ex.code === 0 && !/gt\/a\.js/.test(ex.out) && /gt\/b\.txt/.test(ex.out),
    'exit ' + ex.code + ' · ' + JSON.stringify(ex.out));

  const all = sh.run('grep -R TODO gt');
  check('不带过滤参数时两个文件都命中（原功能没被弄坏）',
    all.code === 0 && /gt\/a\.js/.test(all.out) && /gt\/b\.txt/.test(all.out),
    'exit ' + all.code + ' · ' + JSON.stringify(all.out));

  const txt = sh.run('grep -R --include=*.txt TODO gt');
  check('--include=*.txt 只命中 txt',
    txt.code === 0 && !/gt\/a\.js/.test(txt.out) && /gt\/b\.txt/.test(txt.out),
    'exit ' + txt.code + ' · ' + JSON.stringify(txt.out));
}

/* ── df：读数必须数学成立 ────────────────────────────────
   加这组是因为外部评审实测到：`df -h` 输出 `tmpfs 2.0G 7.2G -5605870860B 361%`——
   已用比总量还大、可用是负数、使用率 361%。根因是把**全盘**已用量填进了 2GB 的 tmpfs 行。
   而 df -h 就在内置规则库的示例里，**Linux 协会的评委第一件事就是跑它**。
   断言：每一行都必须满足 Used ≤ Size、Avail ≥ 0、Use% ≤ 100，且三次运行一致。 */
section('df：读数必须数学成立');

{
  const sh = fresh();
  for (const c of ['df -h', 'df']) {
    const r = sh.run(c);
    const rows = String(r.out || '').split('\n').filter(Boolean).slice(1);
    let ok = rows.length > 0;
    const why = [];
    for (const line of rows) {
      const p = line.trim().split(/\s+/);
      if (p.length < 6) continue;
      const pct = parseInt(p[4], 10);
      if (pct > 100) { ok = false; why.push('使用率 ' + pct + '%'); }
      if (/^-/.test(p[3])) { ok = false; why.push('可用为负 ' + p[3]); }
      if (/^-/.test(p[2])) { ok = false; why.push('已用为负 ' + p[2]); }
    }
    check(c + ' 每一行都满足 Used ≤ Size、Avail ≥ 0、Use% ≤ 100',
      ok, why.length ? why.join(' · ') : rows.join(' | ').slice(0, 90));
  }
  const a = sh.run('df -h').out;
  const b = sh.run('df -h').out;
  check('df 是状态的纯函数（同一命令结果一致）', a === b, a.split('\n')[1] || '');
}
/* ── chown ───────────────────────────────────────────── */
section('chown：属主变更与 root 限制');

{
  const sh = fresh();
  const r = sh.run('chown student notes.txt');
  check('非 root 执行 chown 被拒绝', r.code === 1 && /Operation not permitted/.test(r.err), r.err);
}

{
  const sh = fresh();
  const before = sh.state().fs.get('/home/student/project/scripts/deploy.sh').uid;
  const snap = sh.snapshot();
  const r = sh.run('sudo chown root scripts/deploy.sh');
  const after = sh.state().fs.get('/home/student/project/scripts/deploy.sh').uid;
  check('sudo chown 能把属主改成 root', r.code === 0 && before === 1000 && after === 0, before + ' → ' + after);
  check('属主变更会出现在 diff 里',
    sh.diffSince(snap).some(x => /deploy\.sh$/.test(x.path) && x.kind === 'chg'));
}

{
  const sh = fresh();
  const r = sh.run('sudo chown -R root ./cache');
  check('chown -R 递归覆盖子项',
    r.code === 0 && sh.state().fs.get('/home/student/project/cache/index.tmp').uid === 0);
}

{
  const sh = fresh();
  const r = sh.run('chown student:student notes.txt');
  check('属组语法给出明确说明，而不是假装改了', r.code === 2 && /不跟踪属组/.test(r.err), r.err);
}

/* ── zip / unzip ─────────────────────────────────────── */
section('zip / unzip：归档与解包');

{
  const sh = fresh();
  const r = sh.run('zip -r src.zip ./src');
  check('zip -r 能打包目录并逐项报告', r.code === 0 && /app\.js/.test(r.out) && /index\.js/.test(r.out), r.out.split('\n')[0]);
  check('zip 归档出现在文件树里', sh.state().fs.exists('/home/student/project/src.zip'));
  const l = sh.run('unzip -l src.zip');
  check('unzip -l 能列出归档内容', l.code === 0 && /app\.js/.test(l.out) && /3 files/.test(l.out), l.out.replace(/\n/g, ' | '));
}

{
  const sh = fresh();
  const r = sh.run('zip one.zip notes.txt');
  check('zip 打包单个文件时条目名是文件名本身', /adding: notes\.txt/.test(r.out), r.out.split('\n')[0]);
}

{
  const sh = fresh();
  const r = sh.run('zip bad.zip ./src');
  check('zip 打包目录时要求 -r 并说明原因', r.code === 1 && /-r/.test(r.err), r.err);
}

{
  const sh = fresh();
  const r = sh.run('zip -r c.zip ./src && mkdir -p out && unzip c.zip -d out');
  check('unzip -d 解到指定目录并逐项报告', r.code === 0 && /inflating: app\.js/.test(r.out),
    r.out.split('\n').slice(-2).join(' | '));
  check('解出来的文件真的进了文件树', sh.state().fs.exists('/home/student/project/out/app.js'));
}

{
  const sh = fresh();
  const r = sh.run('unzip nope.zip');
  check('解一个不存在的归档返回 9', r.code === 9 && /cannot find or open/.test(r.err), r.err);
}

{
  const sh = fresh();
  const r = sh.run('unzip notes.txt');
  check('对非沙箱生成的归档给出明确说明', r.code === 9 && /不是沙箱生成的/.test(r.err), r.err);
}

{
  const sh = fresh();
  const r = sh.run('tar -czf one.tar.gz notes.txt && tar -tzf one.tar.gz');
  check('tar 打包单个文件时条目名不是空字符串',
    r.code === 0 && lines(r.out).indexOf('notes.txt') >= 0, JSON.stringify(lines(r.out)));
}

/* ── 确定性 ─────────────────────────────────────────── */
section('确定性（同一个命令必须每次给一样的结果）');

{
  const runs = [0, 1, 2].map(() => fresh().run('du -ah . | sort -rh | head -n 5').out);
  check('同一命令连跑三次输出完全一致',
    runs[0] === runs[1] && runs[1] === runs[2],
    runs.map((r) => r.split('\n')[0]).join('  |  '));

  /* 这条守的是"fixture 里不能有随机数"。
     之前 n.size 用了 Math.random，后果是：du 的总量每次都不一样、
     同一条管道各段的输出互相矛盾（前缀跑出来 2.1M、全量跑出来 1.7M）、
     断言具体大小的用例会随机失败。沙箱说得出"可复现"，就必须真的是常量。 */
  const raw = fs.readFileSync(path.join(assets, 'sandbox-fixtures.js'), 'utf8');
  const code = raw.replace(/\/\*[\s\S]*?\*\//g, '').replace(/\/\/[^\n]*/g, '');
  check('fixture 里没有 Math.random / Date.now（否则整个沙箱不可复现）',
    !/Math\.random|Date\.now/.test(code),
    '在 sandbox-fixtures.js 的代码里找到了随机或时间调用');

  /* 管道拆解要给"每一段的输入/输出样例"，那些样例必须是同一个世界里的数字 */
  const plain = fresh().run('du -ah .').out.split('\n').filter(Boolean);
  const sorted = fresh().run('du -ah . | sort -rh').out.split('\n').filter(Boolean);
  check('同一路径的总量在"原样"与"排序后"两次运行里一致',
    plain[0].split('\t')[0] === sorted[0].split('\t')[0],
    plain[0] + '   vs   ' + sorted[0]);
}

/* ── 汇总 ───────────────────────────────────────────── */
console.log('\n' + '─'.repeat(52));
console.log(fail === 0 ? `全部通过：${pass} 项` : `${pass} 项通过，${fail} 项失败`);
if (fail) {
  console.log('\n失败清单：');
  failures.forEach(f => console.log('  · ' + f));
}
process.exit(fail === 0 ? 0 : 1);
