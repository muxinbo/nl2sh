/* nl2sh · 规则库自测
 *
 * 规则库是「不联网也能用」的那一层，也是演示时最先被看到的内容。
 * 一条写错的条目（命令拼错、anno 片段对不上原文、引用了沙箱里不存在的文件）
 * 在界面上表现为"跑出空结果"或"报错"，而观众不会去分辨是谁的错。
 *
 * 这个脚本把每条规则都真的跑一遍，跑不通就报出来。
 *     node scripts/data-test.mjs
 *
 * 检查项：
 *   1. 结构   必填字段、risk 取值、sim.tree 的状态取值
 *   2. 标注   anno[].t 必须是 cmd 的**真实子串**，且各段**不重叠**
 *   3. 命令   命令名必须在沙箱里实现了（否则会 command not found）
 *   4. 实跑   每条命令真跑一遍：退出码 0、有输出、stderr 干净
 *   5. 唯一   q 与 cmd 不重复
 */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const assets = path.join(here, '..', 'assets');
const read = (p) => fs.readFileSync(path.join(assets, p), 'utf8');

const SYNTAX_FILES = ['data.js', 'sandbox-fixtures.js', 'sandbox-cmds.js', 'sandbox.js', 'ai.js', 'fx.js', 'app.js'];

console.log('脚本语法');
let syntaxBad = 0;
for (const f of SYNTAX_FILES) {
  try {
    new Function(read(f));
    console.log('  ok   ' + f);
  } catch (e) {
    syntaxBad++;
    console.log('  FAIL ' + f + '\n       → ' + e.message);
  }
}
if (syntaxBad) {
  console.log('\n语法没过，后续测试没有意义。');
  process.exit(1);
}

globalThis.window = globalThis;
for (const f of ['sandbox-fixtures.js', 'sandbox-cmds.js', 'sandbox.js']) {
  new Function('window', read(f))(globalThis);
}
new Function('window', read('data.js'))(globalThis);

const SBX = globalThis.NL2SH_SANDBOX;
const items = globalThis.NL2SH.items;
const RISKS = ['safe', 'caution', 'danger'];
const STATES = ['read', 'edit', 'del', 'add'];

let pass = 0, fail = 0;
const failures = [];
function check(name, cond, detail) {
  if (cond) { pass++; }
  else { fail++; failures.push(name); console.log('  FAIL ' + name + (detail !== undefined ? '\n       → ' + detail : '')); }
}

/* ── 1. 结构 + 2. 标注 ─────────────────────────────── */
console.log('\n结构 / 标注（' + items.length + ' 条）');
items.forEach((it, i) => {
  const tag = '[' + (i + 1) + '] ' + String(it.q || '(缺 q)').slice(0, 22);

  check(tag + ' · q 存在', typeof it.q === 'string' && it.q.length > 3);
  check(tag + ' · cmd 存在', typeof it.cmd === 'string' && it.cmd.length > 1);
  check(tag + ' · risk 合法', RISKS.indexOf(it.risk) >= 0, 'got ' + it.risk);
  check(tag + ' · why 非空', typeof it.why === 'string' && it.why.length > 4);
  check(tag + ' · see 是数组', Array.isArray(it.see) && it.see.length >= 1);

  /* 期望值：默认 ok（退出码 0）；denied 表示"这条就是要演示被系统拒绝" */
  check(tag + ' · expect 取值合法', it.expect === undefined || it.expect === 'ok' || it.expect === 'denied',
    'got ' + it.expect);

  /* anno 片段必须是 cmd 的真实子串 */
  check(tag + ' · anno 2~5 段', Array.isArray(it.anno) && it.anno.length >= 2 && it.anno.length <= 5,
    'got ' + (it.anno ? it.anno.length : 0) + ' 段');

  const spans = [];
  (it.anno || []).forEach((a, k) => {
    const t = a && a.t;
    const n = a && a.n;
    check(tag + ' · anno[' + k + '].n 非空', typeof n === 'string' && n.length > 4);
    if (typeof t !== 'string' || !t) { check(tag + ' · anno[' + k + '].t 非空', false); return; }
    const idx = String(it.cmd).indexOf(t);
    check(tag + ' · anno[' + k + '] "' + t + '" 是 cmd 子串', idx >= 0,
      idx < 0 ? '在 cmd 里找不到：' + t : undefined);
    if (idx >= 0) spans.push({ s: idx, e: idx + t.length, t: t });
  });

  /* 片段不能互相重叠，否则高亮会打架 */
  spans.sort((a, b) => a.s - b.s);
  let overlap = null;
  for (let k = 1; k < spans.length; k++) {
    if (spans[k].s < spans[k - 1].e) overlap = spans[k - 1].t + ' 与 ' + spans[k].t;
  }
  check(tag + ' · anno 片段不重叠', !overlap, overlap || undefined);

  /* sim 结构 */
  const sim = it.sim || {};
  check(tag + ' · sim.scope 非空', typeof sim.scope === 'string' && sim.scope.length > 0);
  check(tag + ' · sim 三个布尔位', typeof sim.sudo === 'boolean' && typeof sim.irreversible === 'boolean');
  check(tag + ' · sim.note 非空', typeof sim.note === 'string' && sim.note.length > 4);
  check(tag + ' · sim.tree 非空', Array.isArray(sim.tree) && sim.tree.length >= 1);
  (sim.tree || []).forEach((row, k) => {
    check(tag + ' · tree[' + k + '].s 合法', row && STATES.indexOf(row.s) >= 0,
      row ? 'got ' + row.s : 'missing row');
    check(tag + ' · tree[' + k + '].p 非空', row && typeof row.p === 'string' && row.p.length > 0);
  });

  /* 风险自洽：irreversible 的不能标成 safe */
  if (sim.irreversible) check(tag + ' · 不可撤销的不该是 safe', it.risk !== 'safe', 'risk=' + it.risk);
});

/* ── 5. 唯一性 ─────────────────────────────────────── */
console.log('\n唯一性');
const qSeen = new Map(), cmdSeen = new Map();
items.forEach((it, i) => {
  if (qSeen.has(it.q)) check('[重] q 重复：' + it.q, false, '第 ' + (qSeen.get(it.q) + 1) + ' 与 ' + (i + 1) + ' 条');
  else qSeen.set(it.q, i);
  if (cmdSeen.has(it.cmd)) check('[重] cmd 重复：' + it.cmd, false, '第 ' + (cmdSeen.get(it.cmd) + 1) + ' 与 ' + (i + 1) + ' 条');
  else cmdSeen.set(it.cmd, i);
});
check('q 全部唯一', qSeen.size === items.length);
check('cmd 全部唯一', cmdSeen.size === items.length);

/* ── 3. 命令名必须在沙箱里实现 + 4. 真跑一遍 ────────── */
console.log('\n实跑（每条命令都真跑：退出码必须为 0，且"有输出或有文件变更"）');

/* 这些是 shell 关键字/内建，不是外部命令，不该拿去查沙箱命令表 */
const SHELL_WORDS = new Set(['for', 'do', 'done', 'if', 'then', 'else', 'elif', 'fi', 'while', 'in', 'esac', 'case', 'time', 'sudo']);

const probe = SBX.createSession();
const results = [];
items.forEach((it, i) => {
  const tag = '[' + (i + 1) + '] ' + String(it.q || '').slice(0, 20);
  const names = probe.commandNames(it.cmd).filter((n) => !SHELL_WORDS.has(n));

  /* 未实现的命令 → 界面会显示 command not found，必须拦下 */
  const unknown = names.filter((n) => !probe.hasCommand(n));
  check(tag + ' · 命令都已实现', unknown.length === 0,
    unknown.length ? '沙箱未实现：' + unknown.join(' ') + '  （命令：' + it.cmd + '）' : undefined);

  /* 真跑：每次用全新会话，避免上一条的改动影响下一条 */
  let r, changed = 0;
  try {
    const s = SBX.createSession();
    const snap = s.snapshot();
    r = s.run(it.cmd);
    /* 有些命令天生静默（chmod / rm / find -delete）。
       它们的"结果"体现在文件系统上，所以要么有输出，要么有变更，二者有一即可。 */
    const d = s.diffSince(snap);
    changed = Array.isArray(d) ? d.length : (d && Array.isArray(d.changes) ? d.changes.length : 0);
  } catch (e) {
    check(tag + ' · 执行不抛异常', false, e.message);
    results.push({ i: i + 1, q: it.q, code: 'THROW', lines: 0, changed: 0, cmd: it.cmd });
    return;
  }
  const outLines = String(r.out || '').split('\n').filter((s) => s.trim().length);
  const errTxt = String(r.err || '').trim();

  /* 条目可以在数据里自声明期望：默认 ok；denied 表示"故意演示被系统拒绝"。
     有了它，验证依然是严格的，而不是给某些条目开后门。 */
  if (it.expect === 'denied') {
    /* 被拒绝的命令"什么都不改"恰恰是正确结果，所以这里不要求有输出或变更，
       只要求：确实失败了、而且 stderr 说清了原因是权限。 */
    check(tag + ' · 按预期被拒绝（非 0 退出码）', r.code !== 0, 'code=' + r.code + '（期望非 0）');
    check(tag + ' · 拒绝原因是权限',
      /Permission denied|Operation not permitted/i.test(errTxt), errTxt.slice(0, 110) || '（stderr 为空）');
  } else {
    check(tag + ' · 退出码为 0', r.code === 0, 'code=' + r.code + '  err=' + errTxt.slice(0, 90));
    check(tag + ' · 有输出或有文件变更', outLines.length > 0 || changed > 0,
      '既没有输出也没有文件变更 —— 多半是引用了沙箱里不存在的文件/路径');
    check(tag + ' · stderr 干净', errTxt.length === 0, errTxt.slice(0, 110));
  }

  results.push({ i: i + 1, q: it.q, code: r.code, lines: outLines.length, changed: changed, cmd: it.cmd });
});

if (process.env.NL2SH_VERBOSE) {
  console.log('\n逐条结果');
  results.forEach((r) => {
    console.log('  [code ' + String(r.code).padStart(3) + '] ' + String(r.lines).padStart(3) + ' 行 / ' +
      String(r.changed).padStart(2) + ' 变更  ' + String(r.q).slice(0, 22).padEnd(24) + r.cmd.slice(0, 46));
  });
}

console.log('\n' + '─'.repeat(52));
console.log('规则库 ' + items.length + ' 条 · 命令 ' + items.length + ' 个');
console.log('全部通过：' + pass + ' 项' + (fail ? '     失败：' + fail + ' 项' : ''));
if (fail) {
  console.log('\n失败清单：');
  failures.forEach((f) => console.log('  · ' + f));
  process.exit(1);
}
